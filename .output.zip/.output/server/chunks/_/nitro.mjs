import process from 'node:process';globalThis._importMeta_=globalThis._importMeta_||{url:"file:///_entry.js",env:process.env};import { createHead as createHead$1 } from 'unhead/server';
import { isRef, toValue } from 'vue';
import { DeprecationsPlugin } from 'unhead/legacy';
import { PromisesPlugin, TemplateParamsPlugin, AliasSortingPlugin } from 'unhead/plugins';
import http from 'node:http';
import https from 'node:https';
import { EventEmitter } from 'node:events';
import { Buffer as Buffer$1 } from 'node:buffer';
import { promises, existsSync } from 'node:fs';
import { resolve as resolve$1, dirname as dirname$1, join } from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';

const suspectProtoRx = /"(?:_|\\u0{2}5[Ff]){2}(?:p|\\u0{2}70)(?:r|\\u0{2}72)(?:o|\\u0{2}6[Ff])(?:t|\\u0{2}74)(?:o|\\u0{2}6[Ff])(?:_|\\u0{2}5[Ff]){2}"\s*:/;
const suspectConstructorRx = /"(?:c|\\u0063)(?:o|\\u006[Ff])(?:n|\\u006[Ee])(?:s|\\u0073)(?:t|\\u0074)(?:r|\\u0072)(?:u|\\u0075)(?:c|\\u0063)(?:t|\\u0074)(?:o|\\u006[Ff])(?:r|\\u0072)"\s*:/;
const JsonSigRx = /^\s*["[{]|^\s*-?\d{1,16}(\.\d{1,17})?([Ee][+-]?\d+)?\s*$/;
function jsonParseTransform(key, value) {
  if (key === "__proto__" || key === "constructor" && value && typeof value === "object" && "prototype" in value) {
    warnKeyDropped(key);
    return;
  }
  return value;
}
function warnKeyDropped(key) {
  console.warn(`[destr] Dropping "${key}" key to prevent prototype pollution.`);
}
function destr(value, options = {}) {
  if (typeof value !== "string") {
    return value;
  }
  if (value[0] === '"' && value[value.length - 1] === '"' && value.indexOf("\\") === -1) {
    return value.slice(1, -1);
  }
  const _value = value.trim();
  if (_value.length <= 9) {
    switch (_value.toLowerCase()) {
      case "true": {
        return true;
      }
      case "false": {
        return false;
      }
      case "undefined": {
        return void 0;
      }
      case "null": {
        return null;
      }
      case "nan": {
        return Number.NaN;
      }
      case "infinity": {
        return Number.POSITIVE_INFINITY;
      }
      case "-infinity": {
        return Number.NEGATIVE_INFINITY;
      }
    }
  }
  if (!JsonSigRx.test(value)) {
    if (options.strict) {
      throw new SyntaxError("[destr] Invalid JSON");
    }
    return value;
  }
  try {
    if (suspectProtoRx.test(value) || suspectConstructorRx.test(value)) {
      if (options.strict) {
        throw new Error("[destr] Possible prototype pollution");
      }
      return JSON.parse(value, jsonParseTransform);
    }
    return JSON.parse(value);
  } catch (error) {
    if (options.strict) {
      throw error;
    }
    return value;
  }
}

const HASH_RE$1 = /#/g;
const AMPERSAND_RE = /&/g;
const SLASH_RE = /\//g;
const EQUAL_RE = /=/g;
const PLUS_RE = /\+/g;
const ENC_CARET_RE = /%5e/gi;
const ENC_BACKTICK_RE = /%60/gi;
const ENC_PIPE_RE$1 = /%7c/gi;
const ENC_SPACE_RE = /%20/gi;
const ENC_SLASH_RE = /%2f/gi;
function encode(text) {
  return encodeURI("" + text).replace(ENC_PIPE_RE$1, "|");
}
function encodeQueryValue(input) {
  return encode(typeof input === "string" ? input : JSON.stringify(input)).replace(PLUS_RE, "%2B").replace(ENC_SPACE_RE, "+").replace(HASH_RE$1, "%23").replace(AMPERSAND_RE, "%26").replace(ENC_BACKTICK_RE, "`").replace(ENC_CARET_RE, "^").replace(SLASH_RE, "%2F");
}
function encodeQueryKey(text) {
  return encodeQueryValue(text).replace(EQUAL_RE, "%3D");
}
function decode$1(text = "") {
  try {
    return decodeURIComponent("" + text);
  } catch {
    return "" + text;
  }
}
function decodePath(text) {
  return decode$1(text.replace(ENC_SLASH_RE, "%252F"));
}
function decodeQueryKey(text) {
  return decode$1(text.replace(PLUS_RE, " "));
}
function decodeQueryValue(text) {
  return decode$1(text.replace(PLUS_RE, " "));
}

function parseQuery(parametersString = "") {
  const object = /* @__PURE__ */ Object.create(null);
  if (parametersString[0] === "?") {
    parametersString = parametersString.slice(1);
  }
  for (const parameter of parametersString.split("&")) {
    const s = parameter.match(/([^=]+)=?(.*)/) || [];
    if (s.length < 2) {
      continue;
    }
    const key = decodeQueryKey(s[1]);
    if (key === "__proto__" || key === "constructor") {
      continue;
    }
    const value = decodeQueryValue(s[2] || "");
    if (object[key] === void 0) {
      object[key] = value;
    } else if (Array.isArray(object[key])) {
      object[key].push(value);
    } else {
      object[key] = [object[key], value];
    }
  }
  return object;
}
function encodeQueryItem(key, value) {
  if (typeof value === "number" || typeof value === "boolean") {
    value = String(value);
  }
  if (!value) {
    return encodeQueryKey(key);
  }
  if (Array.isArray(value)) {
    return value.map(
      (_value) => `${encodeQueryKey(key)}=${encodeQueryValue(_value)}`
    ).join("&");
  }
  return `${encodeQueryKey(key)}=${encodeQueryValue(value)}`;
}
function stringifyQuery(query) {
  return Object.keys(query).filter((k) => query[k] !== void 0).map((k) => encodeQueryItem(k, query[k])).filter(Boolean).join("&");
}

const PROTOCOL_STRICT_REGEX = /^[\s\w\0+.-]{2,}:([/\\]{1,2})/;
const PROTOCOL_REGEX = /^[\s\w\0+.-]{2,}:([/\\]{2})?/;
const PROTOCOL_RELATIVE_REGEX = /^([/\\]\s*){2,}[^/\\]/;
const PROTOCOL_SCRIPT_RE = /^[\s\0]*(blob|data|javascript|vbscript):$/i;
const TRAILING_SLASH_RE = /\/$|\/\?|\/#/;
const JOIN_LEADING_SLASH_RE = /^\.?\//;
function hasProtocol(inputString, opts = {}) {
  if (typeof opts === "boolean") {
    opts = { acceptRelative: opts };
  }
  if (opts.strict) {
    return PROTOCOL_STRICT_REGEX.test(inputString);
  }
  return PROTOCOL_REGEX.test(inputString) || (opts.acceptRelative ? PROTOCOL_RELATIVE_REGEX.test(inputString) : false);
}
function isScriptProtocol(protocol) {
  return !!protocol && PROTOCOL_SCRIPT_RE.test(protocol);
}
function hasTrailingSlash(input = "", respectQueryAndFragment) {
  if (!respectQueryAndFragment) {
    return input.endsWith("/");
  }
  return TRAILING_SLASH_RE.test(input);
}
function withoutTrailingSlash(input = "", respectQueryAndFragment) {
  if (!respectQueryAndFragment) {
    return (hasTrailingSlash(input) ? input.slice(0, -1) : input) || "/";
  }
  if (!hasTrailingSlash(input, true)) {
    return input || "/";
  }
  let path = input;
  let fragment = "";
  const fragmentIndex = input.indexOf("#");
  if (fragmentIndex !== -1) {
    path = input.slice(0, fragmentIndex);
    fragment = input.slice(fragmentIndex);
  }
  const [s0, ...s] = path.split("?");
  const cleanPath = s0.endsWith("/") ? s0.slice(0, -1) : s0;
  return (cleanPath || "/") + (s.length > 0 ? `?${s.join("?")}` : "") + fragment;
}
function withTrailingSlash(input = "", respectQueryAndFragment) {
  if (!respectQueryAndFragment) {
    return input.endsWith("/") ? input : input + "/";
  }
  if (hasTrailingSlash(input, true)) {
    return input || "/";
  }
  let path = input;
  let fragment = "";
  const fragmentIndex = input.indexOf("#");
  if (fragmentIndex !== -1) {
    path = input.slice(0, fragmentIndex);
    fragment = input.slice(fragmentIndex);
    if (!path) {
      return fragment;
    }
  }
  const [s0, ...s] = path.split("?");
  return s0 + "/" + (s.length > 0 ? `?${s.join("?")}` : "") + fragment;
}
function hasLeadingSlash(input = "") {
  return input.startsWith("/");
}
function withLeadingSlash(input = "") {
  return hasLeadingSlash(input) ? input : "/" + input;
}
function withBase(input, base) {
  if (isEmptyURL(base) || hasProtocol(input)) {
    return input;
  }
  const _base = withoutTrailingSlash(base);
  if (input.startsWith(_base)) {
    const nextChar = input[_base.length];
    if (!nextChar || nextChar === "/" || nextChar === "?") {
      return input;
    }
  }
  return joinURL(_base, input);
}
function withoutBase(input, base) {
  if (isEmptyURL(base)) {
    return input;
  }
  const _base = withoutTrailingSlash(base);
  if (!input.startsWith(_base)) {
    return input;
  }
  const nextChar = input[_base.length];
  if (nextChar && nextChar !== "/" && nextChar !== "?") {
    return input;
  }
  const trimmed = input.slice(_base.length).replace(/^\/+/, "");
  return "/" + trimmed;
}
function withQuery(input, query) {
  const parsed = parseURL(input);
  const mergedQuery = { ...parseQuery(parsed.search), ...query };
  parsed.search = stringifyQuery(mergedQuery);
  return stringifyParsedURL(parsed);
}
function getQuery$1(input) {
  return parseQuery(parseURL(input).search);
}
function isEmptyURL(url) {
  return !url || url === "/";
}
function isNonEmptyURL(url) {
  return url && url !== "/";
}
function joinURL(base, ...input) {
  let url = base || "";
  for (const segment of input.filter((url2) => isNonEmptyURL(url2))) {
    if (url) {
      const _segment = segment.replace(JOIN_LEADING_SLASH_RE, "");
      url = withTrailingSlash(url) + _segment;
    } else {
      url = segment;
    }
  }
  return url;
}
function joinRelativeURL(..._input) {
  const JOIN_SEGMENT_SPLIT_RE = /\/(?!\/)/;
  const input = _input.filter(Boolean);
  const segments = [];
  let segmentsDepth = 0;
  for (const i of input) {
    if (!i || i === "/") {
      continue;
    }
    for (const [sindex, s] of i.split(JOIN_SEGMENT_SPLIT_RE).entries()) {
      if (!s || s === ".") {
        continue;
      }
      if (s === "..") {
        if (segments.length === 1 && hasProtocol(segments[0])) {
          continue;
        }
        segments.pop();
        segmentsDepth--;
        continue;
      }
      if (sindex === 1 && segments[segments.length - 1]?.endsWith(":/")) {
        segments[segments.length - 1] += "/" + s;
        continue;
      }
      segments.push(s);
      segmentsDepth++;
    }
  }
  let url = segments.join("/");
  if (segmentsDepth >= 0) {
    if (input[0]?.startsWith("/") && !url.startsWith("/")) {
      url = "/" + url;
    } else if (input[0]?.startsWith("./") && !url.startsWith("./")) {
      url = "./" + url;
    }
  } else {
    url = "../".repeat(-1 * segmentsDepth) + url;
  }
  if (input[input.length - 1]?.endsWith("/") && !url.endsWith("/")) {
    url += "/";
  }
  return url;
}

const protocolRelative = Symbol.for("ufo:protocolRelative");
function parseURL(input = "", defaultProto) {
  const _specialProtoMatch = input.match(
    /^[\s\0]*(blob:|data:|javascript:|vbscript:)(.*)/i
  );
  if (_specialProtoMatch) {
    const [, _proto, _pathname = ""] = _specialProtoMatch;
    return {
      protocol: _proto.toLowerCase(),
      pathname: _pathname,
      href: _proto + _pathname,
      auth: "",
      host: "",
      search: "",
      hash: ""
    };
  }
  if (!hasProtocol(input, { acceptRelative: true })) {
    return parsePath(input);
  }
  const [, protocol = "", auth, hostAndPath = ""] = input.replace(/\\/g, "/").match(/^[\s\0]*([\w+.-]{2,}:)?\/\/([^/@]+@)?(.*)/) || [];
  let [, host = "", path = ""] = hostAndPath.match(/([^#/?]*)(.*)?/) || [];
  if (protocol === "file:") {
    path = path.replace(/\/(?=[A-Za-z]:)/, "");
  }
  const { pathname, search, hash } = parsePath(path);
  return {
    protocol: protocol.toLowerCase(),
    auth: auth ? auth.slice(0, Math.max(0, auth.length - 1)) : "",
    host,
    pathname,
    search,
    hash,
    [protocolRelative]: !protocol
  };
}
function parsePath(input = "") {
  const [pathname = "", search = "", hash = ""] = (input.match(/([^#?]*)(\?[^#]*)?(#.*)?/) || []).splice(1);
  return {
    pathname,
    search,
    hash
  };
}
function stringifyParsedURL(parsed) {
  const pathname = parsed.pathname || "";
  const search = parsed.search ? (parsed.search.startsWith("?") ? "" : "?") + parsed.search : "";
  const hash = parsed.hash || "";
  const auth = parsed.auth ? parsed.auth + "@" : "";
  const host = parsed.host || "";
  const proto = parsed.protocol || parsed[protocolRelative] ? (parsed.protocol || "") + "//" : "";
  return proto + auth + host + pathname + search + hash;
}

const NullObject = /* @__PURE__ */ (() => {
  const C = function() {
  };
  C.prototype = /* @__PURE__ */ Object.create(null);
  return C;
})();
function parse(str, options) {
  if (typeof str !== "string") {
    throw new TypeError("argument str must be a string");
  }
  const obj = new NullObject();
  const opt = {};
  const dec = opt.decode || decode;
  let index = 0;
  while (index < str.length) {
    const eqIdx = str.indexOf("=", index);
    if (eqIdx === -1) {
      break;
    }
    let endIdx = str.indexOf(";", index);
    if (endIdx === -1) {
      endIdx = str.length;
    } else if (endIdx < eqIdx) {
      index = str.lastIndexOf(";", eqIdx - 1) + 1;
      continue;
    }
    const key = str.slice(index, eqIdx).trim();
    if (opt?.filter && !opt?.filter(key)) {
      index = endIdx + 1;
      continue;
    }
    if (void 0 === obj[key]) {
      let val = str.slice(eqIdx + 1, endIdx).trim();
      if (val.codePointAt(0) === 34) {
        val = val.slice(1, -1);
      }
      obj[key] = tryDecode(val, dec);
    }
    index = endIdx + 1;
  }
  return obj;
}
function decode(str) {
  return str.includes("%") ? decodeURIComponent(str) : str;
}
function tryDecode(str, decode2) {
  try {
    return decode2(str);
  } catch {
    return str;
  }
}

const fieldContentRegExp = /^[\u0009\u0020-\u007E\u0080-\u00FF]+$/;
function serialize$2(name, value, options) {
  const opt = options || {};
  const enc = opt.encode || encodeURIComponent;
  if (typeof enc !== "function") {
    throw new TypeError("option encode is invalid");
  }
  if (!fieldContentRegExp.test(name)) {
    throw new TypeError("argument name is invalid");
  }
  const encodedValue = enc(value);
  if (encodedValue && !fieldContentRegExp.test(encodedValue)) {
    throw new TypeError("argument val is invalid");
  }
  let str = name + "=" + encodedValue;
  if (void 0 !== opt.maxAge && opt.maxAge !== null) {
    const maxAge = opt.maxAge - 0;
    if (Number.isNaN(maxAge) || !Number.isFinite(maxAge)) {
      throw new TypeError("option maxAge is invalid");
    }
    str += "; Max-Age=" + Math.floor(maxAge);
  }
  if (opt.domain) {
    if (!fieldContentRegExp.test(opt.domain)) {
      throw new TypeError("option domain is invalid");
    }
    str += "; Domain=" + opt.domain;
  }
  if (opt.path) {
    if (!fieldContentRegExp.test(opt.path)) {
      throw new TypeError("option path is invalid");
    }
    str += "; Path=" + opt.path;
  }
  if (opt.expires) {
    if (!isDate(opt.expires) || Number.isNaN(opt.expires.valueOf())) {
      throw new TypeError("option expires is invalid");
    }
    str += "; Expires=" + opt.expires.toUTCString();
  }
  if (opt.httpOnly) {
    str += "; HttpOnly";
  }
  if (opt.secure) {
    str += "; Secure";
  }
  if (opt.priority) {
    const priority = typeof opt.priority === "string" ? opt.priority.toLowerCase() : opt.priority;
    switch (priority) {
      case "low": {
        str += "; Priority=Low";
        break;
      }
      case "medium": {
        str += "; Priority=Medium";
        break;
      }
      case "high": {
        str += "; Priority=High";
        break;
      }
      default: {
        throw new TypeError("option priority is invalid");
      }
    }
  }
  if (opt.sameSite) {
    const sameSite = typeof opt.sameSite === "string" ? opt.sameSite.toLowerCase() : opt.sameSite;
    switch (sameSite) {
      case true: {
        str += "; SameSite=Strict";
        break;
      }
      case "lax": {
        str += "; SameSite=Lax";
        break;
      }
      case "strict": {
        str += "; SameSite=Strict";
        break;
      }
      case "none": {
        str += "; SameSite=None";
        break;
      }
      default: {
        throw new TypeError("option sameSite is invalid");
      }
    }
  }
  if (opt.partitioned) {
    str += "; Partitioned";
  }
  return str;
}
function isDate(val) {
  return Object.prototype.toString.call(val) === "[object Date]" || val instanceof Date;
}

function parseSetCookie(setCookieValue, options) {
  const parts = (setCookieValue || "").split(";").filter((str) => typeof str === "string" && !!str.trim());
  const nameValuePairStr = parts.shift() || "";
  const parsed = _parseNameValuePair(nameValuePairStr);
  const name = parsed.name;
  let value = parsed.value;
  try {
    value = options?.decode === false ? value : (options?.decode || decodeURIComponent)(value);
  } catch {
  }
  const cookie = {
    name,
    value
  };
  for (const part of parts) {
    const sides = part.split("=");
    const partKey = (sides.shift() || "").trimStart().toLowerCase();
    const partValue = sides.join("=");
    switch (partKey) {
      case "expires": {
        cookie.expires = new Date(partValue);
        break;
      }
      case "max-age": {
        cookie.maxAge = Number.parseInt(partValue, 10);
        break;
      }
      case "secure": {
        cookie.secure = true;
        break;
      }
      case "httponly": {
        cookie.httpOnly = true;
        break;
      }
      case "samesite": {
        cookie.sameSite = partValue;
        break;
      }
      default: {
        cookie[partKey] = partValue;
      }
    }
  }
  return cookie;
}
function _parseNameValuePair(nameValuePairStr) {
  let name = "";
  let value = "";
  const nameValueArr = nameValuePairStr.split("=");
  if (nameValueArr.length > 1) {
    name = nameValueArr.shift();
    value = nameValueArr.join("=");
  } else {
    value = nameValuePairStr;
  }
  return { name, value };
}

const NODE_TYPES = {
  NORMAL: 0,
  WILDCARD: 1,
  PLACEHOLDER: 2
};

function createRouter$1(options = {}) {
  const ctx = {
    options,
    rootNode: createRadixNode(),
    staticRoutesMap: {}
  };
  const normalizeTrailingSlash = (p) => options.strictTrailingSlash ? p : p.replace(/\/$/, "") || "/";
  if (options.routes) {
    for (const path in options.routes) {
      insert(ctx, normalizeTrailingSlash(path), options.routes[path]);
    }
  }
  return {
    ctx,
    lookup: (path) => lookup(ctx, normalizeTrailingSlash(path)),
    insert: (path, data) => insert(ctx, normalizeTrailingSlash(path), data),
    remove: (path) => remove(ctx, normalizeTrailingSlash(path))
  };
}
function lookup(ctx, path) {
  const staticPathNode = ctx.staticRoutesMap[path];
  if (staticPathNode) {
    return staticPathNode.data;
  }
  const sections = path.split("/");
  const params = {};
  let paramsFound = false;
  let wildcardNode = null;
  let node = ctx.rootNode;
  let wildCardParam = null;
  for (let i = 0; i < sections.length; i++) {
    const section = sections[i];
    if (node.wildcardChildNode !== null) {
      wildcardNode = node.wildcardChildNode;
      wildCardParam = sections.slice(i).join("/");
    }
    const nextNode = node.children.get(section);
    if (nextNode === void 0) {
      if (node && node.placeholderChildren.length > 1) {
        const remaining = sections.length - i;
        node = node.placeholderChildren.find((c) => c.maxDepth === remaining) || null;
      } else {
        node = node.placeholderChildren[0] || null;
      }
      if (!node) {
        break;
      }
      if (node.paramName) {
        params[node.paramName] = section;
      }
      paramsFound = true;
    } else {
      node = nextNode;
    }
  }
  if ((node === null || node.data === null) && wildcardNode !== null) {
    node = wildcardNode;
    params[node.paramName || "_"] = wildCardParam;
    paramsFound = true;
  }
  if (!node) {
    return null;
  }
  if (paramsFound) {
    return {
      ...node.data,
      params: paramsFound ? params : void 0
    };
  }
  return node.data;
}
function insert(ctx, path, data) {
  let isStaticRoute = true;
  const sections = path.split("/");
  let node = ctx.rootNode;
  let _unnamedPlaceholderCtr = 0;
  const matchedNodes = [node];
  for (const section of sections) {
    let childNode;
    if (childNode = node.children.get(section)) {
      node = childNode;
    } else {
      const type = getNodeType(section);
      childNode = createRadixNode({ type, parent: node });
      node.children.set(section, childNode);
      if (type === NODE_TYPES.PLACEHOLDER) {
        childNode.paramName = section === "*" ? `_${_unnamedPlaceholderCtr++}` : section.slice(1);
        node.placeholderChildren.push(childNode);
        isStaticRoute = false;
      } else if (type === NODE_TYPES.WILDCARD) {
        node.wildcardChildNode = childNode;
        childNode.paramName = section.slice(
          3
          /* "**:" */
        ) || "_";
        isStaticRoute = false;
      }
      matchedNodes.push(childNode);
      node = childNode;
    }
  }
  for (const [depth, node2] of matchedNodes.entries()) {
    node2.maxDepth = Math.max(matchedNodes.length - depth, node2.maxDepth || 0);
  }
  node.data = data;
  if (isStaticRoute === true) {
    ctx.staticRoutesMap[path] = node;
  }
  return node;
}
function remove(ctx, path) {
  let success = false;
  const sections = path.split("/");
  let node = ctx.rootNode;
  for (const section of sections) {
    node = node.children.get(section);
    if (!node) {
      return success;
    }
  }
  if (node.data) {
    const lastSection = sections.at(-1) || "";
    node.data = null;
    if (Object.keys(node.children).length === 0 && node.parent) {
      node.parent.children.delete(lastSection);
      node.parent.wildcardChildNode = null;
      node.parent.placeholderChildren = [];
    }
    success = true;
  }
  return success;
}
function createRadixNode(options = {}) {
  return {
    type: options.type || NODE_TYPES.NORMAL,
    maxDepth: 0,
    parent: options.parent || null,
    children: /* @__PURE__ */ new Map(),
    data: options.data || null,
    paramName: options.paramName || null,
    wildcardChildNode: null,
    placeholderChildren: []
  };
}
function getNodeType(str) {
  if (str.startsWith("**")) {
    return NODE_TYPES.WILDCARD;
  }
  if (str[0] === ":" || str === "*") {
    return NODE_TYPES.PLACEHOLDER;
  }
  return NODE_TYPES.NORMAL;
}

function toRouteMatcher(router) {
  const table = _routerNodeToTable("", router.ctx.rootNode);
  return _createMatcher(table, router.ctx.options.strictTrailingSlash);
}
function _createMatcher(table, strictTrailingSlash) {
  return {
    ctx: { table },
    matchAll: (path) => _matchRoutes(path, table, strictTrailingSlash)
  };
}
function _createRouteTable() {
  return {
    static: /* @__PURE__ */ new Map(),
    wildcard: /* @__PURE__ */ new Map(),
    dynamic: /* @__PURE__ */ new Map()
  };
}
function _matchRoutes(path, table, strictTrailingSlash) {
  if (strictTrailingSlash !== true && path.endsWith("/")) {
    path = path.slice(0, -1) || "/";
  }
  const matches = [];
  for (const [key, value] of _sortRoutesMap(table.wildcard)) {
    if (path === key || path.startsWith(key + "/")) {
      matches.push(value);
    }
  }
  for (const [key, value] of _sortRoutesMap(table.dynamic)) {
    if (path.startsWith(key + "/")) {
      const subPath = "/" + path.slice(key.length).split("/").splice(2).join("/");
      matches.push(..._matchRoutes(subPath, value));
    }
  }
  const staticMatch = table.static.get(path);
  if (staticMatch) {
    matches.push(staticMatch);
  }
  return matches.filter(Boolean);
}
function _sortRoutesMap(m) {
  return [...m.entries()].sort((a, b) => a[0].length - b[0].length);
}
function _routerNodeToTable(initialPath, initialNode) {
  const table = _createRouteTable();
  function _addNode(path, node) {
    if (path) {
      if (node.type === NODE_TYPES.NORMAL && !(path.includes("*") || path.includes(":"))) {
        if (node.data) {
          table.static.set(path, node.data);
        }
      } else if (node.type === NODE_TYPES.WILDCARD) {
        table.wildcard.set(path.replace("/**", ""), node.data);
      } else if (node.type === NODE_TYPES.PLACEHOLDER) {
        const subTable = _routerNodeToTable("", node);
        if (node.data) {
          subTable.static.set("/", node.data);
        }
        table.dynamic.set(path.replace(/\/\*|\/:\w+/, ""), subTable);
        return;
      }
    }
    for (const [childPath, child] of node.children.entries()) {
      _addNode(`${path}/${childPath}`.replace("//", "/"), child);
    }
  }
  _addNode(initialPath, initialNode);
  return table;
}

function isPlainObject(value) {
  if (value === null || typeof value !== "object") {
    return false;
  }
  const prototype = Object.getPrototypeOf(value);
  if (prototype !== null && prototype !== Object.prototype && Object.getPrototypeOf(prototype) !== null) {
    return false;
  }
  if (Symbol.iterator in value) {
    return false;
  }
  if (Symbol.toStringTag in value) {
    return Object.prototype.toString.call(value) === "[object Module]";
  }
  return true;
}

function _defu(baseObject, defaults, namespace = ".", merger) {
  if (!isPlainObject(defaults)) {
    return _defu(baseObject, {}, namespace, merger);
  }
  const object = { ...defaults };
  for (const key of Object.keys(baseObject)) {
    if (key === "__proto__" || key === "constructor") {
      continue;
    }
    const value = baseObject[key];
    if (value === null || value === void 0) {
      continue;
    }
    if (merger && merger(object, key, value, namespace)) {
      continue;
    }
    if (Array.isArray(value) && Array.isArray(object[key])) {
      object[key] = [...value, ...object[key]];
    } else if (isPlainObject(value) && isPlainObject(object[key])) {
      object[key] = _defu(
        value,
        object[key],
        (namespace ? `${namespace}.` : "") + key.toString(),
        merger
      );
    } else {
      object[key] = value;
    }
  }
  return object;
}
function createDefu(merger) {
  return (...arguments_) => (
    // eslint-disable-next-line unicorn/no-array-reduce
    arguments_.reduce((p, c) => _defu(p, c, "", merger), {})
  );
}
const defu = createDefu();
const defuFn = createDefu((object, key, currentValue) => {
  if (object[key] !== void 0 && typeof currentValue === "function") {
    object[key] = currentValue(object[key]);
    return true;
  }
});

function o(n){throw new Error(`${n} is not implemented yet!`)}let i$1 = class i extends EventEmitter{__unenv__={};readableEncoding=null;readableEnded=true;readableFlowing=false;readableHighWaterMark=0;readableLength=0;readableObjectMode=false;readableAborted=false;readableDidRead=false;closed=false;errored=null;readable=false;destroyed=false;static from(e,t){return new i(t)}constructor(e){super();}_read(e){}read(e){}setEncoding(e){return this}pause(){return this}resume(){return this}isPaused(){return  true}unpipe(e){return this}unshift(e,t){}wrap(e){return this}push(e,t){return  false}_destroy(e,t){this.removeAllListeners();}destroy(e){return this.destroyed=true,this._destroy(e),this}pipe(e,t){return {}}compose(e,t){throw new Error("Method not implemented.")}[Symbol.asyncDispose](){return this.destroy(),Promise.resolve()}async*[Symbol.asyncIterator](){throw o("Readable.asyncIterator")}iterator(e){throw o("Readable.iterator")}map(e,t){throw o("Readable.map")}filter(e,t){throw o("Readable.filter")}forEach(e,t){throw o("Readable.forEach")}reduce(e,t,r){throw o("Readable.reduce")}find(e,t){throw o("Readable.find")}findIndex(e,t){throw o("Readable.findIndex")}some(e,t){throw o("Readable.some")}toArray(e){throw o("Readable.toArray")}every(e,t){throw o("Readable.every")}flatMap(e,t){throw o("Readable.flatMap")}drop(e,t){throw o("Readable.drop")}take(e,t){throw o("Readable.take")}asIndexedPairs(e){throw o("Readable.asIndexedPairs")}};let l$1 = class l extends EventEmitter{__unenv__={};writable=true;writableEnded=false;writableFinished=false;writableHighWaterMark=0;writableLength=0;writableObjectMode=false;writableCorked=0;closed=false;errored=null;writableNeedDrain=false;writableAborted=false;destroyed=false;_data;_encoding="utf8";constructor(e){super();}pipe(e,t){return {}}_write(e,t,r){if(this.writableEnded){r&&r();return}if(this._data===void 0)this._data=e;else {const s=typeof this._data=="string"?Buffer$1.from(this._data,this._encoding||t||"utf8"):this._data,a=typeof e=="string"?Buffer$1.from(e,t||this._encoding||"utf8"):e;this._data=Buffer$1.concat([s,a]);}this._encoding=t,r&&r();}_writev(e,t){}_destroy(e,t){}_final(e){}write(e,t,r){const s=typeof t=="string"?this._encoding:"utf8",a=typeof t=="function"?t:typeof r=="function"?r:void 0;return this._write(e,s,a),true}setDefaultEncoding(e){return this}end(e,t,r){const s=typeof e=="function"?e:typeof t=="function"?t:typeof r=="function"?r:void 0;if(this.writableEnded)return s&&s(),this;const a=e===s?void 0:e;if(a){const u=t===s?void 0:t;this.write(a,u);}return this.writableEnded=true,this.writableFinished=true,this.emit("close"),this.emit("finish"),s&&s(),this}cork(){}uncork(){}destroy(e){return this.destroyed=true,delete this._data,this.removeAllListeners(),this}compose(e,t){throw new Error("Method not implemented.")}[Symbol.asyncDispose](){return Promise.resolve()}};const c=class{allowHalfOpen=true;_destroy;constructor(e=new i$1,t=new l$1){Object.assign(this,e),Object.assign(this,t),this._destroy=m(e._destroy,t._destroy);}};function _(){return Object.assign(c.prototype,i$1.prototype),Object.assign(c.prototype,l$1.prototype),c}function m(...n){return function(...e){for(const t of n)t(...e);}}const g=_();class A extends g{__unenv__={};bufferSize=0;bytesRead=0;bytesWritten=0;connecting=false;destroyed=false;pending=false;localAddress="";localPort=0;remoteAddress="";remoteFamily="";remotePort=0;autoSelectFamilyAttemptedAddresses=[];readyState="readOnly";constructor(e){super();}write(e,t,r){return  false}connect(e,t,r){return this}end(e,t,r){return this}setEncoding(e){return this}pause(){return this}resume(){return this}setTimeout(e,t){return this}setNoDelay(e){return this}setKeepAlive(e,t){return this}address(){return {}}unref(){return this}ref(){return this}destroySoon(){this.destroy();}resetAndDestroy(){const e=new Error("ERR_SOCKET_CLOSED");return e.code="ERR_SOCKET_CLOSED",this.destroy(e),this}}class y extends i$1{aborted=false;httpVersion="1.1";httpVersionMajor=1;httpVersionMinor=1;complete=true;connection;socket;headers={};trailers={};method="GET";url="/";statusCode=200;statusMessage="";closed=false;errored=null;readable=false;constructor(e){super(),this.socket=this.connection=e||new A;}get rawHeaders(){const e=this.headers,t=[];for(const r in e)if(Array.isArray(e[r]))for(const s of e[r])t.push(r,s);else t.push(r,e[r]);return t}get rawTrailers(){return []}setTimeout(e,t){return this}get headersDistinct(){return p(this.headers)}get trailersDistinct(){return p(this.trailers)}}function p(n){const e={};for(const[t,r]of Object.entries(n))t&&(e[t]=(Array.isArray(r)?r:[r]).filter(Boolean));return e}class w extends l$1{statusCode=200;statusMessage="";upgrading=false;chunkedEncoding=false;shouldKeepAlive=false;useChunkedEncodingByDefault=false;sendDate=false;finished=false;headersSent=false;strictContentLength=false;connection=null;socket=null;req;_headers={};constructor(e){super(),this.req=e;}assignSocket(e){e._httpMessage=this,this.socket=e,this.connection=e,this.emit("socket",e),this._flush();}_flush(){this.flushHeaders();}detachSocket(e){}writeContinue(e){}writeHead(e,t,r){e&&(this.statusCode=e),typeof t=="string"&&(this.statusMessage=t,t=void 0);const s=r||t;if(s&&!Array.isArray(s))for(const a in s)this.setHeader(a,s[a]);return this.headersSent=true,this}writeProcessing(){}setTimeout(e,t){return this}appendHeader(e,t){e=e.toLowerCase();const r=this._headers[e],s=[...Array.isArray(r)?r:[r],...Array.isArray(t)?t:[t]].filter(Boolean);return this._headers[e]=s.length>1?s:s[0],this}setHeader(e,t){return this._headers[e.toLowerCase()]=t,this}setHeaders(e){for(const[t,r]of Object.entries(e))this.setHeader(t,r);return this}getHeader(e){return this._headers[e.toLowerCase()]}getHeaders(){return this._headers}getHeaderNames(){return Object.keys(this._headers)}hasHeader(e){return e.toLowerCase()in this._headers}removeHeader(e){delete this._headers[e.toLowerCase()];}addTrailers(e){}flushHeaders(){}writeEarlyHints(e,t){typeof t=="function"&&t();}}const E=(()=>{const n=function(){};return n.prototype=Object.create(null),n})();function R(n={}){const e=new E,t=Array.isArray(n)||H(n)?n:Object.entries(n);for(const[r,s]of t)if(s){if(e[r]===void 0){e[r]=s;continue}e[r]=[...Array.isArray(e[r])?e[r]:[e[r]],...Array.isArray(s)?s:[s]];}return e}function H(n){return typeof n?.entries=="function"}function v(n={}){if(n instanceof Headers)return n;const e=new Headers;for(const[t,r]of Object.entries(n))if(r!==void 0){if(Array.isArray(r)){for(const s of r)e.append(t,String(s));continue}e.set(t,String(r));}return e}const S=new Set([101,204,205,304]);async function b(n,e){const t=new y,r=new w(t);t.url=e.url?.toString()||"/";let s;if(!t.url.startsWith("/")){const d=new URL(t.url);s=d.host,t.url=d.pathname+d.search+d.hash;}t.method=e.method||"GET",t.headers=R(e.headers||{}),t.headers.host||(t.headers.host=e.host||s||"localhost"),t.connection.encrypted=t.connection.encrypted||e.protocol==="https",t.body=e.body||null,t.__unenv__=e.context,await n(t,r);let a=r._data;(S.has(r.statusCode)||t.method.toUpperCase()==="HEAD")&&(a=null,delete r._headers["content-length"]);const u={status:r.statusCode,statusText:r.statusMessage,headers:r._headers,body:a};return t.destroy(),r.destroy(),u}async function C(n,e,t={}){try{const r=await b(n,{url:e,...t});return new Response(r.body,{status:r.status,statusText:r.statusText,headers:v(r.headers)})}catch(r){return new Response(r.toString(),{status:Number.parseInt(r.statusCode||r.code)||500,statusText:r.statusText})}}

function hasProp(obj, prop) {
  try {
    return prop in obj;
  } catch {
    return false;
  }
}

class H3Error extends Error {
  static __h3_error__ = true;
  statusCode = 500;
  fatal = false;
  unhandled = false;
  statusMessage;
  data;
  cause;
  constructor(message, opts = {}) {
    super(message, opts);
    if (opts.cause && !this.cause) {
      this.cause = opts.cause;
    }
  }
  toJSON() {
    const obj = {
      message: this.message,
      statusCode: sanitizeStatusCode(this.statusCode, 500)
    };
    if (this.statusMessage) {
      obj.statusMessage = sanitizeStatusMessage(this.statusMessage);
    }
    if (this.data !== void 0) {
      obj.data = this.data;
    }
    return obj;
  }
}
function createError$1(input) {
  if (typeof input === "string") {
    return new H3Error(input);
  }
  if (isError(input)) {
    return input;
  }
  const err = new H3Error(input.message ?? input.statusMessage ?? "", {
    cause: input.cause || input
  });
  if (hasProp(input, "stack")) {
    try {
      Object.defineProperty(err, "stack", {
        get() {
          return input.stack;
        }
      });
    } catch {
      try {
        err.stack = input.stack;
      } catch {
      }
    }
  }
  if (input.data) {
    err.data = input.data;
  }
  if (input.statusCode) {
    err.statusCode = sanitizeStatusCode(input.statusCode, err.statusCode);
  } else if (input.status) {
    err.statusCode = sanitizeStatusCode(input.status, err.statusCode);
  }
  if (input.statusMessage) {
    err.statusMessage = input.statusMessage;
  } else if (input.statusText) {
    err.statusMessage = input.statusText;
  }
  if (err.statusMessage) {
    const originalMessage = err.statusMessage;
    const sanitizedMessage = sanitizeStatusMessage(err.statusMessage);
    if (sanitizedMessage !== originalMessage) {
      console.warn(
        "[h3] Please prefer using `message` for longer error messages instead of `statusMessage`. In the future, `statusMessage` will be sanitized by default."
      );
    }
  }
  if (input.fatal !== void 0) {
    err.fatal = input.fatal;
  }
  if (input.unhandled !== void 0) {
    err.unhandled = input.unhandled;
  }
  return err;
}
function sendError(event, error, debug) {
  if (event.handled) {
    return;
  }
  const h3Error = isError(error) ? error : createError$1(error);
  const responseBody = {
    statusCode: h3Error.statusCode,
    statusMessage: h3Error.statusMessage,
    stack: [],
    data: h3Error.data
  };
  if (debug) {
    responseBody.stack = (h3Error.stack || "").split("\n").map((l) => l.trim());
  }
  if (event.handled) {
    return;
  }
  const _code = Number.parseInt(h3Error.statusCode);
  setResponseStatus(event, _code, h3Error.statusMessage);
  event.node.res.setHeader("content-type", MIMES.json);
  event.node.res.end(JSON.stringify(responseBody, void 0, 2));
}
function isError(input) {
  return input?.constructor?.__h3_error__ === true;
}

function getQuery(event) {
  return getQuery$1(event.path || "");
}
function isMethod(event, expected, allowHead) {
  if (typeof expected === "string") {
    if (event.method === expected) {
      return true;
    }
  } else if (expected.includes(event.method)) {
    return true;
  }
  return false;
}
function assertMethod(event, expected, allowHead) {
  if (!isMethod(event, expected)) {
    throw createError$1({
      statusCode: 405,
      statusMessage: "HTTP method is not allowed."
    });
  }
}
function getRequestHeaders(event) {
  const _headers = {};
  for (const key in event.node.req.headers) {
    const val = event.node.req.headers[key];
    _headers[key] = Array.isArray(val) ? val.filter(Boolean).join(", ") : val;
  }
  return _headers;
}
function getRequestHeader(event, name) {
  const headers = getRequestHeaders(event);
  const value = headers[name.toLowerCase()];
  return value;
}
function getRequestHost(event, opts = {}) {
  if (opts.xForwardedHost) {
    const _header = event.node.req.headers["x-forwarded-host"];
    const xForwardedHost = (_header || "").split(",").shift()?.trim();
    if (xForwardedHost) {
      return xForwardedHost;
    }
  }
  return event.node.req.headers.host || "localhost";
}
function getRequestProtocol(event, opts = {}) {
  if (opts.xForwardedProto !== false && event.node.req.headers["x-forwarded-proto"] === "https") {
    return "https";
  }
  return event.node.req.connection?.encrypted ? "https" : "http";
}
function getRequestURL(event, opts = {}) {
  const host = getRequestHost(event, opts);
  const protocol = getRequestProtocol(event, opts);
  const path = (event.node.req.originalUrl || event.path).replace(
    /^[/\\]+/g,
    "/"
  );
  return new URL(path, `${protocol}://${host}`);
}

const RawBodySymbol = Symbol.for("h3RawBody");
const PayloadMethods$1 = ["PATCH", "POST", "PUT", "DELETE"];
function readRawBody(event, encoding = "utf8") {
  assertMethod(event, PayloadMethods$1);
  const _rawBody = event._requestBody || event.web?.request?.body || event.node.req[RawBodySymbol] || event.node.req.rawBody || event.node.req.body;
  if (_rawBody) {
    const promise2 = Promise.resolve(_rawBody).then((_resolved) => {
      if (Buffer.isBuffer(_resolved)) {
        return _resolved;
      }
      if (typeof _resolved.pipeTo === "function") {
        return new Promise((resolve, reject) => {
          const chunks = [];
          _resolved.pipeTo(
            new WritableStream({
              write(chunk) {
                chunks.push(chunk);
              },
              close() {
                resolve(Buffer.concat(chunks));
              },
              abort(reason) {
                reject(reason);
              }
            })
          ).catch(reject);
        });
      } else if (typeof _resolved.pipe === "function") {
        return new Promise((resolve, reject) => {
          const chunks = [];
          _resolved.on("data", (chunk) => {
            chunks.push(chunk);
          }).on("end", () => {
            resolve(Buffer.concat(chunks));
          }).on("error", reject);
        });
      }
      if (_resolved.constructor === Object) {
        return Buffer.from(JSON.stringify(_resolved));
      }
      if (_resolved instanceof URLSearchParams) {
        return Buffer.from(_resolved.toString());
      }
      if (_resolved instanceof FormData) {
        return new Response(_resolved).bytes().then((uint8arr) => Buffer.from(uint8arr));
      }
      return Buffer.from(_resolved);
    });
    return encoding ? promise2.then((buff) => buff.toString(encoding)) : promise2;
  }
  if (!Number.parseInt(event.node.req.headers["content-length"] || "") && !/\bchunked\b/i.test(
    String(event.node.req.headers["transfer-encoding"] ?? "")
  )) {
    return Promise.resolve(void 0);
  }
  const promise = event.node.req[RawBodySymbol] = new Promise(
    (resolve, reject) => {
      const bodyData = [];
      event.node.req.on("error", (err) => {
        reject(err);
      }).on("data", (chunk) => {
        bodyData.push(chunk);
      }).on("end", () => {
        resolve(Buffer.concat(bodyData));
      });
    }
  );
  const result = encoding ? promise.then((buff) => buff.toString(encoding)) : promise;
  return result;
}
function getRequestWebStream(event) {
  if (!PayloadMethods$1.includes(event.method)) {
    return;
  }
  const bodyStream = event.web?.request?.body || event._requestBody;
  if (bodyStream) {
    return bodyStream;
  }
  const _hasRawBody = RawBodySymbol in event.node.req || "rawBody" in event.node.req || "body" in event.node.req || "__unenv__" in event.node.req;
  if (_hasRawBody) {
    return new ReadableStream({
      async start(controller) {
        const _rawBody = await readRawBody(event, false);
        if (_rawBody) {
          controller.enqueue(_rawBody);
        }
        controller.close();
      }
    });
  }
  return new ReadableStream({
    start: (controller) => {
      event.node.req.on("data", (chunk) => {
        controller.enqueue(chunk);
      });
      event.node.req.on("end", () => {
        controller.close();
      });
      event.node.req.on("error", (err) => {
        controller.error(err);
      });
    }
  });
}

function handleCacheHeaders(event, opts) {
  const cacheControls = ["public", ...opts.cacheControls || []];
  let cacheMatched = false;
  if (opts.maxAge !== void 0) {
    cacheControls.push(`max-age=${+opts.maxAge}`, `s-maxage=${+opts.maxAge}`);
  }
  if (opts.modifiedTime) {
    const modifiedTime = new Date(opts.modifiedTime);
    const ifModifiedSince = event.node.req.headers["if-modified-since"];
    event.node.res.setHeader("last-modified", modifiedTime.toUTCString());
    if (ifModifiedSince && new Date(ifModifiedSince) >= modifiedTime) {
      cacheMatched = true;
    }
  }
  if (opts.etag) {
    event.node.res.setHeader("etag", opts.etag);
    const ifNonMatch = event.node.req.headers["if-none-match"];
    if (ifNonMatch === opts.etag) {
      cacheMatched = true;
    }
  }
  event.node.res.setHeader("cache-control", cacheControls.join(", "));
  if (cacheMatched) {
    event.node.res.statusCode = 304;
    if (!event.handled) {
      event.node.res.end();
    }
    return true;
  }
  return false;
}

const MIMES = {
  html: "text/html",
  json: "application/json"
};

const DISALLOWED_STATUS_CHARS = /[^\u0009\u0020-\u007E]/g;
function sanitizeStatusMessage(statusMessage = "") {
  return statusMessage.replace(DISALLOWED_STATUS_CHARS, "");
}
function sanitizeStatusCode(statusCode, defaultStatusCode = 200) {
  if (!statusCode) {
    return defaultStatusCode;
  }
  if (typeof statusCode === "string") {
    statusCode = Number.parseInt(statusCode, 10);
  }
  if (statusCode < 100 || statusCode > 999) {
    return defaultStatusCode;
  }
  return statusCode;
}

function getDistinctCookieKey(name, opts) {
  return [name, opts.domain || "", opts.path || "/"].join(";");
}

function parseCookies(event) {
  return parse(event.node.req.headers.cookie || "");
}
function getCookie(event, name) {
  return parseCookies(event)[name];
}
function setCookie(event, name, value, serializeOptions = {}) {
  if (!serializeOptions.path) {
    serializeOptions = { path: "/", ...serializeOptions };
  }
  const newCookie = serialize$2(name, value, serializeOptions);
  const currentCookies = splitCookiesString(
    event.node.res.getHeader("set-cookie")
  );
  if (currentCookies.length === 0) {
    event.node.res.setHeader("set-cookie", newCookie);
    return;
  }
  const newCookieKey = getDistinctCookieKey(name, serializeOptions);
  event.node.res.removeHeader("set-cookie");
  for (const cookie of currentCookies) {
    const parsed = parseSetCookie(cookie);
    const key = getDistinctCookieKey(parsed.name, parsed);
    if (key === newCookieKey) {
      continue;
    }
    event.node.res.appendHeader("set-cookie", cookie);
  }
  event.node.res.appendHeader("set-cookie", newCookie);
}
function deleteCookie(event, name, serializeOptions) {
  setCookie(event, name, "", {
    ...serializeOptions,
    maxAge: 0
  });
}
function splitCookiesString(cookiesString) {
  if (Array.isArray(cookiesString)) {
    return cookiesString.flatMap((c) => splitCookiesString(c));
  }
  if (typeof cookiesString !== "string") {
    return [];
  }
  const cookiesStrings = [];
  let pos = 0;
  let start;
  let ch;
  let lastComma;
  let nextStart;
  let cookiesSeparatorFound;
  const skipWhitespace = () => {
    while (pos < cookiesString.length && /\s/.test(cookiesString.charAt(pos))) {
      pos += 1;
    }
    return pos < cookiesString.length;
  };
  const notSpecialChar = () => {
    ch = cookiesString.charAt(pos);
    return ch !== "=" && ch !== ";" && ch !== ",";
  };
  while (pos < cookiesString.length) {
    start = pos;
    cookiesSeparatorFound = false;
    while (skipWhitespace()) {
      ch = cookiesString.charAt(pos);
      if (ch === ",") {
        lastComma = pos;
        pos += 1;
        skipWhitespace();
        nextStart = pos;
        while (pos < cookiesString.length && notSpecialChar()) {
          pos += 1;
        }
        if (pos < cookiesString.length && cookiesString.charAt(pos) === "=") {
          cookiesSeparatorFound = true;
          pos = nextStart;
          cookiesStrings.push(cookiesString.slice(start, lastComma));
          start = pos;
        } else {
          pos = lastComma + 1;
        }
      } else {
        pos += 1;
      }
    }
    if (!cookiesSeparatorFound || pos >= cookiesString.length) {
      cookiesStrings.push(cookiesString.slice(start));
    }
  }
  return cookiesStrings;
}

const defer = typeof setImmediate === "undefined" ? (fn) => fn() : setImmediate;
function send(event, data, type) {
  if (type) {
    defaultContentType(event, type);
  }
  return new Promise((resolve) => {
    defer(() => {
      if (!event.handled) {
        event.node.res.end(data);
      }
      resolve();
    });
  });
}
function sendNoContent(event, code) {
  if (event.handled) {
    return;
  }
  if (!code && event.node.res.statusCode !== 200) {
    code = event.node.res.statusCode;
  }
  const _code = sanitizeStatusCode(code, 204);
  if (_code === 204) {
    event.node.res.removeHeader("content-length");
  }
  event.node.res.writeHead(_code);
  event.node.res.end();
}
function setResponseStatus(event, code, text) {
  if (code) {
    event.node.res.statusCode = sanitizeStatusCode(
      code,
      event.node.res.statusCode
    );
  }
  if (text) {
    event.node.res.statusMessage = sanitizeStatusMessage(text);
  }
}
function getResponseStatus(event) {
  return event.node.res.statusCode;
}
function defaultContentType(event, type) {
  if (type && event.node.res.statusCode !== 304 && !event.node.res.getHeader("content-type")) {
    event.node.res.setHeader("content-type", type);
  }
}
function sendRedirect(event, location, code = 302) {
  event.node.res.statusCode = sanitizeStatusCode(
    code,
    event.node.res.statusCode
  );
  event.node.res.setHeader("location", location);
  const encodedLoc = location.replace(/"/g, "%22");
  const html = `<!DOCTYPE html><html><head><meta http-equiv="refresh" content="0; url=${encodedLoc}"></head></html>`;
  return send(event, html, MIMES.html);
}
function getResponseHeader(event, name) {
  return event.node.res.getHeader(name);
}
function setResponseHeaders(event, headers) {
  for (const [name, value] of Object.entries(headers)) {
    event.node.res.setHeader(
      name,
      value
    );
  }
}
const setHeaders = setResponseHeaders;
function setResponseHeader(event, name, value) {
  event.node.res.setHeader(name, value);
}
const setHeader = setResponseHeader;
function appendResponseHeader(event, name, value) {
  let current = event.node.res.getHeader(name);
  if (!current) {
    event.node.res.setHeader(name, value);
    return;
  }
  if (!Array.isArray(current)) {
    current = [current.toString()];
  }
  event.node.res.setHeader(name, [...current, value]);
}
function removeResponseHeader(event, name) {
  return event.node.res.removeHeader(name);
}
function isStream(data) {
  if (!data || typeof data !== "object") {
    return false;
  }
  if (typeof data.pipe === "function") {
    if (typeof data._read === "function") {
      return true;
    }
    if (typeof data.abort === "function") {
      return true;
    }
  }
  if (typeof data.pipeTo === "function") {
    return true;
  }
  return false;
}
function isWebResponse(data) {
  return typeof Response !== "undefined" && data instanceof Response;
}
function sendStream(event, stream) {
  if (!stream || typeof stream !== "object") {
    throw new Error("[h3] Invalid stream provided.");
  }
  event.node.res._data = stream;
  if (!event.node.res.socket) {
    event._handled = true;
    return Promise.resolve();
  }
  if (hasProp(stream, "pipeTo") && typeof stream.pipeTo === "function") {
    return stream.pipeTo(
      new WritableStream({
        write(chunk) {
          event.node.res.write(chunk);
        }
      })
    ).then(() => {
      event.node.res.end();
    });
  }
  if (hasProp(stream, "pipe") && typeof stream.pipe === "function") {
    return new Promise((resolve, reject) => {
      stream.pipe(event.node.res);
      if (stream.on) {
        stream.on("end", () => {
          event.node.res.end();
          resolve();
        });
        stream.on("error", (error) => {
          reject(error);
        });
      }
      event.node.res.on("close", () => {
        if (stream.abort) {
          stream.abort();
        }
      });
    });
  }
  throw new Error("[h3] Invalid or incompatible stream provided.");
}
const noop = () => {
};
function writeEarlyHints(event, hints, cb = noop) {
  if (!event.node.res.socket) {
    cb();
    return;
  }
  if (typeof hints === "string" || Array.isArray(hints)) {
    hints = { link: hints };
  }
  if (hints.link) {
    hints.link = Array.isArray(hints.link) ? hints.link : hints.link.split(",");
  }
  const headers = Object.entries(hints).map(
    (e) => [e[0].toLowerCase(), e[1]]
  );
  if (headers.length === 0) {
    cb();
    return;
  }
  let hint = "HTTP/1.1 103 Early Hints";
  if (hints.link) {
    hint += `\r
Link: ${hints.link.join(", ")}`;
  }
  for (const [header, value] of headers) {
    if (header === "link") {
      continue;
    }
    hint += `\r
${header}: ${value}`;
  }
  if (event.node.res.socket) {
    event.node.res.socket.write(
      `${hint}\r
\r
`,
      "utf8",
      cb
    );
  } else {
    cb();
  }
}
function sendWebResponse(event, response) {
  for (const [key, value] of response.headers) {
    if (key === "set-cookie") {
      event.node.res.appendHeader(key, splitCookiesString(value));
    } else {
      event.node.res.setHeader(key, value);
    }
  }
  if (response.status) {
    event.node.res.statusCode = sanitizeStatusCode(
      response.status,
      event.node.res.statusCode
    );
  }
  if (response.statusText) {
    event.node.res.statusMessage = sanitizeStatusMessage(response.statusText);
  }
  if (response.redirected) {
    event.node.res.setHeader("location", response.url);
  }
  if (!response.body) {
    event.node.res.end();
    return;
  }
  return sendStream(event, response.body);
}

const PayloadMethods = /* @__PURE__ */ new Set(["PATCH", "POST", "PUT", "DELETE"]);
const ignoredHeaders = /* @__PURE__ */ new Set([
  "transfer-encoding",
  "accept-encoding",
  "connection",
  "keep-alive",
  "upgrade",
  "expect",
  "host",
  "accept"
]);
async function proxyRequest(event, target, opts = {}) {
  let body;
  let duplex;
  if (PayloadMethods.has(event.method)) {
    if (opts.streamRequest) {
      body = getRequestWebStream(event);
      duplex = "half";
    } else {
      body = await readRawBody(event, false).catch(() => void 0);
    }
  }
  const method = opts.fetchOptions?.method || event.method;
  const fetchHeaders = mergeHeaders$1(
    getProxyRequestHeaders(event, { host: target.startsWith("/") }),
    opts.fetchOptions?.headers,
    opts.headers
  );
  return sendProxy(event, target, {
    ...opts,
    fetchOptions: {
      method,
      body,
      duplex,
      ...opts.fetchOptions,
      headers: fetchHeaders
    }
  });
}
async function sendProxy(event, target, opts = {}) {
  let response;
  try {
    response = await _getFetch(opts.fetch)(target, {
      headers: opts.headers,
      ignoreResponseError: true,
      // make $ofetch.raw transparent
      ...opts.fetchOptions
    });
  } catch (error) {
    throw createError$1({
      status: 502,
      statusMessage: "Bad Gateway",
      cause: error
    });
  }
  event.node.res.statusCode = sanitizeStatusCode(
    response.status,
    event.node.res.statusCode
  );
  event.node.res.statusMessage = sanitizeStatusMessage(response.statusText);
  const cookies = [];
  for (const [key, value] of response.headers.entries()) {
    if (key === "content-encoding") {
      continue;
    }
    if (key === "content-length") {
      continue;
    }
    if (key === "set-cookie") {
      cookies.push(...splitCookiesString(value));
      continue;
    }
    event.node.res.setHeader(key, value);
  }
  if (cookies.length > 0) {
    event.node.res.setHeader(
      "set-cookie",
      cookies.map((cookie) => {
        if (opts.cookieDomainRewrite) {
          cookie = rewriteCookieProperty(
            cookie,
            opts.cookieDomainRewrite,
            "domain"
          );
        }
        if (opts.cookiePathRewrite) {
          cookie = rewriteCookieProperty(
            cookie,
            opts.cookiePathRewrite,
            "path"
          );
        }
        return cookie;
      })
    );
  }
  if (opts.onResponse) {
    await opts.onResponse(event, response);
  }
  if (response._data !== void 0) {
    return response._data;
  }
  if (event.handled) {
    return;
  }
  if (opts.sendStream === false) {
    const data = new Uint8Array(await response.arrayBuffer());
    return event.node.res.end(data);
  }
  if (response.body) {
    for await (const chunk of response.body) {
      event.node.res.write(chunk);
    }
  }
  return event.node.res.end();
}
function getProxyRequestHeaders(event, opts) {
  const headers = /* @__PURE__ */ Object.create(null);
  const reqHeaders = getRequestHeaders(event);
  for (const name in reqHeaders) {
    if (!ignoredHeaders.has(name) || name === "host" && opts?.host) {
      headers[name] = reqHeaders[name];
    }
  }
  return headers;
}
function fetchWithEvent(event, req, init, options) {
  return _getFetch(options?.fetch)(req, {
    ...init,
    context: init?.context || event.context,
    headers: {
      ...getProxyRequestHeaders(event, {
        host: typeof req === "string" && req.startsWith("/")
      }),
      ...init?.headers
    }
  });
}
function _getFetch(_fetch) {
  if (_fetch) {
    return _fetch;
  }
  if (globalThis.fetch) {
    return globalThis.fetch;
  }
  throw new Error(
    "fetch is not available. Try importing `node-fetch-native/polyfill` for Node.js."
  );
}
function rewriteCookieProperty(header, map, property) {
  const _map = typeof map === "string" ? { "*": map } : map;
  return header.replace(
    new RegExp(`(;\\s*${property}=)([^;]+)`, "gi"),
    (match, prefix, previousValue) => {
      let newValue;
      if (previousValue in _map) {
        newValue = _map[previousValue];
      } else if ("*" in _map) {
        newValue = _map["*"];
      } else {
        return match;
      }
      return newValue ? prefix + newValue : "";
    }
  );
}
function mergeHeaders$1(defaults, ...inputs) {
  const _inputs = inputs.filter(Boolean);
  if (_inputs.length === 0) {
    return defaults;
  }
  const merged = new Headers(defaults);
  for (const input of _inputs) {
    const entries = Array.isArray(input) ? input : typeof input.entries === "function" ? input.entries() : Object.entries(input);
    for (const [key, value] of entries) {
      if (value !== void 0) {
        merged.set(key, value);
      }
    }
  }
  return merged;
}

class H3Event {
  "__is_event__" = true;
  // Context
  node;
  // Node
  web;
  // Web
  context = {};
  // Shared
  // Request
  _method;
  _path;
  _headers;
  _requestBody;
  // Response
  _handled = false;
  // Hooks
  _onBeforeResponseCalled;
  _onAfterResponseCalled;
  constructor(req, res) {
    this.node = { req, res };
  }
  // --- Request ---
  get method() {
    if (!this._method) {
      this._method = (this.node.req.method || "GET").toUpperCase();
    }
    return this._method;
  }
  get path() {
    return this._path || this.node.req.url || "/";
  }
  get headers() {
    if (!this._headers) {
      this._headers = _normalizeNodeHeaders(this.node.req.headers);
    }
    return this._headers;
  }
  // --- Respoonse ---
  get handled() {
    return this._handled || this.node.res.writableEnded || this.node.res.headersSent;
  }
  respondWith(response) {
    return Promise.resolve(response).then(
      (_response) => sendWebResponse(this, _response)
    );
  }
  // --- Utils ---
  toString() {
    return `[${this.method}] ${this.path}`;
  }
  toJSON() {
    return this.toString();
  }
  // --- Deprecated ---
  /** @deprecated Please use `event.node.req` instead. */
  get req() {
    return this.node.req;
  }
  /** @deprecated Please use `event.node.res` instead. */
  get res() {
    return this.node.res;
  }
}
function isEvent(input) {
  return hasProp(input, "__is_event__");
}
function createEvent(req, res) {
  return new H3Event(req, res);
}
function _normalizeNodeHeaders(nodeHeaders) {
  const headers = new Headers();
  for (const [name, value] of Object.entries(nodeHeaders)) {
    if (Array.isArray(value)) {
      for (const item of value) {
        headers.append(name, item);
      }
    } else if (value) {
      headers.set(name, value);
    }
  }
  return headers;
}

function defineEventHandler(handler) {
  if (typeof handler === "function") {
    handler.__is_handler__ = true;
    return handler;
  }
  const _hooks = {
    onRequest: _normalizeArray(handler.onRequest),
    onBeforeResponse: _normalizeArray(handler.onBeforeResponse)
  };
  const _handler = (event) => {
    return _callHandler(event, handler.handler, _hooks);
  };
  _handler.__is_handler__ = true;
  _handler.__resolve__ = handler.handler.__resolve__;
  _handler.__websocket__ = handler.websocket;
  return _handler;
}
function _normalizeArray(input) {
  return input ? Array.isArray(input) ? input : [input] : void 0;
}
async function _callHandler(event, handler, hooks) {
  if (hooks.onRequest) {
    for (const hook of hooks.onRequest) {
      await hook(event);
      if (event.handled) {
        return;
      }
    }
  }
  const body = await handler(event);
  const response = { body };
  if (hooks.onBeforeResponse) {
    for (const hook of hooks.onBeforeResponse) {
      await hook(event, response);
    }
  }
  return response.body;
}
const eventHandler = defineEventHandler;
function isEventHandler(input) {
  return hasProp(input, "__is_handler__");
}
function toEventHandler(input, _, _route) {
  return input;
}
function defineLazyEventHandler(factory) {
  let _promise;
  let _resolved;
  const resolveHandler = () => {
    if (_resolved) {
      return Promise.resolve(_resolved);
    }
    if (!_promise) {
      _promise = Promise.resolve(factory()).then((r) => {
        const handler2 = r.default || r;
        if (typeof handler2 !== "function") {
          throw new TypeError(
            "Invalid lazy handler result. It should be a function:",
            handler2
          );
        }
        _resolved = { handler: toEventHandler(r.default || r) };
        return _resolved;
      });
    }
    return _promise;
  };
  const handler = eventHandler((event) => {
    if (_resolved) {
      return _resolved.handler(event);
    }
    return resolveHandler().then((r) => r.handler(event));
  });
  handler.__resolve__ = resolveHandler;
  return handler;
}
const lazyEventHandler = defineLazyEventHandler;

function createApp(options = {}) {
  const stack = [];
  const handler = createAppEventHandler(stack, options);
  const resolve = createResolver(stack);
  handler.__resolve__ = resolve;
  const getWebsocket = cachedFn(() => websocketOptions(resolve, options));
  const app = {
    // @ts-expect-error
    use: (arg1, arg2, arg3) => use(app, arg1, arg2, arg3),
    resolve,
    handler,
    stack,
    options,
    get websocket() {
      return getWebsocket();
    }
  };
  return app;
}
function use(app, arg1, arg2, arg3) {
  if (Array.isArray(arg1)) {
    for (const i of arg1) {
      use(app, i, arg2, arg3);
    }
  } else if (Array.isArray(arg2)) {
    for (const i of arg2) {
      use(app, arg1, i, arg3);
    }
  } else if (typeof arg1 === "string") {
    app.stack.push(
      normalizeLayer({ ...arg3, route: arg1, handler: arg2 })
    );
  } else if (typeof arg1 === "function") {
    app.stack.push(normalizeLayer({ ...arg2, handler: arg1 }));
  } else {
    app.stack.push(normalizeLayer({ ...arg1 }));
  }
  return app;
}
function createAppEventHandler(stack, options) {
  const spacing = options.debug ? 2 : void 0;
  return eventHandler(async (event) => {
    event.node.req.originalUrl = event.node.req.originalUrl || event.node.req.url || "/";
    const _rawReqUrl = event.node.req.url || "/";
    const _reqPath = _decodePath(event._path || _rawReqUrl);
    event._path = _reqPath;
    const _needsRawUrl = _reqPath !== _rawReqUrl;
    let _layerPath;
    if (options.onRequest) {
      await options.onRequest(event);
    }
    for (const layer of stack) {
      if (layer.route.length > 1) {
        if (!_reqPath.startsWith(layer.route)) {
          continue;
        }
        _layerPath = _reqPath.slice(layer.route.length) || "/";
      } else {
        _layerPath = _reqPath;
      }
      if (layer.match && !layer.match(_layerPath, event)) {
        continue;
      }
      event._path = _layerPath;
      event.node.req.url = _needsRawUrl ? layer.route.length > 1 ? _rawReqUrl.slice(layer.route.length) || "/" : _rawReqUrl : _layerPath;
      const val = await layer.handler(event);
      const _body = val === void 0 ? void 0 : await val;
      if (_body !== void 0) {
        const _response = { body: _body };
        if (options.onBeforeResponse) {
          event._onBeforeResponseCalled = true;
          await options.onBeforeResponse(event, _response);
        }
        await handleHandlerResponse(event, _response.body, spacing);
        if (options.onAfterResponse) {
          event._onAfterResponseCalled = true;
          await options.onAfterResponse(event, _response);
        }
        return;
      }
      if (event.handled) {
        if (options.onAfterResponse) {
          event._onAfterResponseCalled = true;
          await options.onAfterResponse(event, void 0);
        }
        return;
      }
    }
    if (!event.handled) {
      throw createError$1({
        statusCode: 404,
        statusMessage: `Cannot find any path matching ${event.path || "/"}.`
      });
    }
    if (options.onAfterResponse) {
      event._onAfterResponseCalled = true;
      await options.onAfterResponse(event, void 0);
    }
  });
}
function createResolver(stack) {
  return async (path) => {
    let _layerPath;
    for (const layer of stack) {
      if (layer.route === "/" && !layer.handler.__resolve__) {
        continue;
      }
      if (!path.startsWith(layer.route)) {
        continue;
      }
      _layerPath = path.slice(layer.route.length) || "/";
      if (layer.match && !layer.match(_layerPath, void 0)) {
        continue;
      }
      let res = { route: layer.route, handler: layer.handler };
      if (res.handler.__resolve__) {
        const _res = await res.handler.__resolve__(_layerPath);
        if (!_res) {
          continue;
        }
        res = {
          ...res,
          ..._res,
          route: joinURL(res.route || "/", _res.route || "/")
        };
      }
      return res;
    }
  };
}
function normalizeLayer(input) {
  let handler = input.handler;
  if (handler.handler) {
    handler = handler.handler;
  }
  if (input.lazy) {
    handler = lazyEventHandler(handler);
  } else if (!isEventHandler(handler)) {
    handler = toEventHandler(handler, void 0, input.route);
  }
  return {
    route: withoutTrailingSlash(input.route),
    match: input.match,
    handler
  };
}
function handleHandlerResponse(event, val, jsonSpace) {
  if (val === null) {
    return sendNoContent(event);
  }
  if (val) {
    if (isWebResponse(val)) {
      return sendWebResponse(event, val);
    }
    if (isStream(val)) {
      return sendStream(event, val);
    }
    if (val.buffer) {
      return send(event, val);
    }
    if (val.arrayBuffer && typeof val.arrayBuffer === "function") {
      return val.arrayBuffer().then((arrayBuffer) => {
        return send(event, Buffer.from(arrayBuffer), val.type);
      });
    }
    if (val instanceof Error) {
      throw createError$1(val);
    }
    if (typeof val.end === "function") {
      return true;
    }
  }
  const valType = typeof val;
  if (valType === "string") {
    return send(event, val, MIMES.html);
  }
  if (valType === "object" || valType === "boolean" || valType === "number") {
    return send(event, JSON.stringify(val, void 0, jsonSpace), MIMES.json);
  }
  if (valType === "bigint") {
    return send(event, val.toString(), MIMES.json);
  }
  throw createError$1({
    statusCode: 500,
    statusMessage: `[h3] Cannot send ${valType} as response.`
  });
}
function cachedFn(fn) {
  let cache;
  return () => {
    if (!cache) {
      cache = fn();
    }
    return cache;
  };
}
function _decodePath(url) {
  const qIndex = url.indexOf("?");
  const path = qIndex === -1 ? url : url.slice(0, qIndex);
  const query = qIndex === -1 ? "" : url.slice(qIndex);
  const decodedPath = path.includes("%25") ? decodePath(path.replace(/%25/g, "%2525")) : decodePath(path);
  return decodedPath + query;
}
function websocketOptions(evResolver, appOptions) {
  return {
    ...appOptions.websocket,
    async resolve(info) {
      const url = info.request?.url || info.url || "/";
      const { pathname } = typeof url === "string" ? parseURL(url) : url;
      const resolved = await evResolver(pathname);
      return resolved?.handler?.__websocket__ || {};
    }
  };
}

const RouterMethods = [
  "connect",
  "delete",
  "get",
  "head",
  "options",
  "post",
  "put",
  "trace",
  "patch"
];
function createRouter(opts = {}) {
  const _router = createRouter$1({});
  const routes = {};
  let _matcher;
  const router = {};
  const addRoute = (path, handler, method) => {
    let route = routes[path];
    if (!route) {
      routes[path] = route = { path, handlers: {} };
      _router.insert(path, route);
    }
    if (Array.isArray(method)) {
      for (const m of method) {
        addRoute(path, handler, m);
      }
    } else {
      route.handlers[method] = toEventHandler(handler);
    }
    return router;
  };
  router.use = router.add = (path, handler, method) => addRoute(path, handler, method || "all");
  for (const method of RouterMethods) {
    router[method] = (path, handle) => router.add(path, handle, method);
  }
  const matchHandler = (path = "/", method = "get") => {
    const qIndex = path.indexOf("?");
    if (qIndex !== -1) {
      path = path.slice(0, Math.max(0, qIndex));
    }
    const matched = _router.lookup(path);
    if (!matched || !matched.handlers) {
      return {
        error: createError$1({
          statusCode: 404,
          name: "Not Found",
          statusMessage: `Cannot find any route matching ${path || "/"}.`
        })
      };
    }
    let handler = matched.handlers[method] || matched.handlers.all;
    if (!handler) {
      if (!_matcher) {
        _matcher = toRouteMatcher(_router);
      }
      const _matches = _matcher.matchAll(path).reverse();
      for (const _match of _matches) {
        if (_match.handlers[method]) {
          handler = _match.handlers[method];
          matched.handlers[method] = matched.handlers[method] || handler;
          break;
        }
        if (_match.handlers.all) {
          handler = _match.handlers.all;
          matched.handlers.all = matched.handlers.all || handler;
          break;
        }
      }
    }
    if (!handler) {
      return {
        error: createError$1({
          statusCode: 405,
          name: "Method Not Allowed",
          statusMessage: `Method ${method} is not allowed on this route.`
        })
      };
    }
    return { matched, handler };
  };
  const isPreemptive = opts.preemptive || opts.preemtive;
  router.handler = eventHandler((event) => {
    const match = matchHandler(
      event.path,
      event.method.toLowerCase()
    );
    if ("error" in match) {
      if (isPreemptive) {
        throw match.error;
      } else {
        return;
      }
    }
    event.context.matchedRoute = match.matched;
    const params = match.matched.params || {};
    event.context.params = params;
    return Promise.resolve(match.handler(event)).then((res) => {
      if (res === void 0 && isPreemptive) {
        return null;
      }
      return res;
    });
  });
  router.handler.__resolve__ = async (path) => {
    path = withLeadingSlash(path);
    const match = matchHandler(path);
    if ("error" in match) {
      return;
    }
    let res = {
      route: match.matched.path,
      handler: match.handler
    };
    if (match.handler.__resolve__) {
      const _res = await match.handler.__resolve__(path);
      if (!_res) {
        return;
      }
      res = { ...res, ..._res };
    }
    return res;
  };
  return router;
}
function toNodeListener(app) {
  const toNodeHandle = async function(req, res) {
    const event = createEvent(req, res);
    try {
      await app.handler(event);
    } catch (_error) {
      const error = createError$1(_error);
      if (!isError(_error)) {
        error.unhandled = true;
      }
      setResponseStatus(event, error.statusCode, error.statusMessage);
      if (app.options.onError) {
        await app.options.onError(error, event);
      }
      if (event.handled) {
        return;
      }
      if (error.unhandled || error.fatal) {
        console.error("[h3]", error.fatal ? "[fatal]" : "[unhandled]", error);
      }
      if (app.options.onBeforeResponse && !event._onBeforeResponseCalled) {
        await app.options.onBeforeResponse(event, { body: error });
      }
      await sendError(event, error, !!app.options.debug);
      if (app.options.onAfterResponse && !event._onAfterResponseCalled) {
        await app.options.onAfterResponse(event, { body: error });
      }
    }
  };
  return toNodeHandle;
}

function flatHooks(configHooks, hooks = {}, parentName) {
  for (const key in configHooks) {
    const subHook = configHooks[key];
    const name = parentName ? `${parentName}:${key}` : key;
    if (typeof subHook === "object" && subHook !== null) {
      flatHooks(subHook, hooks, name);
    } else if (typeof subHook === "function") {
      hooks[name] = subHook;
    }
  }
  return hooks;
}
const defaultTask = { run: (function_) => function_() };
const _createTask = () => defaultTask;
const createTask = typeof console.createTask !== "undefined" ? console.createTask : _createTask;
function serialTaskCaller(hooks, args) {
  const name = args.shift();
  const task = createTask(name);
  return hooks.reduce(
    (promise, hookFunction) => promise.then(() => task.run(() => hookFunction(...args))),
    Promise.resolve()
  );
}
function parallelTaskCaller(hooks, args) {
  const name = args.shift();
  const task = createTask(name);
  return Promise.all(hooks.map((hook) => task.run(() => hook(...args))));
}
function callEachWith(callbacks, arg0) {
  for (const callback of [...callbacks]) {
    callback(arg0);
  }
}

class Hookable {
  constructor() {
    this._hooks = {};
    this._before = void 0;
    this._after = void 0;
    this._deprecatedMessages = void 0;
    this._deprecatedHooks = {};
    this.hook = this.hook.bind(this);
    this.callHook = this.callHook.bind(this);
    this.callHookWith = this.callHookWith.bind(this);
  }
  hook(name, function_, options = {}) {
    if (!name || typeof function_ !== "function") {
      return () => {
      };
    }
    const originalName = name;
    let dep;
    while (this._deprecatedHooks[name]) {
      dep = this._deprecatedHooks[name];
      name = dep.to;
    }
    if (dep && !options.allowDeprecated) {
      let message = dep.message;
      if (!message) {
        message = `${originalName} hook has been deprecated` + (dep.to ? `, please use ${dep.to}` : "");
      }
      if (!this._deprecatedMessages) {
        this._deprecatedMessages = /* @__PURE__ */ new Set();
      }
      if (!this._deprecatedMessages.has(message)) {
        console.warn(message);
        this._deprecatedMessages.add(message);
      }
    }
    if (!function_.name) {
      try {
        Object.defineProperty(function_, "name", {
          get: () => "_" + name.replace(/\W+/g, "_") + "_hook_cb",
          configurable: true
        });
      } catch {
      }
    }
    this._hooks[name] = this._hooks[name] || [];
    this._hooks[name].push(function_);
    return () => {
      if (function_) {
        this.removeHook(name, function_);
        function_ = void 0;
      }
    };
  }
  hookOnce(name, function_) {
    let _unreg;
    let _function = (...arguments_) => {
      if (typeof _unreg === "function") {
        _unreg();
      }
      _unreg = void 0;
      _function = void 0;
      return function_(...arguments_);
    };
    _unreg = this.hook(name, _function);
    return _unreg;
  }
  removeHook(name, function_) {
    if (this._hooks[name]) {
      const index = this._hooks[name].indexOf(function_);
      if (index !== -1) {
        this._hooks[name].splice(index, 1);
      }
      if (this._hooks[name].length === 0) {
        delete this._hooks[name];
      }
    }
  }
  deprecateHook(name, deprecated) {
    this._deprecatedHooks[name] = typeof deprecated === "string" ? { to: deprecated } : deprecated;
    const _hooks = this._hooks[name] || [];
    delete this._hooks[name];
    for (const hook of _hooks) {
      this.hook(name, hook);
    }
  }
  deprecateHooks(deprecatedHooks) {
    Object.assign(this._deprecatedHooks, deprecatedHooks);
    for (const name in deprecatedHooks) {
      this.deprecateHook(name, deprecatedHooks[name]);
    }
  }
  addHooks(configHooks) {
    const hooks = flatHooks(configHooks);
    const removeFns = Object.keys(hooks).map(
      (key) => this.hook(key, hooks[key])
    );
    return () => {
      for (const unreg of removeFns.splice(0, removeFns.length)) {
        unreg();
      }
    };
  }
  removeHooks(configHooks) {
    const hooks = flatHooks(configHooks);
    for (const key in hooks) {
      this.removeHook(key, hooks[key]);
    }
  }
  removeAllHooks() {
    for (const key in this._hooks) {
      delete this._hooks[key];
    }
  }
  callHook(name, ...arguments_) {
    arguments_.unshift(name);
    return this.callHookWith(serialTaskCaller, name, ...arguments_);
  }
  callHookParallel(name, ...arguments_) {
    arguments_.unshift(name);
    return this.callHookWith(parallelTaskCaller, name, ...arguments_);
  }
  callHookWith(caller, name, ...arguments_) {
    const event = this._before || this._after ? { name, args: arguments_, context: {} } : void 0;
    if (this._before) {
      callEachWith(this._before, event);
    }
    const result = caller(
      name in this._hooks ? [...this._hooks[name]] : [],
      arguments_
    );
    if (result instanceof Promise) {
      return result.finally(() => {
        if (this._after && event) {
          callEachWith(this._after, event);
        }
      });
    }
    if (this._after && event) {
      callEachWith(this._after, event);
    }
    return result;
  }
  beforeEach(function_) {
    this._before = this._before || [];
    this._before.push(function_);
    return () => {
      if (this._before !== void 0) {
        const index = this._before.indexOf(function_);
        if (index !== -1) {
          this._before.splice(index, 1);
        }
      }
    };
  }
  afterEach(function_) {
    this._after = this._after || [];
    this._after.push(function_);
    return () => {
      if (this._after !== void 0) {
        const index = this._after.indexOf(function_);
        if (index !== -1) {
          this._after.splice(index, 1);
        }
      }
    };
  }
}
function createHooks() {
  return new Hookable();
}

const s=globalThis.Headers,i=globalThis.AbortController,l=globalThis.fetch||(()=>{throw new Error("[node-fetch-native] Failed to fetch: `globalThis.fetch` is not available!")});

class FetchError extends Error {
  constructor(message, opts) {
    super(message, opts);
    this.name = "FetchError";
    if (opts?.cause && !this.cause) {
      this.cause = opts.cause;
    }
  }
}
function createFetchError(ctx) {
  const errorMessage = ctx.error?.message || ctx.error?.toString() || "";
  const method = ctx.request?.method || ctx.options?.method || "GET";
  const url = ctx.request?.url || String(ctx.request) || "/";
  const requestStr = `[${method}] ${JSON.stringify(url)}`;
  const statusStr = ctx.response ? `${ctx.response.status} ${ctx.response.statusText}` : "<no response>";
  const message = `${requestStr}: ${statusStr}${errorMessage ? ` ${errorMessage}` : ""}`;
  const fetchError = new FetchError(
    message,
    ctx.error ? { cause: ctx.error } : void 0
  );
  for (const key of ["request", "options", "response"]) {
    Object.defineProperty(fetchError, key, {
      get() {
        return ctx[key];
      }
    });
  }
  for (const [key, refKey] of [
    ["data", "_data"],
    ["status", "status"],
    ["statusCode", "status"],
    ["statusText", "statusText"],
    ["statusMessage", "statusText"]
  ]) {
    Object.defineProperty(fetchError, key, {
      get() {
        return ctx.response && ctx.response[refKey];
      }
    });
  }
  return fetchError;
}

const payloadMethods = new Set(
  Object.freeze(["PATCH", "POST", "PUT", "DELETE"])
);
function isPayloadMethod(method = "GET") {
  return payloadMethods.has(method.toUpperCase());
}
function isJSONSerializable(value) {
  if (value === void 0) {
    return false;
  }
  const t = typeof value;
  if (t === "string" || t === "number" || t === "boolean" || t === null) {
    return true;
  }
  if (t !== "object") {
    return false;
  }
  if (Array.isArray(value)) {
    return true;
  }
  if (value.buffer) {
    return false;
  }
  if (value instanceof FormData || value instanceof URLSearchParams) {
    return false;
  }
  return value.constructor && value.constructor.name === "Object" || typeof value.toJSON === "function";
}
const textTypes = /* @__PURE__ */ new Set([
  "image/svg",
  "application/xml",
  "application/xhtml",
  "application/html"
]);
const JSON_RE = /^application\/(?:[\w!#$%&*.^`~-]*\+)?json(;.+)?$/i;
function detectResponseType(_contentType = "") {
  if (!_contentType) {
    return "json";
  }
  const contentType = _contentType.split(";").shift() || "";
  if (JSON_RE.test(contentType)) {
    return "json";
  }
  if (contentType === "text/event-stream") {
    return "stream";
  }
  if (textTypes.has(contentType) || contentType.startsWith("text/")) {
    return "text";
  }
  return "blob";
}
function resolveFetchOptions(request, input, defaults, Headers) {
  const headers = mergeHeaders(
    input?.headers ?? request?.headers,
    defaults?.headers,
    Headers
  );
  let query;
  if (defaults?.query || defaults?.params || input?.params || input?.query) {
    query = {
      ...defaults?.params,
      ...defaults?.query,
      ...input?.params,
      ...input?.query
    };
  }
  return {
    ...defaults,
    ...input,
    query,
    params: query,
    headers
  };
}
function mergeHeaders(input, defaults, Headers) {
  if (!defaults) {
    return new Headers(input);
  }
  const headers = new Headers(defaults);
  if (input) {
    for (const [key, value] of Symbol.iterator in input || Array.isArray(input) ? input : new Headers(input)) {
      headers.set(key, value);
    }
  }
  return headers;
}
async function callHooks(context, hooks) {
  if (hooks) {
    if (Array.isArray(hooks)) {
      for (const hook of hooks) {
        await hook(context);
      }
    } else {
      await hooks(context);
    }
  }
}

const retryStatusCodes = /* @__PURE__ */ new Set([
  408,
  // Request Timeout
  409,
  // Conflict
  425,
  // Too Early (Experimental)
  429,
  // Too Many Requests
  500,
  // Internal Server Error
  502,
  // Bad Gateway
  503,
  // Service Unavailable
  504
  // Gateway Timeout
]);
const nullBodyResponses = /* @__PURE__ */ new Set([101, 204, 205, 304]);
function createFetch(globalOptions = {}) {
  const {
    fetch = globalThis.fetch,
    Headers = globalThis.Headers,
    AbortController = globalThis.AbortController
  } = globalOptions;
  async function onError(context) {
    const isAbort = context.error && context.error.name === "AbortError" && !context.options.timeout || false;
    if (context.options.retry !== false && !isAbort) {
      let retries;
      if (typeof context.options.retry === "number") {
        retries = context.options.retry;
      } else {
        retries = isPayloadMethod(context.options.method) ? 0 : 1;
      }
      const responseCode = context.response && context.response.status || 500;
      if (retries > 0 && (Array.isArray(context.options.retryStatusCodes) ? context.options.retryStatusCodes.includes(responseCode) : retryStatusCodes.has(responseCode))) {
        const retryDelay = typeof context.options.retryDelay === "function" ? context.options.retryDelay(context) : context.options.retryDelay || 0;
        if (retryDelay > 0) {
          await new Promise((resolve) => setTimeout(resolve, retryDelay));
        }
        return $fetchRaw(context.request, {
          ...context.options,
          retry: retries - 1
        });
      }
    }
    const error = createFetchError(context);
    if (Error.captureStackTrace) {
      Error.captureStackTrace(error, $fetchRaw);
    }
    throw error;
  }
  const $fetchRaw = async function $fetchRaw2(_request, _options = {}) {
    const context = {
      request: _request,
      options: resolveFetchOptions(
        _request,
        _options,
        globalOptions.defaults,
        Headers
      ),
      response: void 0,
      error: void 0
    };
    if (context.options.method) {
      context.options.method = context.options.method.toUpperCase();
    }
    if (context.options.onRequest) {
      await callHooks(context, context.options.onRequest);
      if (!(context.options.headers instanceof Headers)) {
        context.options.headers = new Headers(
          context.options.headers || {}
          /* compat */
        );
      }
    }
    if (typeof context.request === "string") {
      if (context.options.baseURL) {
        context.request = withBase(context.request, context.options.baseURL);
      }
      if (context.options.query) {
        context.request = withQuery(context.request, context.options.query);
        delete context.options.query;
      }
      if ("query" in context.options) {
        delete context.options.query;
      }
      if ("params" in context.options) {
        delete context.options.params;
      }
    }
    if (context.options.body && isPayloadMethod(context.options.method)) {
      if (isJSONSerializable(context.options.body)) {
        const contentType = context.options.headers.get("content-type");
        if (typeof context.options.body !== "string") {
          context.options.body = contentType === "application/x-www-form-urlencoded" ? new URLSearchParams(
            context.options.body
          ).toString() : JSON.stringify(context.options.body);
        }
        if (!contentType) {
          context.options.headers.set("content-type", "application/json");
        }
        if (!context.options.headers.has("accept")) {
          context.options.headers.set("accept", "application/json");
        }
      } else if (
        // ReadableStream Body
        "pipeTo" in context.options.body && typeof context.options.body.pipeTo === "function" || // Node.js Stream Body
        typeof context.options.body.pipe === "function"
      ) {
        if (!("duplex" in context.options)) {
          context.options.duplex = "half";
        }
      }
    }
    let abortTimeout;
    if (!context.options.signal && context.options.timeout) {
      const controller = new AbortController();
      abortTimeout = setTimeout(() => {
        const error = new Error(
          "[TimeoutError]: The operation was aborted due to timeout"
        );
        error.name = "TimeoutError";
        error.code = 23;
        controller.abort(error);
      }, context.options.timeout);
      context.options.signal = controller.signal;
    }
    try {
      context.response = await fetch(
        context.request,
        context.options
      );
    } catch (error) {
      context.error = error;
      if (context.options.onRequestError) {
        await callHooks(
          context,
          context.options.onRequestError
        );
      }
      return await onError(context);
    } finally {
      if (abortTimeout) {
        clearTimeout(abortTimeout);
      }
    }
    const hasBody = (context.response.body || // https://github.com/unjs/ofetch/issues/324
    // https://github.com/unjs/ofetch/issues/294
    // https://github.com/JakeChampion/fetch/issues/1454
    context.response._bodyInit) && !nullBodyResponses.has(context.response.status) && context.options.method !== "HEAD";
    if (hasBody) {
      const responseType = (context.options.parseResponse ? "json" : context.options.responseType) || detectResponseType(context.response.headers.get("content-type") || "");
      switch (responseType) {
        case "json": {
          const data = await context.response.text();
          const parseFunction = context.options.parseResponse || destr;
          context.response._data = parseFunction(data);
          break;
        }
        case "stream": {
          context.response._data = context.response.body || context.response._bodyInit;
          break;
        }
        default: {
          context.response._data = await context.response[responseType]();
        }
      }
    }
    if (context.options.onResponse) {
      await callHooks(
        context,
        context.options.onResponse
      );
    }
    if (!context.options.ignoreResponseError && context.response.status >= 400 && context.response.status < 600) {
      if (context.options.onResponseError) {
        await callHooks(
          context,
          context.options.onResponseError
        );
      }
      return await onError(context);
    }
    return context.response;
  };
  const $fetch = async function $fetch2(request, options) {
    const r = await $fetchRaw(request, options);
    return r._data;
  };
  $fetch.raw = $fetchRaw;
  $fetch.native = (...args) => fetch(...args);
  $fetch.create = (defaultOptions = {}, customGlobalOptions = {}) => createFetch({
    ...globalOptions,
    ...customGlobalOptions,
    defaults: {
      ...globalOptions.defaults,
      ...customGlobalOptions.defaults,
      ...defaultOptions
    }
  });
  return $fetch;
}

function createNodeFetch() {
  const useKeepAlive = JSON.parse(process.env.FETCH_KEEP_ALIVE || "false");
  if (!useKeepAlive) {
    return l;
  }
  const agentOptions = { keepAlive: true };
  const httpAgent = new http.Agent(agentOptions);
  const httpsAgent = new https.Agent(agentOptions);
  const nodeFetchOptions = {
    agent(parsedURL) {
      return parsedURL.protocol === "http:" ? httpAgent : httpsAgent;
    }
  };
  return function nodeFetchWithKeepAlive(input, init) {
    return l(input, { ...nodeFetchOptions, ...init });
  };
}
const fetch = globalThis.fetch ? (...args) => globalThis.fetch(...args) : createNodeFetch();
const Headers$1 = globalThis.Headers || s;
const AbortController = globalThis.AbortController || i;
const ofetch = createFetch({ fetch, Headers: Headers$1, AbortController });
const $fetch = ofetch;

function wrapToPromise(value) {
  if (!value || typeof value.then !== "function") {
    return Promise.resolve(value);
  }
  return value;
}
function asyncCall(function_, ...arguments_) {
  try {
    return wrapToPromise(function_(...arguments_));
  } catch (error) {
    return Promise.reject(error);
  }
}
function isPrimitive(value) {
  const type = typeof value;
  return value === null || type !== "object" && type !== "function";
}
function isPureObject(value) {
  const proto = Object.getPrototypeOf(value);
  return !proto || proto.isPrototypeOf(Object);
}
function stringify(value) {
  if (isPrimitive(value)) {
    return String(value);
  }
  if (isPureObject(value) || Array.isArray(value)) {
    return JSON.stringify(value);
  }
  if (typeof value.toJSON === "function") {
    return stringify(value.toJSON());
  }
  throw new Error("[unstorage] Cannot stringify value!");
}
const BASE64_PREFIX = "base64:";
function serializeRaw(value) {
  if (typeof value === "string") {
    return value;
  }
  return BASE64_PREFIX + base64Encode(value);
}
function deserializeRaw(value) {
  if (typeof value !== "string") {
    return value;
  }
  if (!value.startsWith(BASE64_PREFIX)) {
    return value;
  }
  return base64Decode(value.slice(BASE64_PREFIX.length));
}
function base64Decode(input) {
  if (globalThis.Buffer) {
    return Buffer.from(input, "base64");
  }
  return Uint8Array.from(
    globalThis.atob(input),
    (c) => c.codePointAt(0)
  );
}
function base64Encode(input) {
  if (globalThis.Buffer) {
    return Buffer.from(input).toString("base64");
  }
  return globalThis.btoa(String.fromCodePoint(...input));
}

const storageKeyProperties = [
  "has",
  "hasItem",
  "get",
  "getItem",
  "getItemRaw",
  "set",
  "setItem",
  "setItemRaw",
  "del",
  "remove",
  "removeItem",
  "getMeta",
  "setMeta",
  "removeMeta",
  "getKeys",
  "clear",
  "mount",
  "unmount"
];
const nonItemKeyProperties = /* @__PURE__ */ new Set([
  "getKeys",
  "clear",
  "mount",
  "unmount"
]);
function prefixStorage(storage, base) {
  if (base?.includes("?")) {
    throw new Error(`[unstorage] Invalid base: ${JSON.stringify(base)}`);
  }
  base = normalizeBaseKey(base);
  if (!base) {
    return storage;
  }
  const itemKey = (key) => {
    if (!normalizeKey$1(key)) {
      throw new Error(`[unstorage] Invalid key: ${JSON.stringify(key)}`);
    }
    return base + key;
  };
  const nsStorage = { ...storage };
  for (const property of storageKeyProperties) {
    nsStorage[property] = nonItemKeyProperties.has(property) ? (key = "", ...args) => (
      // @ts-ignore
      storage[property](base + key, ...args)
    ) : async (key = "", ...args) => (
      // @ts-ignore
      storage[property](itemKey(key), ...args)
    );
  }
  nsStorage.getKeys = (key = "", ...arguments_) => storage.getKeys(base + key, ...arguments_).then((keys) => keys.map((key2) => key2.slice(base.length)));
  nsStorage.keys = nsStorage.getKeys;
  nsStorage.getItems = async (items, commonOptions) => {
    const prefixedItems = items.map(
      (item) => typeof item === "string" ? itemKey(item) : { ...item, key: itemKey(item.key) }
    );
    const results = await storage.getItems(prefixedItems, commonOptions);
    return results.map((entry) => ({
      key: entry.key.slice(base.length),
      value: entry.value
    }));
  };
  nsStorage.setItems = async (items, commonOptions) => {
    const prefixedItems = items.map((item) => ({
      key: itemKey(item.key),
      value: item.value,
      options: item.options
    }));
    return storage.setItems(prefixedItems, commonOptions);
  };
  return nsStorage;
}
function normalizeKey$1(key) {
  if (!key) {
    return "";
  }
  return key.split("?")[0]?.replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "") || "";
}
function hasDotSegment(key) {
  return key.split(":").some((segment) => segment === "." || segment === "..");
}
function joinKeys(...keys) {
  return normalizeKey$1(keys.join(":"));
}
function normalizeBaseKey(base) {
  base = normalizeKey$1(base);
  return base ? base + ":" : "";
}
function filterKeyByDepth(key, depth) {
  if (depth === void 0) {
    return true;
  }
  let substrCount = 0;
  let index = key.indexOf(":");
  while (index > -1) {
    substrCount++;
    index = key.indexOf(":", index + 1);
  }
  return substrCount <= depth;
}
function filterKeyByBase(key, base) {
  if (base) {
    return key.startsWith(base) && key[key.length - 1] !== "$";
  }
  return key[key.length - 1] !== "$";
}

function defineDriver$1(factory) {
  return factory;
}

const DRIVER_NAME$1 = "memory";
const memory = defineDriver$1(() => {
  const data = /* @__PURE__ */ new Map();
  return {
    name: DRIVER_NAME$1,
    getInstance: () => data,
    hasItem(key) {
      return data.has(key);
    },
    getItem(key) {
      return data.get(key) ?? null;
    },
    getItemRaw(key) {
      return data.get(key) ?? null;
    },
    setItem(key, value) {
      data.set(key, value);
    },
    setItemRaw(key, value) {
      data.set(key, value);
    },
    removeItem(key) {
      data.delete(key);
    },
    getKeys() {
      return [...data.keys()];
    },
    clear() {
      data.clear();
    },
    dispose() {
      data.clear();
    }
  };
});

function createStorage(options = {}) {
  const context = {
    mounts: { "": options.driver || memory() },
    mountpoints: [""],
    watching: false,
    watchListeners: [],
    unwatch: {}
  };
  const normalizeItemKey = (key) => {
    const normalizedKey = normalizeKey$1(key);
    if (!normalizedKey || hasDotSegment(normalizedKey)) {
      throw new Error(`[unstorage] Invalid key: ${JSON.stringify(key)}`);
    }
    return normalizedKey;
  };
  const normalizeBase = (base) => {
    const normalizedBase = normalizeBaseKey(base);
    if (hasDotSegment(normalizedBase)) {
      throw new Error(`[unstorage] Invalid base: ${JSON.stringify(base)}`);
    }
    return normalizedBase;
  };
  const getMount = (key) => {
    for (const base of context.mountpoints) {
      if (key.startsWith(base)) {
        return {
          base,
          relativeKey: key.slice(base.length),
          driver: context.mounts[base]
        };
      }
    }
    return {
      base: "",
      relativeKey: key,
      driver: context.mounts[""]
    };
  };
  const getMounts = (base, includeParent) => {
    return context.mountpoints.filter(
      (mountpoint) => mountpoint.startsWith(base) || includeParent && base.startsWith(mountpoint)
    ).map((mountpoint) => ({
      relativeBase: base.length > mountpoint.length ? base.slice(mountpoint.length) : void 0,
      mountpoint,
      driver: context.mounts[mountpoint]
    }));
  };
  const onChange = (event, key) => {
    if (!context.watching) {
      return;
    }
    key = normalizeKey$1(key);
    for (const listener of context.watchListeners) {
      listener(event, key);
    }
  };
  const startWatch = async () => {
    if (context.watching) {
      return;
    }
    context.watching = true;
    for (const mountpoint in context.mounts) {
      context.unwatch[mountpoint] = await watch(
        context.mounts[mountpoint],
        onChange,
        mountpoint
      );
    }
  };
  const stopWatch = async () => {
    if (!context.watching) {
      return;
    }
    for (const mountpoint in context.unwatch) {
      await context.unwatch[mountpoint]();
    }
    context.unwatch = {};
    context.watching = false;
  };
  const runBatch = (items, commonOptions, cb) => {
    const batches = /* @__PURE__ */ new Map();
    const getBatch = (mount) => {
      let batch = batches.get(mount.base);
      if (!batch) {
        batch = {
          driver: mount.driver,
          base: mount.base,
          items: []
        };
        batches.set(mount.base, batch);
      }
      return batch;
    };
    for (const item of items) {
      const isStringItem = typeof item === "string";
      const key = normalizeItemKey(isStringItem ? item : item.key);
      const value = isStringItem ? void 0 : item.value;
      const options2 = isStringItem || !item.options ? commonOptions : { ...commonOptions, ...item.options };
      const mount = getMount(key);
      getBatch(mount).items.push({
        key,
        value,
        relativeKey: mount.relativeKey,
        options: options2
      });
    }
    return Promise.all([...batches.values()].map((batch) => cb(batch))).then(
      (r) => r.flat()
    );
  };
  const storage = {
    // Item
    async hasItem(key, opts = {}) {
      key = normalizeItemKey(key);
      const { relativeKey, driver } = getMount(key);
      return asyncCall(driver.hasItem, relativeKey, opts);
    },
    async getItem(key, opts = {}) {
      key = normalizeItemKey(key);
      const { relativeKey, driver } = getMount(key);
      return asyncCall(driver.getItem, relativeKey, opts).then(
        (value) => destr(value)
      );
    },
    async getItems(items, commonOptions = {}) {
      return runBatch(items, commonOptions, (batch) => {
        if (batch.driver.getItems) {
          return asyncCall(
            batch.driver.getItems,
            batch.items.map((item) => ({
              key: item.relativeKey,
              options: item.options
            })),
            commonOptions
          ).then(
            (r) => r.map((item) => ({
              key: joinKeys(batch.base, item.key),
              value: destr(item.value)
            }))
          );
        }
        return Promise.all(
          batch.items.map((item) => {
            return asyncCall(
              batch.driver.getItem,
              item.relativeKey,
              item.options
            ).then((value) => ({
              key: item.key,
              value: destr(value)
            }));
          })
        );
      });
    },
    async getItemRaw(key, opts = {}) {
      key = normalizeItemKey(key);
      const { relativeKey, driver } = getMount(key);
      if (driver.getItemRaw) {
        return asyncCall(driver.getItemRaw, relativeKey, opts);
      }
      return asyncCall(driver.getItem, relativeKey, opts).then(
        (value) => deserializeRaw(value)
      );
    },
    async setItem(key, value, opts = {}) {
      if (value === void 0) {
        return storage.removeItem(key);
      }
      key = normalizeItemKey(key);
      const { relativeKey, driver } = getMount(key);
      if (!driver.setItem) {
        return;
      }
      await asyncCall(driver.setItem, relativeKey, stringify(value), opts);
      if (!driver.watch) {
        onChange("update", key);
      }
    },
    async setItems(items, commonOptions) {
      await runBatch(items, commonOptions, async (batch) => {
        if (batch.driver.setItems) {
          return asyncCall(
            batch.driver.setItems,
            batch.items.map((item) => ({
              key: item.relativeKey,
              value: stringify(item.value),
              options: item.options
            })),
            commonOptions
          );
        }
        if (!batch.driver.setItem) {
          return;
        }
        await Promise.all(
          batch.items.map((item) => {
            return asyncCall(
              batch.driver.setItem,
              item.relativeKey,
              stringify(item.value),
              item.options
            );
          })
        );
      });
    },
    async setItemRaw(key, value, opts = {}) {
      if (value === void 0) {
        return storage.removeItem(key, opts);
      }
      key = normalizeItemKey(key);
      const { relativeKey, driver } = getMount(key);
      if (driver.setItemRaw) {
        await asyncCall(driver.setItemRaw, relativeKey, value, opts);
      } else if (driver.setItem) {
        await asyncCall(driver.setItem, relativeKey, serializeRaw(value), opts);
      } else {
        return;
      }
      if (!driver.watch) {
        onChange("update", key);
      }
    },
    async removeItem(key, opts = {}) {
      if (typeof opts === "boolean") {
        opts = { removeMeta: opts };
      }
      key = normalizeItemKey(key);
      const { relativeKey, driver } = getMount(key);
      if (!driver.removeItem) {
        return;
      }
      await asyncCall(driver.removeItem, relativeKey, opts);
      if (opts.removeMeta || opts.removeMata) {
        await asyncCall(driver.removeItem, relativeKey + "$", opts);
      }
      if (!driver.watch) {
        onChange("remove", key);
      }
    },
    // Meta
    async getMeta(key, opts = {}) {
      if (typeof opts === "boolean") {
        opts = { nativeOnly: opts };
      }
      key = normalizeItemKey(key);
      const { relativeKey, driver } = getMount(key);
      const meta = /* @__PURE__ */ Object.create(null);
      if (driver.getMeta) {
        Object.assign(meta, await asyncCall(driver.getMeta, relativeKey, opts));
      }
      if (!opts.nativeOnly) {
        const value = await asyncCall(
          driver.getItem,
          relativeKey + "$",
          opts
        ).then((value_) => destr(value_));
        if (value && typeof value === "object") {
          if (typeof value.atime === "string") {
            value.atime = new Date(value.atime);
          }
          if (typeof value.mtime === "string") {
            value.mtime = new Date(value.mtime);
          }
          Object.assign(meta, value);
        }
      }
      return meta;
    },
    async setMeta(key, value, opts = {}) {
      return this.setItem(normalizeItemKey(key) + "$", value, opts);
    },
    async removeMeta(key, opts = {}) {
      return this.removeItem(normalizeItemKey(key) + "$", opts);
    },
    // Keys
    async getKeys(base, opts = {}) {
      base = normalizeBase(base);
      const mounts = getMounts(base, true);
      let maskedMounts = [];
      const allKeys = [];
      let allMountsSupportMaxDepth = true;
      for (const mount of mounts) {
        if (!mount.driver.flags?.maxDepth) {
          allMountsSupportMaxDepth = false;
        }
        const rawKeys = await asyncCall(
          mount.driver.getKeys,
          mount.relativeBase,
          opts
        );
        for (const key of rawKeys) {
          const fullKey = mount.mountpoint + normalizeKey$1(key);
          if (!maskedMounts.some((p) => fullKey.startsWith(p))) {
            allKeys.push(fullKey);
          }
        }
        maskedMounts = [
          mount.mountpoint,
          ...maskedMounts.filter((p) => !p.startsWith(mount.mountpoint))
        ];
      }
      const shouldFilterByDepth = opts.maxDepth !== void 0 && !allMountsSupportMaxDepth;
      return allKeys.filter(
        (key) => (!shouldFilterByDepth || filterKeyByDepth(key, opts.maxDepth)) && filterKeyByBase(key, base)
      );
    },
    // Utils
    async clear(base, opts = {}) {
      base = normalizeBase(base);
      await Promise.all(
        getMounts(base, false).map(async (m) => {
          if (m.driver.clear) {
            return asyncCall(m.driver.clear, m.relativeBase, opts);
          }
          if (m.driver.removeItem) {
            const keys = await m.driver.getKeys(m.relativeBase || "", opts);
            return Promise.all(
              keys.map((key) => m.driver.removeItem(key, opts))
            );
          }
        })
      );
    },
    async dispose() {
      await Promise.all(
        Object.values(context.mounts).map((driver) => dispose(driver))
      );
    },
    async watch(callback) {
      await startWatch();
      context.watchListeners.push(callback);
      return async () => {
        context.watchListeners = context.watchListeners.filter(
          (listener) => listener !== callback
        );
        if (context.watchListeners.length === 0) {
          await stopWatch();
        }
      };
    },
    async unwatch() {
      context.watchListeners = [];
      await stopWatch();
    },
    // Mount
    mount(base, driver) {
      base = normalizeBase(base);
      if (base && context.mounts[base]) {
        throw new Error(`already mounted at ${base}`);
      }
      if (base) {
        context.mountpoints.push(base);
        context.mountpoints.sort((a, b) => b.length - a.length);
      }
      context.mounts[base] = driver;
      if (context.watching) {
        Promise.resolve(watch(driver, onChange, base)).then((unwatcher) => {
          context.unwatch[base] = unwatcher;
        }).catch(console.error);
      }
      return storage;
    },
    async unmount(base, _dispose = true) {
      base = normalizeBaseKey(base);
      if (!base || !context.mounts[base]) {
        return;
      }
      if (context.watching && base in context.unwatch) {
        context.unwatch[base]?.();
        delete context.unwatch[base];
      }
      if (_dispose) {
        await dispose(context.mounts[base]);
      }
      context.mountpoints = context.mountpoints.filter((key) => key !== base);
      delete context.mounts[base];
    },
    getMount(key = "") {
      key = normalizeKey$1(key) + ":";
      const m = getMount(key);
      return {
        driver: m.driver,
        base: m.base
      };
    },
    getMounts(base = "", opts = {}) {
      base = normalizeKey$1(base);
      const mounts = getMounts(base, opts.parents);
      return mounts.map((m) => ({
        driver: m.driver,
        base: m.mountpoint
      }));
    },
    // Aliases
    keys: (base, opts = {}) => storage.getKeys(base, opts),
    get: (key, opts = {}) => storage.getItem(key, opts),
    set: (key, value, opts = {}) => storage.setItem(key, value, opts),
    has: (key, opts = {}) => storage.hasItem(key, opts),
    del: (key, opts = {}) => storage.removeItem(key, opts),
    remove: (key, opts = {}) => storage.removeItem(key, opts)
  };
  return storage;
}
function watch(driver, onChange, base) {
  return driver.watch ? driver.watch((event, key) => onChange(event, base + key)) : () => {
  };
}
async function dispose(driver) {
  if (typeof driver.dispose === "function") {
    await asyncCall(driver.dispose);
  }
}

const _assets = {

};

const normalizeKey = function normalizeKey(key) {
  if (!key) {
    return "";
  }
  return key.split("?")[0]?.replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "") || "";
};

const assets$1 = {
  getKeys() {
    return Promise.resolve(Object.keys(_assets))
  },
  hasItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(id in _assets)
  },
  getItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].import() : null)
  },
  getMeta (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].meta : {})
  }
};

function defineDriver(factory) {
  return factory;
}
function createError(driver, message, opts) {
  const err = new Error(`[unstorage] [${driver}] ${message}`, opts);
  if (Error.captureStackTrace) {
    Error.captureStackTrace(err, createError);
  }
  return err;
}
function createRequiredError(driver, name) {
  if (Array.isArray(name)) {
    return createError(
      driver,
      `Missing some of the required options ${name.map((n) => "`" + n + "`").join(", ")}`
    );
  }
  return createError(driver, `Missing required option \`${name}\`.`);
}

function ignoreNotfound(err) {
  return err.code === "ENOENT" || err.code === "EISDIR" ? null : err;
}
function ignoreExists(err) {
  return err.code === "EEXIST" ? null : err;
}
async function writeFile(path, data, encoding) {
  await ensuredir(dirname$1(path));
  return promises.writeFile(path, data, encoding);
}
function readFile(path, encoding) {
  return promises.readFile(path, encoding ?? null).catch(ignoreNotfound);
}
function unlink(path) {
  return promises.unlink(path).catch(ignoreNotfound);
}
function readdir(dir) {
  return promises.readdir(dir, { withFileTypes: true }).catch(ignoreNotfound).then((r) => r || []);
}
async function ensuredir(dir) {
  if (existsSync(dir)) {
    return;
  }
  await ensuredir(dirname$1(dir)).catch(ignoreExists);
  await promises.mkdir(dir).catch(ignoreExists);
}
async function readdirRecursive(dir, ignore, maxDepth) {
  if (ignore && ignore(dir)) {
    return [];
  }
  const entries = await readdir(dir);
  const files = [];
  await Promise.all(
    entries.map(async (entry) => {
      const entryPath = resolve$1(dir, entry.name);
      if (entry.isDirectory()) {
        if (maxDepth === void 0 || maxDepth > 0) {
          const dirFiles = await readdirRecursive(
            entryPath,
            ignore,
            maxDepth === void 0 ? void 0 : maxDepth - 1
          );
          files.push(...dirFiles.map((f) => entry.name + "/" + f));
        }
      } else {
        if (!(ignore && ignore(entry.name))) {
          files.push(entry.name);
        }
      }
    })
  );
  return files;
}
async function rmRecursive(dir) {
  const entries = await readdir(dir);
  await Promise.all(
    entries.map((entry) => {
      const entryPath = resolve$1(dir, entry.name);
      if (entry.isDirectory()) {
        return rmRecursive(entryPath).then(() => promises.rmdir(entryPath));
      } else {
        return promises.unlink(entryPath);
      }
    })
  );
}

const PATH_TRAVERSE_RE = /\.\.:|\.\.$/;
const DRIVER_NAME = "fs-lite";
const unstorage_47drivers_47fs_45lite = defineDriver((opts = {}) => {
  if (!opts.base) {
    throw createRequiredError(DRIVER_NAME, "base");
  }
  opts.base = resolve$1(opts.base);
  const r = (key) => {
    if (PATH_TRAVERSE_RE.test(key)) {
      throw createError(
        DRIVER_NAME,
        `Invalid key: ${JSON.stringify(key)}. It should not contain .. segments`
      );
    }
    const resolved = join(opts.base, key.replace(/:/g, "/"));
    return resolved;
  };
  return {
    name: DRIVER_NAME,
    options: opts,
    flags: {
      maxDepth: true
    },
    hasItem(key) {
      return existsSync(r(key));
    },
    getItem(key) {
      return readFile(r(key), "utf8");
    },
    getItemRaw(key) {
      return readFile(r(key));
    },
    async getMeta(key) {
      const { atime, mtime, size, birthtime, ctime } = await promises.stat(r(key)).catch(() => ({}));
      return { atime, mtime, size, birthtime, ctime };
    },
    setItem(key, value) {
      if (opts.readOnly) {
        return;
      }
      return writeFile(r(key), value, "utf8");
    },
    setItemRaw(key, value) {
      if (opts.readOnly) {
        return;
      }
      return writeFile(r(key), value);
    },
    removeItem(key) {
      if (opts.readOnly) {
        return;
      }
      return unlink(r(key));
    },
    getKeys(_base, topts) {
      return readdirRecursive(r("."), opts.ignore, topts?.maxDepth);
    },
    async clear() {
      if (opts.readOnly || opts.noClear) {
        return;
      }
      await rmRecursive(r("."));
    }
  };
});

const storage = createStorage({});

storage.mount('/assets', assets$1);

storage.mount('data', unstorage_47drivers_47fs_45lite({"driver":"fsLite","base":"./.data/kv"}));

function useStorage(base = "") {
  return base ? prefixStorage(storage, base) : storage;
}

function serialize$1(input) {
	if (typeof input === "string") return `'${input}'`;
	return new Serializer().serialize(input);
}
const asciiOrder = " _-,;:!?.'\"()[]{}@*/\\&#%`^+<=>|~$0123456789abcdefghijklmnopqrstuvwxyz";
const asciiWeights = /*@__PURE__*/ (function() {
	const weights = /* @__PURE__ */ new Uint8Array(128);
	for (let i = 0; i < 69; i++) weights[asciiOrder.charCodeAt(i)] = i + 1;
	for (let code = 65; code <= 90; code++) weights[code] = weights[code + 32];
	return weights;
})();
function compareStrings(a, b) {
	if (a === b) return 0;
	const length = Math.min(a.length, b.length);
	let tieBreaker = 0;
	for (let i = 0; i < length; i++) {
		const codeA = a.charCodeAt(i);
		const codeB = b.charCodeAt(i);
		if (codeA === codeB) continue;
		const weightA = codeA < 128 && asciiWeights[codeA] ? asciiWeights[codeA] : codeA + 128;
		const weightB = codeB < 128 && asciiWeights[codeB] ? asciiWeights[codeB] : codeB + 128;
		if (weightA !== weightB) return weightA < weightB ? -1 : 1;
		if (tieBreaker === 0) tieBreaker = codeA > codeB ? -1 : 1;
	}
	if (a.length !== b.length) return a.length < b.length ? -1 : 1;
	return tieBreaker;
}
const Serializer = /*@__PURE__*/ (function() {
	class Serializer {
		#context = /* @__PURE__ */ new Map();
		compare(a, b) {
			const typeA = typeof a;
			const typeB = typeof b;
			if (typeA === "string" && typeB === "string") return compareStrings(a, b);
			if (typeA === "number" && typeB === "number") return a - b;
			return compareStrings(this.serialize(a, true), this.serialize(b, true));
		}
		serialize(value, noQuotes) {
			if (value === null) return "null";
			switch (typeof value) {
				case "string": return noQuotes ? value : `'${value}'`;
				case "bigint": return `${value}n`;
				case "object": return this.$object(value);
				case "function": return this.$function(value);
			}
			return String(value);
		}
		serializeObject(object) {
			const objString = Object.prototype.toString.call(object);
			if (objString !== "[object Object]") return this.serializeBuiltInType(objString.length < 10 ? `unknown:${objString}` : objString.slice(8, -1), object);
			const constructor = object.constructor;
			const objName = constructor === Object || constructor === void 0 ? "" : constructor.name;
			if (objName !== "" && globalThis[objName] === constructor) return this.serializeBuiltInType(objName, object);
			if ("toJSON" in object && typeof object.toJSON === "function") {
				const json = object.toJSON();
				return objName + (json !== null && typeof json === "object" ? this.$object(json) : `(${this.serialize(json)})`);
			}
			const keys = Object.keys(object).sort(compareStrings);
			let content = `${objName}{`;
			for (let i = 0; i < keys.length; i++) {
				const key = keys[i];
				content += `${key}:${this.serialize(object[key])}`;
				if (i < keys.length - 1) content += ",";
			}
			return content + "}";
		}
		serializeBuiltInType(type, object) {
			const handler = this["$" + type];
			if (handler) return handler.call(this, object);
			if (typeof object.entries === "function") return this.serializeObjectEntries(type, object.entries());
			throw new Error(`Cannot serialize ${type}`);
		}
		serializeObjectEntries(type, entries) {
			const sortedEntries = Array.from(entries).sort((a, b) => this.compare(a[0], b[0]));
			let content = `${type}{`;
			for (let i = 0; i < sortedEntries.length; i++) {
				const [key, value] = sortedEntries[i];
				content += `${this.serialize(key, true)}:${this.serialize(value)}`;
				if (i < sortedEntries.length - 1) content += ",";
			}
			return content + "}";
		}
		$object(object) {
			let content = this.#context.get(object);
			if (content === void 0) {
				this.#context.set(object, `#${this.#context.size}`);
				content = this.serializeObject(object);
				this.#context.set(object, content);
			}
			return content;
		}
		$function(fn) {
			const fnStr = Function.prototype.toString.call(fn);
			if (fnStr.slice(-15) === "[native code] }") return `${fn.name || ""}()[native]`;
			return `${fn.name}(${fn.length})${fnStr.replace(/\s*\n\s*/g, "")}`;
		}
		$Array(arr) {
			let content = "[";
			for (let i = 0; i < arr.length; i++) {
				content += this.serialize(arr[i]);
				if (i < arr.length - 1) content += ",";
			}
			return content + "]";
		}
		$Date(date) {
			try {
				return `Date(${date.toISOString()})`;
			} catch {
				return `Date(null)`;
			}
		}
		$ArrayBuffer(arr) {
			return `ArrayBuffer[${new Uint8Array(arr).join(",")}]`;
		}
		$Set(set) {
			return `Set${this.$Array(Array.from(set).sort((a, b) => this.compare(a, b)))}`;
		}
		$Map(map) {
			return this.serializeObjectEntries("Map", map.entries());
		}
	}
	for (const type of [
		"Error",
		"RegExp",
		"URL"
	]) Serializer.prototype["$" + type] = function(val) {
		return `${type}(${val})`;
	};
	for (const type of [
		"Int8Array",
		"Uint8Array",
		"Uint8ClampedArray",
		"Int16Array",
		"Uint16Array",
		"Int32Array",
		"Uint32Array",
		"Float32Array",
		"Float64Array"
	]) Serializer.prototype["$" + type] = function(arr) {
		return `${type}[${arr.join(",")}]`;
	};
	for (const type of ["BigInt64Array", "BigUint64Array"]) Serializer.prototype["$" + type] = function(arr) {
		return `${type}[${arr.join("n,")}${arr.length > 0 ? "n" : ""}]`;
	};
	return Serializer;
})();
function isEqual(object1, object2) {
	if (object1 === object2) return true;
	if (serialize$1(object1) === serialize$1(object2)) return true;
	return false;
}

const fastHash = /*@__PURE__*/ (() => globalThis.process?.getBuiltinModule?.("crypto")?.hash)();
const algorithm = "sha256";
const encoding = "base64url";
function digest(data) {
	if (fastHash) return fastHash(algorithm, data, encoding);
	const h = createHash(algorithm).update(data);
	return globalThis.process?.versions?.webcontainer ? h.digest().toString(encoding) : h.digest(encoding);
}

const Hasher = /* @__PURE__ */ (() => {
  class Hasher2 {
    buff = "";
    #context = /* @__PURE__ */ new Map();
    write(str) {
      this.buff += str;
    }
    dispatch(value) {
      const type = value === null ? "null" : typeof value;
      return this[type](value);
    }
    object(object) {
      if (object && typeof object.toJSON === "function") {
        return this.object(object.toJSON());
      }
      const objString = Object.prototype.toString.call(object);
      let objType = "";
      const objectLength = objString.length;
      objType = objectLength < 10 ? "unknown:[" + objString + "]" : objString.slice(8, objectLength - 1);
      objType = objType.toLowerCase();
      let objectNumber = null;
      if ((objectNumber = this.#context.get(object)) === void 0) {
        this.#context.set(object, this.#context.size);
      } else {
        return this.dispatch("[CIRCULAR:" + objectNumber + "]");
      }
      if (typeof Buffer !== "undefined" && Buffer.isBuffer && Buffer.isBuffer(object)) {
        this.write("buffer:");
        return this.write(object.toString("utf8"));
      }
      if (objType !== "object" && objType !== "function" && objType !== "asyncfunction") {
        if (this[objType]) {
          this[objType](object);
        } else {
          this.unknown(object, objType);
        }
      } else {
        const keys = Object.keys(object).sort();
        const extraKeys = [];
        this.write("object:" + (keys.length + extraKeys.length) + ":");
        const dispatchForKey = (key) => {
          this.dispatch(key);
          this.write(":");
          this.dispatch(object[key]);
          this.write(",");
        };
        for (const key of keys) {
          dispatchForKey(key);
        }
        for (const key of extraKeys) {
          dispatchForKey(key);
        }
      }
    }
    array(arr, unordered) {
      unordered = unordered === void 0 ? false : unordered;
      this.write("array:" + arr.length + ":");
      if (!unordered || arr.length <= 1) {
        for (const entry of arr) {
          this.dispatch(entry);
        }
        return;
      }
      const contextAdditions = /* @__PURE__ */ new Map();
      const entries = arr.map((entry) => {
        const hasher = new Hasher2();
        hasher.dispatch(entry);
        for (const [key, value] of hasher.#context) {
          contextAdditions.set(key, value);
        }
        return hasher.toString();
      });
      this.#context = contextAdditions;
      entries.sort();
      return this.array(entries, false);
    }
    date(date) {
      return this.write("date:" + date.toJSON());
    }
    symbol(sym) {
      return this.write("symbol:" + sym.toString());
    }
    unknown(value, type) {
      this.write(type);
      if (!value) {
        return;
      }
      this.write(":");
      if (value && typeof value.entries === "function") {
        return this.array(
          [...value.entries()],
          true
          /* ordered */
        );
      }
    }
    error(err) {
      return this.write("error:" + err.toString());
    }
    boolean(bool) {
      return this.write("bool:" + bool);
    }
    string(string) {
      this.write("string:" + string.length + ":");
      this.write(string);
    }
    function(fn) {
      this.write("fn:");
      if (isNativeFunction(fn)) {
        this.dispatch("[native]");
      } else {
        this.dispatch(fn.toString());
      }
    }
    number(number) {
      return this.write("number:" + number);
    }
    null() {
      return this.write("Null");
    }
    undefined() {
      return this.write("Undefined");
    }
    regexp(regex) {
      return this.write("regex:" + regex.toString());
    }
    arraybuffer(arr) {
      this.write("arraybuffer:");
      return this.dispatch(new Uint8Array(arr));
    }
    url(url) {
      return this.write("url:" + url.toString());
    }
    map(map) {
      this.write("map:");
      const arr = [...map];
      return this.array(arr, false);
    }
    set(set) {
      this.write("set:");
      const arr = [...set];
      return this.array(arr, false);
    }
    bigint(number) {
      return this.write("bigint:" + number.toString());
    }
  }
  for (const type of [
    "uint8array",
    "uint8clampedarray",
    "unt8array",
    "uint16array",
    "unt16array",
    "uint32array",
    "unt32array",
    "float32array",
    "float64array"
  ]) {
    Hasher2.prototype[type] = function(arr) {
      this.write(type + ":");
      return this.array([...arr], false);
    };
  }
  function isNativeFunction(f) {
    if (typeof f !== "function") {
      return false;
    }
    return Function.prototype.toString.call(f).slice(
      -15
      /* "[native code] }".length */
    ) === "[native code] }";
  }
  return Hasher2;
})();
function serialize(object) {
  const hasher = new Hasher();
  hasher.dispatch(object);
  return hasher.buff;
}
function hash(value) {
  return digest(typeof value === "string" ? value : serialize(value)).replace(/[-_]/g, "").slice(0, 10);
}

function defaultCacheOptions() {
  return {
    name: "_",
    base: "/cache",
    swr: true,
    maxAge: 1
  };
}
function defineCachedFunction(fn, opts = {}) {
  opts = { ...defaultCacheOptions(), ...opts };
  const pending = {};
  const group = opts.group || "nitro/functions";
  const name = opts.name || fn.name || "_";
  const integrity = opts.integrity || hash([fn, opts]);
  const validate = opts.validate || ((entry) => entry.value !== void 0);
  async function get(key, resolver, shouldInvalidateCache, event) {
    const cacheKey = [opts.base, group, name, key + ".json"].filter(Boolean).join(":").replace(/:\/$/, ":index");
    let entry = await useStorage().getItem(cacheKey).catch((error) => {
      console.error(`[cache] Cache read error.`, error);
      useNitroApp().captureError(error, { event, tags: ["cache"] });
    }) || {};
    if (typeof entry !== "object") {
      entry = {};
      const error = new Error("Malformed data read from cache.");
      console.error("[cache]", error);
      useNitroApp().captureError(error, { event, tags: ["cache"] });
    }
    const ttl = (opts.maxAge ?? 0) * 1e3;
    if (ttl) {
      entry.expires = Date.now() + ttl;
    }
    const expired = shouldInvalidateCache || entry.integrity !== integrity || ttl && Date.now() - (entry.mtime || 0) > ttl || validate(entry) === false;
    const _resolve = async () => {
      const isPending = pending[key];
      if (!isPending) {
        if (entry.value !== void 0 && (opts.staleMaxAge || 0) >= 0 && opts.swr === false) {
          entry.value = void 0;
          entry.integrity = void 0;
          entry.mtime = void 0;
          entry.expires = void 0;
        }
        pending[key] = Promise.resolve(resolver());
      }
      try {
        entry.value = await pending[key];
      } catch (error) {
        if (!isPending) {
          delete pending[key];
        }
        throw error;
      }
      if (!isPending) {
        entry.mtime = Date.now();
        entry.integrity = integrity;
        delete pending[key];
        if (validate(entry) !== false) {
          let setOpts;
          if (opts.maxAge && !opts.swr) {
            setOpts = { ttl: opts.maxAge };
          }
          const promise = useStorage().setItem(cacheKey, entry, setOpts).catch((error) => {
            console.error(`[cache] Cache write error.`, error);
            useNitroApp().captureError(error, { event, tags: ["cache"] });
          });
          if (event?.waitUntil) {
            event.waitUntil(promise);
          }
        }
      }
    };
    const _resolvePromise = expired ? _resolve() : Promise.resolve();
    if (entry.value === void 0) {
      await _resolvePromise;
    } else if (expired && event && event.waitUntil) {
      event.waitUntil(_resolvePromise);
    }
    if (opts.swr && validate(entry) !== false) {
      _resolvePromise.catch((error) => {
        console.error(`[cache] SWR handler error.`, error);
        useNitroApp().captureError(error, { event, tags: ["cache"] });
      });
      return entry;
    }
    return _resolvePromise.then(() => entry);
  }
  return async (...args) => {
    const shouldBypassCache = await opts.shouldBypassCache?.(...args);
    if (shouldBypassCache) {
      return fn(...args);
    }
    const key = await (opts.getKey || getKey)(...args);
    const shouldInvalidateCache = await opts.shouldInvalidateCache?.(...args);
    const entry = await get(
      key,
      () => fn(...args),
      shouldInvalidateCache,
      args[0] && isEvent(args[0]) ? args[0] : void 0
    );
    let value = entry.value;
    if (opts.transform) {
      value = await opts.transform(entry, ...args) || value;
    }
    return value;
  };
}
function cachedFunction(fn, opts = {}) {
  return defineCachedFunction(fn, opts);
}
function getKey(...args) {
  return args.length > 0 ? hash(args) : "";
}
function escapeKey(key) {
  return String(key).replace(/\W/g, "");
}
function defineCachedEventHandler(handler, opts = defaultCacheOptions()) {
  const variableHeaderNames = (opts.varies || []).filter(Boolean).map((h) => h.toLowerCase()).sort();
  const _opts = {
    ...opts,
    getKey: async (event) => {
      const customKey = await opts.getKey?.(event);
      if (customKey) {
        return escapeKey(customKey);
      }
      const _path = event.node.req.originalUrl || event.node.req.url || event.path;
      let _pathname;
      try {
        _pathname = escapeKey(decodeURI(parseURL(_path).pathname)).slice(0, 16) || "index";
      } catch {
        _pathname = "-";
      }
      const _hashedPath = `${_pathname}.${hash(_path)}`;
      const _headers = variableHeaderNames.map((header) => [header, event.node.req.headers[header]]).map(([name, value]) => `${escapeKey(name)}.${hash(value)}`);
      return [_hashedPath, ..._headers].join(":");
    },
    validate: (entry) => {
      if (!entry.value) {
        return false;
      }
      if (entry.value.code >= 400) {
        return false;
      }
      if (entry.value.body === void 0) {
        return false;
      }
      if (entry.value.headers.etag === "undefined" || entry.value.headers["last-modified"] === "undefined") {
        return false;
      }
      return true;
    },
    group: opts.group || "nitro/handlers",
    integrity: opts.integrity || hash([handler, opts])
  };
  const _cachedHandler = cachedFunction(
    async (incomingEvent) => {
      const variableHeaders = {};
      for (const header of variableHeaderNames) {
        const value = incomingEvent.node.req.headers[header];
        if (value !== void 0) {
          variableHeaders[header] = value;
        }
      }
      const reqProxy = cloneWithProxy(incomingEvent.node.req, {
        headers: variableHeaders
      });
      const resHeaders = {};
      let _resSendBody;
      const resProxy = cloneWithProxy(incomingEvent.node.res, {
        statusCode: 200,
        writableEnded: false,
        writableFinished: false,
        headersSent: false,
        closed: false,
        getHeader(name) {
          return resHeaders[name];
        },
        setHeader(name, value) {
          resHeaders[name] = value;
          return this;
        },
        getHeaderNames() {
          return Object.keys(resHeaders);
        },
        hasHeader(name) {
          return name in resHeaders;
        },
        removeHeader(name) {
          delete resHeaders[name];
        },
        getHeaders() {
          return resHeaders;
        },
        end(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2();
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return this;
        },
        write(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2(void 0);
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return true;
        },
        writeHead(statusCode, headers2) {
          this.statusCode = statusCode;
          if (headers2) {
            if (Array.isArray(headers2) || typeof headers2 === "string") {
              throw new TypeError("Raw headers  is not supported.");
            }
            for (const header in headers2) {
              const value = headers2[header];
              if (value !== void 0) {
                this.setHeader(
                  header,
                  value
                );
              }
            }
          }
          return this;
        }
      });
      const event = createEvent(reqProxy, resProxy);
      event._path = incomingEvent._path;
      event.fetch = (url, fetchOptions) => fetchWithEvent(event, url, fetchOptions, {
        fetch: useNitroApp().localFetch
      });
      event.$fetch = (url, fetchOptions) => fetchWithEvent(event, url, fetchOptions, {
        fetch: globalThis.$fetch
      });
      event.waitUntil = incomingEvent.waitUntil;
      event.context = incomingEvent.context;
      event.context.cache = {
        options: _opts
      };
      const body = await handler(event) || _resSendBody;
      const headers = event.node.res.getHeaders();
      headers.etag = String(
        headers.Etag || headers.etag || `W/"${hash(body)}"`
      );
      headers["last-modified"] = String(
        headers["Last-Modified"] || headers["last-modified"] || (/* @__PURE__ */ new Date()).toUTCString()
      );
      const cacheControl = [];
      if (opts.swr) {
        if (opts.maxAge) {
          cacheControl.push(`s-maxage=${opts.maxAge}`);
        }
        if (opts.staleMaxAge) {
          cacheControl.push(`stale-while-revalidate=${opts.staleMaxAge}`);
        } else {
          cacheControl.push("stale-while-revalidate");
        }
      } else if (opts.maxAge) {
        cacheControl.push(`max-age=${opts.maxAge}`);
      }
      if (cacheControl.length > 0) {
        headers["cache-control"] = cacheControl.join(", ");
      }
      const cacheEntry = {
        code: event.node.res.statusCode,
        headers,
        body
      };
      return cacheEntry;
    },
    _opts
  );
  return defineEventHandler(async (event) => {
    if (opts.headersOnly) {
      if (handleCacheHeaders(event, { maxAge: opts.maxAge })) {
        return;
      }
      return handler(event);
    }
    const response = await _cachedHandler(
      event
    );
    if (event.node.res.headersSent || event.node.res.writableEnded) {
      return response.body;
    }
    if (handleCacheHeaders(event, {
      modifiedTime: new Date(response.headers["last-modified"]),
      etag: response.headers.etag,
      maxAge: opts.maxAge
    })) {
      return;
    }
    event.node.res.statusCode = response.code;
    for (const name in response.headers) {
      const value = response.headers[name];
      if (name === "set-cookie") {
        event.node.res.appendHeader(
          name,
          splitCookiesString(value)
        );
      } else {
        if (value !== void 0) {
          event.node.res.setHeader(name, value);
        }
      }
    }
    return response.body;
  });
}
function cloneWithProxy(obj, overrides) {
  return new Proxy(obj, {
    get(target, property, receiver) {
      if (property in overrides) {
        return overrides[property];
      }
      return Reflect.get(target, property, receiver);
    },
    set(target, property, value, receiver) {
      if (property in overrides) {
        overrides[property] = value;
        return true;
      }
      return Reflect.set(target, property, value, receiver);
    }
  });
}
const cachedEventHandler = defineCachedEventHandler;

function klona(x) {
	if (typeof x !== 'object') return x;

	var k, tmp, str=Object.prototype.toString.call(x);

	if (str === '[object Object]') {
		if (x.constructor !== Object && typeof x.constructor === 'function') {
			tmp = new x.constructor();
			for (k in x) {
				if (x.hasOwnProperty(k) && tmp[k] !== x[k]) {
					tmp[k] = klona(x[k]);
				}
			}
		} else {
			tmp = {}; // null
			for (k in x) {
				if (k === '__proto__') {
					Object.defineProperty(tmp, k, {
						value: klona(x[k]),
						configurable: true,
						enumerable: true,
						writable: true,
					});
				} else {
					tmp[k] = klona(x[k]);
				}
			}
		}
		return tmp;
	}

	if (str === '[object Array]') {
		k = x.length;
		for (tmp=Array(k); k--;) {
			tmp[k] = klona(x[k]);
		}
		return tmp;
	}

	if (str === '[object Set]') {
		tmp = new Set;
		x.forEach(function (val) {
			tmp.add(klona(val));
		});
		return tmp;
	}

	if (str === '[object Map]') {
		tmp = new Map;
		x.forEach(function (val, key) {
			tmp.set(klona(key), klona(val));
		});
		return tmp;
	}

	if (str === '[object Date]') {
		return new Date(+x);
	}

	if (str === '[object RegExp]') {
		tmp = new RegExp(x.source, x.flags);
		tmp.lastIndex = x.lastIndex;
		return tmp;
	}

	if (str === '[object DataView]') {
		return new x.constructor( klona(x.buffer) );
	}

	if (str === '[object ArrayBuffer]') {
		return x.slice(0);
	}

	// ArrayBuffer.isView(x)
	// ~> `new` bcuz `Buffer.slice` => ref
	if (str.slice(-6) === 'Array]') {
		return new x.constructor(x);
	}

	return x;
}

const inlineAppConfig = {};



const appConfig = defuFn(inlineAppConfig);

const NUMBER_CHAR_RE = /\d/;
const STR_SPLITTERS = ["-", "_", "/", "."];
function isUppercase(char = "") {
  if (NUMBER_CHAR_RE.test(char)) {
    return void 0;
  }
  return char !== char.toLowerCase();
}
function splitByCase(str, separators) {
  const splitters = STR_SPLITTERS;
  const parts = [];
  if (!str || typeof str !== "string") {
    return parts;
  }
  let buff = "";
  let previousUpper;
  let previousSplitter;
  for (const char of str) {
    const isSplitter = splitters.includes(char);
    if (isSplitter === true) {
      parts.push(buff);
      buff = "";
      previousUpper = void 0;
      continue;
    }
    const isUpper = isUppercase(char);
    if (previousSplitter === false) {
      if (previousUpper === false && isUpper === true) {
        parts.push(buff);
        buff = char;
        previousUpper = isUpper;
        continue;
      }
      if (previousUpper === true && isUpper === false && buff.length > 1) {
        const lastChar = buff.at(-1);
        parts.push(buff.slice(0, Math.max(0, buff.length - 1)));
        buff = lastChar + char;
        previousUpper = isUpper;
        continue;
      }
    }
    buff += char;
    previousUpper = isUpper;
    previousSplitter = isSplitter;
  }
  parts.push(buff);
  return parts;
}
function kebabCase(str, joiner) {
  return str ? (Array.isArray(str) ? str : splitByCase(str)).map((p) => p.toLowerCase()).join(joiner) : "";
}
function snakeCase(str) {
  return kebabCase(str || "", "_");
}

function getEnv(key, opts) {
  const envKey = snakeCase(key).toUpperCase();
  return destr(
    process.env[opts.prefix + envKey] ?? process.env[opts.altPrefix + envKey]
  );
}
function _isObject(input) {
  return typeof input === "object" && !Array.isArray(input);
}
function applyEnv(obj, opts, parentKey = "") {
  for (const key in obj) {
    const subKey = parentKey ? `${parentKey}_${key}` : key;
    const envValue = getEnv(subKey, opts);
    if (_isObject(obj[key])) {
      if (_isObject(envValue)) {
        obj[key] = { ...obj[key], ...envValue };
        applyEnv(obj[key], opts, subKey);
      } else if (envValue === void 0) {
        applyEnv(obj[key], opts, subKey);
      } else {
        obj[key] = envValue ?? obj[key];
      }
    } else {
      obj[key] = envValue ?? obj[key];
    }
    if (opts.envExpansion && typeof obj[key] === "string") {
      obj[key] = _expandFromEnv(obj[key]);
    }
  }
  return obj;
}
const envExpandRx = /\{\{([^{}]*)\}\}/g;
function _expandFromEnv(value) {
  return value.replace(envExpandRx, (match, key) => {
    return process.env[key] || match;
  });
}

const _inlineRuntimeConfig = {
  "app": {
    "baseURL": "/",
    "buildId": "631842df-4911-48c0-8fd4-2075dd593927",
    "buildAssetsDir": "/_nuxt/",
    "cdnURL": ""
  },
  "nitro": {
    "envPrefix": "NUXT_",
    "routeRules": {
      "/__nuxt_error": {
        "cache": false
      },
      "/user/**": {
        "headers": {
          "X-Robots-Tag": "noindex, nofollow"
        }
      },
      "/writer": {
        "headers": {
          "X-Robots-Tag": "noindex, nofollow"
        }
      },
      "/site/manager/**": {
        "headers": {
          "X-Robots-Tag": "noindex, nofollow"
        }
      },
      "/search": {
        "headers": {
          "X-Robots-Tag": "noindex, follow"
        }
      },
      "/_nuxt/builds/meta/**": {
        "headers": {
          "cache-control": "public, max-age=31536000, immutable"
        }
      },
      "/_nuxt/builds/**": {
        "headers": {
          "cache-control": "public, max-age=1, immutable"
        }
      },
      "/_nuxt/**": {
        "headers": {
          "cache-control": "public, max-age=31536000, immutable"
        }
      }
    }
  },
  "appSecret": "",
  "public": {
    "siteUrl": "https://www.zngg.net",
    "apiBase": "https://api.zngg.net",
    "googleAdsense": {
      "id": "ca-pub-6667301035180632",
      "analyticsDomainName": "",
      "analyticsUacct": "",
      "hideUnfilled": false,
      "includeQuery": false,
      "onPageLoad": false,
      "overlayBottom": false,
      "pageLevelAds": false,
      "pauseOnLoad": false,
      "tag": "adsbygoogle",
      "test": false
    }
  }
};
const envOptions = {
  prefix: "NITRO_",
  altPrefix: _inlineRuntimeConfig.nitro.envPrefix ?? process.env.NITRO_ENV_PREFIX ?? "_",
  envExpansion: _inlineRuntimeConfig.nitro.envExpansion ?? process.env.NITRO_ENV_EXPANSION ?? false
};
const _sharedRuntimeConfig = _deepFreeze(
  applyEnv(klona(_inlineRuntimeConfig), envOptions)
);
function useRuntimeConfig(event) {
  if (!event) {
    return _sharedRuntimeConfig;
  }
  if (event.context.nitro.runtimeConfig) {
    return event.context.nitro.runtimeConfig;
  }
  const runtimeConfig = klona(_inlineRuntimeConfig);
  applyEnv(runtimeConfig, envOptions);
  event.context.nitro.runtimeConfig = runtimeConfig;
  return runtimeConfig;
}
_deepFreeze(klona(appConfig));
function _deepFreeze(object) {
  const propNames = Object.getOwnPropertyNames(object);
  for (const name of propNames) {
    const value = object[name];
    if (value && typeof value === "object") {
      _deepFreeze(value);
    }
  }
  return Object.freeze(object);
}
new Proxy(/* @__PURE__ */ Object.create(null), {
  get: (_, prop) => {
    console.warn(
      "Please use `useRuntimeConfig()` instead of accessing config directly."
    );
    const runtimeConfig = useRuntimeConfig();
    if (prop in runtimeConfig) {
      return runtimeConfig[prop];
    }
    return void 0;
  }
});

function isPathInScope(pathname, base) {
  let canonical;
  try {
    const pre = pathname.replace(/%2f/gi, "/").replace(/%5c/gi, "\\");
    canonical = new URL(pre, "http://_").pathname;
  } catch {
    return false;
  }
  return !base || canonical === base || canonical.startsWith(base + "/");
}

const config = useRuntimeConfig();
const _routeRulesMatcher = toRouteMatcher(
  createRouter$1({ routes: config.nitro.routeRules })
);
function createRouteRulesHandler(ctx) {
  return eventHandler((event) => {
    const routeRules = getRouteRules$1(event);
    if (routeRules.headers) {
      setHeaders(event, routeRules.headers);
    }
    if (routeRules.redirect) {
      let target = routeRules.redirect.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.redirect._redirectStripBase;
        if (strpBase) {
          if (!isPathInScope(event.path.split("?")[0], strpBase)) {
            throw createError$1({ statusCode: 400 });
          }
          targetPath = withoutBase(targetPath, strpBase);
        } else if (targetPath.startsWith("//")) {
          targetPath = targetPath.replace(/^\/+/, "/");
        }
        target = joinURL(target.slice(0, -3), targetPath);
      } else if (event.path.includes("?")) {
        const query = getQuery$1(event.path);
        target = withQuery(target, query);
      }
      return sendRedirect(event, target, routeRules.redirect.statusCode);
    }
    if (routeRules.proxy) {
      let target = routeRules.proxy.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.proxy._proxyStripBase;
        if (strpBase) {
          if (!isPathInScope(event.path.split("?")[0], strpBase)) {
            throw createError$1({ statusCode: 400 });
          }
          targetPath = withoutBase(targetPath, strpBase);
        } else if (targetPath.startsWith("//")) {
          targetPath = targetPath.replace(/^\/+/, "/");
        }
        target = joinURL(target.slice(0, -3), targetPath);
      } else if (event.path.includes("?")) {
        const query = getQuery$1(event.path);
        target = withQuery(target, query);
      }
      return proxyRequest(event, target, {
        fetch: ctx.localFetch,
        ...routeRules.proxy
      });
    }
  });
}
function getRouteRules$1(event) {
  event.context._nitro = event.context._nitro || {};
  if (!event.context._nitro.routeRules) {
    event.context._nitro.routeRules = getRouteRulesForPath(
      withoutBase(event.path.split("?")[0], useRuntimeConfig().app.baseURL)
    );
  }
  return event.context._nitro.routeRules;
}
function getRouteRulesForPath(path) {
  return defu({}, ..._routeRulesMatcher.matchAll(path).reverse());
}

function _captureError(error, type) {
  console.error(`[${type}]`, error);
  useNitroApp().captureError(error, { tags: [type] });
}
function trapUnhandledNodeErrors() {
  process.on(
    "unhandledRejection",
    (error) => _captureError(error, "unhandledRejection")
  );
  process.on(
    "uncaughtException",
    (error) => _captureError(error, "uncaughtException")
  );
}
function joinHeaders(value) {
  return Array.isArray(value) ? value.join(", ") : String(value);
}
function normalizeFetchResponse(response) {
  if (!response.headers.has("set-cookie")) {
    return response;
  }
  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers: normalizeCookieHeaders(response.headers)
  });
}
function normalizeCookieHeader(header = "") {
  return splitCookiesString(joinHeaders(header));
}
function normalizeCookieHeaders(headers) {
  const outgoingHeaders = new Headers();
  for (const [name, header] of headers) {
    if (name === "set-cookie") {
      for (const cookie of normalizeCookieHeader(header)) {
        outgoingHeaders.append("set-cookie", cookie);
      }
    } else {
      outgoingHeaders.set(name, joinHeaders(header));
    }
  }
  return outgoingHeaders;
}

//#region src/runtime/utils/event.ts
const ENC_PIPE_RE = /%7C/g;
const ENC_BRACKET_OPEN_RE = /%5B/g;
const ENC_BRACKET_CLOSE_RE = /%5D/g;
const ENC_ENC_SLASH_RE = /%252F/gi;
const HASH_RE = /#/g;
const QUESTION_MARK_RE = /\?/g;
function encodeEventPath(path) {
	const queryIndex = path.indexOf("?");
	if (queryIndex === -1) return encodeVueRouterPath(path);
	return encodeVueRouterPath(path.slice(0, queryIndex)) + path.slice(queryIndex);
}
function encodeVueRouterPath(path) {
	return encodeURI(path).replace(ENC_PIPE_RE, "|").replace(ENC_BRACKET_OPEN_RE, "[").replace(ENC_BRACKET_CLOSE_RE, "]").replace(HASH_RE, "%23").replace(QUESTION_MARK_RE, "%3F").replace(ENC_ENC_SLASH_RE, "%2F");
}
/**
* The response headers of an h3 v1 event, in the shape the renderer writes them in.
*
* Backed by the node response rather than a copy of it, so a header the app sets through
* h3 and a header the renderer sets are the same header, and both are sent.
*/
var NodeResponseHeaders = class {
	res;
	constructor(res) {
		this.res = res;
	}
	get(name) {
		const value = this.res.getHeader(name);
		if (value === void 0) return null;
		return Array.isArray(value) ? value.join(", ") : String(value);
	}
	has(name) {
		return this.res.hasHeader(name);
	}
	set(name, value) {
		this.res.setHeader(name, value);
	}
	append(name, value) {
		const existing = this.res.getHeader(name);
		if (existing === void 0) {
			this.res.setHeader(name, value);
			return;
		}
		this.res.setHeader(name, Array.isArray(existing) ? [...existing, value] : [String(existing), value]);
	}
	delete(name) {
		this.res.removeHeader(name);
	}
	getSetCookie() {
		const value = this.res.getHeader("set-cookie");
		if (value === void 0) return [];
		return Array.isArray(value) ? value.map(String) : [String(value)];
	}
	*entries() {
		const headers = this.res.getHeaders();
		for (const name of Object.keys(headers).sort()) {
			const value = headers[name];
			if (value === void 0) continue;
			if (name === "set-cookie" && Array.isArray(value)) for (const entry of value) yield [name, entry];
			else yield [name, Array.isArray(value) ? value.join(", ") : String(value)];
		}
	}
	*keys() {
		for (const [name] of this.entries()) yield name;
	}
	*values() {
		for (const [, value] of this.entries()) yield value;
	}
	forEach(callback, thisArg) {
		for (const [name, value] of this.entries()) callback.call(thisArg, value, name, this);
	}
	[Symbol.iterator]() {
		return this.entries();
	}
};
const PAYLOAD_METHODS = /* @__PURE__ */ new Set([
	"PATCH",
	"POST",
	"PUT",
	"DELETE"
]);
const BODY_READ_METHODS = /* @__PURE__ */ new Set([
	"arrayBuffer",
	"blob",
	"bytes",
	"formData",
	"json",
	"text"
]);
/**
* The request in the web-standard shape, with every read of its body served from the bytes
* h3 v1 caches on the node request.
*
* A body read here and a `readBody(event)` elsewhere in the same request therefore resolve
* to the same bytes whichever happens first, and reading the request twice - directly, from
* a clone, or as a stream - resolves the same bytes each time rather than the second read
* finding a stream the first has drained.
*/
function toWebRequest$1(event) {
	const existing = event.web?.request;
	if (existing) return existing;
	const method = event.method;
	if (!PAYLOAD_METHODS.has(method)) return new Request(getRequestURL(event), {
		method,
		headers: event.headers
	});
	const request = new Request(getRequestURL(event), {
		method,
		headers: event.headers,
		body: toBufferedBodyStream(event),
		duplex: "half"
	});
	const read = () => readRawBody(event, false).then((body) => body ? new Uint8Array(body) : /* @__PURE__ */ new Uint8Array());
	const copy = () => read().then((body) => new Response(body, { headers: request.headers }));
	const buffered = new Proxy(request, { get(target, property) {
		if (property === "bodyUsed") return false;
		if (property === "body") return toBufferedBodyStream(event);
		if (property === "clone") return () => buffered;
		if (typeof property === "string" && BODY_READ_METHODS.has(property)) return () => copy().then((response) => response[property]());
		const value = Reflect.get(target, property, target);
		return typeof value === "function" ? value.bind(target) : value;
	} });
	return buffered;
}
function toBufferedBodyStream(event) {
	return new ReadableStream({ async pull(controller) {
		const body = await readRawBody(event, false);
		if (body) controller.enqueue(new Uint8Array(body));
		controller.close();
	} });
}
/**
* The Nuxt context a request nitro made to itself was fetched with: `node-mock-http` carries
* it on the mock request rather than in the h3 event's own context. A request that arrives
* over the network has none, whoever sent it.
*/
function getFetchedRequestContext(event) {
	return event.node.req.__unenv__?.nuxt;
}
/** The event the SSR renderer reads, which reaches the h3 v1 event itself through `~app`. */
function toRequestEvent(event) {
	const requestEvent = toWebView(event);
	const fetchedWith = getFetchedRequestContext(event);
	if (fetchedWith) event.context.nuxt = {
		...fetchedWith,
		...event.context.nuxt
	};
	return requestEvent;
}
/**
* Describe an h3 v1 event in the web-standard shape, rather than adapting it in place:
* `event.req` and `event.res` already name the node request and response, and that is the
* shape `useRequestEvent()` and the render hooks must keep seeing.
*
* Everything is resolved on access, and the response is backed by the node response rather
* than a copy of it, so a header the application sets through h3 and a header the renderer
* sets are the same header.
*/
function toWebView(event, resolveURL = () => new URL(encodeEventPath(event.path), `${getRequestProtocol(event)}://${getRequestHost(event)}`)) {
	const node = event.node;
	let request;
	let url;
	const res = {
		get status() {
			return node.res.statusCode;
		},
		set status(status) {
			node.res.statusCode = status;
		},
		get statusText() {
			return node.res.statusMessage;
		},
		set statusText(statusText) {
			node.res.statusMessage = statusText;
		},
		headers: new NodeResponseHeaders(node.res)
	};
	const requestEvent = {
		context: event.context,
		res,
		get req() {
			return request ??= toWebRequest$1(event);
		},
		get url() {
			return url ??= resolveURL();
		},
		set url(value) {
			url = value;
			event._path = node.req.url = value.pathname + value.search;
		}
	};
	requestEvent["~app"] = event;
	return requestEvent;
}

//#region src/runtime/utils/error.ts
/**
* Nitro internal functions extracted from https://github.com/nitrojs/nitro/blob/v2/src/runtime/internal/utils.ts
*/
function isJsonRequest(event) {
	if (hasReqHeader(event, "accept", "text/html")) return false;
	return hasReqHeader(event, "accept", "application/json") || hasReqHeader(event, "user-agent", "curl/") || hasReqHeader(event, "user-agent", "httpie/") || hasReqHeader(event, "sec-fetch-mode", "cors") || event.path.startsWith("/api/") || event.path.endsWith(".json");
}
function hasReqHeader(event, name, includes) {
	const value = getRequestHeader(event, name);
	return !!(value && typeof value === "string" && value.toLowerCase().includes(includes));
}

const headSymbol = "usehead";
// @__NO_SIDE_EFFECTS__
function vueInstall(head) {
  const plugin = {
    install(app) {
      app.config.globalProperties.$unhead = head;
      app.config.globalProperties.$head = head;
      app.provide(headSymbol, head);
    }
  };
  return plugin.install;
}

const VueResolver = /* @__PURE__ */ Object.assign(
  (_, value) => isRef(value) ? toValue(value) : value,
  // identity for plain non-reactive values, so the SSR default init entry
  // keeps its precomputed fast path (see unhead/server createHead)
  { _static: true }
);

// @__NO_SIDE_EFFECTS__
function createHead(options = {}) {
  const head = createHead$1({
    ...options,
    propResolvers: [VueResolver]
  });
  head.install = vueInstall(head);
  return head;
}

const legacyPlugins = [DeprecationsPlugin, PromisesPlugin, TemplateParamsPlugin, AliasSortingPlugin];

const unheadOptions = {
  disableDefaults: true,
  plugins: legacyPlugins,
};

const renderSSRHeadOptions = {"omitLineBreaks":true};

const NUXT_PRERENDER_NO_SSR_ROUTES = ["/index.html","/200.html","/404.html"];
const NUXT_NO_SCRIPTS_PATTERNS = [];
const NUXT_PAGE_PATTERNS = ["/site/manager","/site/manager/download","/site/manager/link","/site/manager/nav","/site/manager/project","/discover","/download","/download/:id","/link","/nav","/project","/project/:id","/read","/read/category/:id","/read/post/:id","/search","/tool","/tool/category/:id","/tool/detail","/tool/detail/Base64Convert","/tool/detail/CssGlassGenerates","/tool/detail/CSSGradient","/tool/detail/DownloadM3U8","/tool/detail/EnglistConvert","/tool/detail/FancyBorderRadius","/tool/detail/FlvPlayer","/tool/detail/ImageToBase64","/tool/detail/M3U8V2Pro","/tool/detail/MakePhrase","/tool/detail/MasterTyping","/tool/detail/NationalDayAvatar","/tool/detail/NPlayer","/tool/detail/PayTest","/tool/detail/PngToSVG","/tool/detail/ScreenRec","/tool/detail/TextDistinct","/tool/detail/TextSecret","/tool/detail/Timestamp","/tool/detail/TraceReplay","/tool/detail/UnicodeConvert","/tool/detail/WeiBoGenerates","/tool/detail/Whois","/tool/detail/WordToPDF","/tool/detail/YinHeOSCode","/user","/user/create","/user/favorites","/user/info","/user/order","/writer","/"];
const NUXT_SSR_STREAMING = false;
const appHead = {"meta":[{"name":"viewport","content":"width=device-width, initial-scale=1"},{"charset":"utf-8"},{"name":"theme-color","content":"#F7F4EE"},{"name":"format-detection","content":"telephone=no"},{"name":"description","content":"ZNGG在线工具提供免费在线工具、技术文章、开源项目推荐与软件资源下载，帮助开发者与创作者高效完成工作。"},{"name":"keywords","content":"在线工具,免费在线工具,技术文章,开源项目推荐,软件下载,资源下载,ZNGG"},{"name":"robots","content":"index, follow"},{"property":"og:site_name","content":"ZNGG在线工具"},{"property":"og:locale","content":"zh_CN"},{"property":"og:type","content":"website"},{"name":"twitter:card","content":"summary_large_image"}],"link":[{"rel":"icon","href":"/favicon.ico","sizes":"32x32"},{"rel":"icon","type":"image/svg+xml","href":"/favicon.svg"},{"rel":"icon","type":"image/png","sizes":"32x32","href":"/favicon-32x32.png"},{"rel":"icon","type":"image/png","sizes":"16x16","href":"/favicon-16x16.png"},{"rel":"apple-touch-icon","sizes":"180x180","href":"/apple-touch-icon.png"},{"rel":"manifest","href":"/site.webmanifest"}],"style":[],"script":[{"key":"adsbygoogle-script","defer":true,"crossorigin":"anonymous","src":"//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-6667301035180632"},{"hid":"adsbygoogle","innerHTML":"if (!window.__abg_called){ (window.adsbygoogle = window.adsbygoogle || []); adsbygoogle.pauseAdRequests=0;\n      adsbygoogle.push({\n        google_ad_client: \"ca-pub-6667301035180632\",\n        overlays: {bottom: false},\n        \n      }); window.__abg_called = true;}"}],"noscript":[],"viewport":"width=device-width, initial-scale=1","charset":"utf-8","htmlAttrs":{"lang":"zh-CN"},"title":"ZNGG在线工具 - 在线工具、技术文章与资源下载"};
const appRootTag = "div";
const appRootAttrs = {"id":"__nuxt"};
const appTeleportTag = "div";
const appTeleportAttrs = {"id":"teleports"};
const appSpaLoaderTag = "div";
const appSpaLoaderAttrs = {"id":"__nuxt-loader"};
const appId = "nuxt-app";

//#region src/runtime/handlers/error.ts
var error_default = async function errorhandler(error, event, { defaultHandler }) {
	if (event.handled) return;
	const isRenderingError = !!(event.context.nuxt?.["~rendering-error"] || getFetchedRequestContext(event)?.["~rendering-error"]);
	let errorCause;
	if (isJsonRequest(event)) {
		return;
	}
	const defaultRes = await defaultHandler(error, event, {
		json: true,
		silent: false
	});
	if ((error.status || error.statusCode || 500) === 404 && defaultRes.status === 302) {
		setResponseHeaders(event, defaultRes.headers);
		appendVary(event, "accept, sec-fetch-mode");
		setResponseStatus(event, defaultRes.status, defaultRes.statusText);
		return send(event, JSON.stringify(defaultRes.body, null, 2));
	}
	const errorObject = defaultRes.body;
	const url = new URL(errorObject.url);
	errorObject.url = withoutBase(url.pathname, useRuntimeConfig(event).app.baseURL) + url.search + url.hash;
	errorObject.message = error.unhandled ? errorObject.message || "Server Error" : error.message || errorObject.message || "Server Error";
	if (!error.unhandled) errorObject.data ||= error.data;
	errorObject.statusText ||= error.statusText || error.statusMessage;
	delete defaultRes.headers["content-type"];
	delete defaultRes.headers["content-security-policy"];
	setResponseHeaders(event, defaultRes.headers);
	appendVary(event, "accept, sec-fetch-mode");
	if (!isRenderingError) event.context.nuxt = {
		...event.context.nuxt,
		"~rendering-error": true
	};
	const res = isRenderingError ? null : await useNitroApp().localFetch(withQuery(joinURL(useRuntimeConfig(event).app.baseURL, "/__nuxt_error"), {
		...errorObject,
		...errorCause !== void 0
	}), {
		headers: event.headers,
		redirect: "manual",
		context: { nuxt: { "~rendering-error": true } }
	}).catch(() => null);
	if (event.handled) return;
	if (!res) {
		setResponseHeader(event, "Content-Type", "text/html;charset=UTF-8");
		const { template } = await import('./error-template.mjs');
		return send(event, template(errorObject));
	}
	let html = await res.text();
	for (const [header, value] of res.headers.entries()) {
		if (header === ERROR_PAGE_HEADER) continue;
		if (header === "set-cookie" || header === "x-nitro-prerender") {
			appendResponseHeader(event, header, value);
			continue;
		}
		setResponseHeader(event, header, value);
	}
	setResponseStatus(event, res.status && res.status !== 200 ? res.status : defaultRes.status, res.statusText || defaultRes.statusText);
	return send(event, html);
};
/** Set when the app's own error page could not render. */
const ERROR_PAGE_HEADER = "x-nuxt-error-page";
/**
* Add `value`'s tokens to the response `vary` header, keeping any already
* present. `*` absorbs everything else, since it means the response varies on
* all headers.
*/
function appendVary(event, value) {
	const incoming = parseVary(value);
	if (!incoming.length) return;
	const existing = parseVary(getResponseHeader(event, "vary"));
	if (existing.includes("*")) return;
	if (incoming.includes("*")) {
		setResponseHeader(event, "vary", "*");
		return;
	}
	const merged = existing.slice();
	for (const token of incoming) if (!merged.includes(token)) merged.push(token);
	setResponseHeader(event, "vary", merged.join(", "));
}
function parseVary(value) {
	return (Array.isArray(value) ? value : typeof value === "string" ? value.split(",") : []).map((token) => token.trim().toLowerCase()).filter(Boolean);
}

function defineNitroErrorHandler(handler) {
  return handler;
}

const errorHandler$1 = defineNitroErrorHandler(
  function defaultNitroErrorHandler(error, event) {
    const res = defaultHandler(error, event);
    setResponseHeaders(event, res.headers);
    setResponseStatus(event, res.status, res.statusText);
    return send(event, JSON.stringify(res.body, null, 2));
  }
);
function defaultHandler(error, event, opts) {
  const isSensitive = error.unhandled || error.fatal;
  const statusCode = error.statusCode || 500;
  const statusMessage = error.statusMessage || "Server Error";
  const url = getRequestURL(event, { xForwardedHost: true, xForwardedProto: true });
  if (statusCode === 404) {
    const baseURL = "/";
    if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) {
      const redirectTo = `${baseURL}${url.pathname.slice(1)}${url.search}`;
      return {
        status: 302,
        statusText: "Found",
        headers: { location: redirectTo },
        body: `Redirecting...`
      };
    }
  }
  if (isSensitive && !opts?.silent) {
    const tags = [error.unhandled && "[unhandled]", error.fatal && "[fatal]"].filter(Boolean).join(" ");
    console.error(`[request error] ${tags} [${event.method}] ${url}
`, error);
  }
  const headers = {
    "content-type": "application/json",
    // Prevent browser from guessing the MIME types of resources.
    "x-content-type-options": "nosniff",
    // Prevent error page from being embedded in an iframe
    "x-frame-options": "DENY",
    // Prevent browsers from sending the Referer header
    "referrer-policy": "no-referrer",
    // Disable the execution of any js
    "content-security-policy": "script-src 'none'; frame-ancestors 'none';"
  };
  setResponseStatus(event, statusCode, statusMessage);
  if (statusCode === 404 || !getResponseHeader(event, "cache-control")) {
    headers["cache-control"] = "no-cache";
  }
  const body = {
    error: true,
    url: url.href,
    statusCode,
    statusMessage,
    message: isSensitive ? "Server Error" : error.message,
    data: isSensitive ? void 0 : error.data
  };
  return {
    status: statusCode,
    statusText: statusMessage,
    headers,
    body
  };
}

const errorHandlers = [error_default, errorHandler$1];

async function errorHandler(error, event) {
  for (const handler of errorHandlers) {
    try {
      await handler(error, event, { defaultHandler });
      if (event.handled) {
        return; // Response handled
      }
    } catch(error) {
      // Handler itself thrown, log and continue
      console.error(error);
    }
  }
  // H3 will handle fallback
}

const decodeRoutePath = function decodeRoutePath(path) {
	if (!path.includes("%")) return path;
	const queryIndex = path.indexOf("?");
	const pathname = queryIndex === -1 ? path : path.slice(0, queryIndex);
	try {
		return queryIndex === -1 ? decodeURI(pathname) : decodeURI(pathname) + path.slice(queryIndex);
	} catch {
		return path;
	}
};
const normalizePath = (path, fold) => {
  if (typeof path !== 'string') { return path }
  const decoded = decodeRoutePath(path);
  return fold ? decoded.toLowerCase() : decoded
};
const normalizeRouteRulePath = path => normalizePath(path, true);

//#region src/runtime/utils/route-rules.ts
let matcher;
function getMatcher() {
	if (!matcher) {
		const routes = {};
		for (const [route, rules] of Object.entries(useRuntimeConfig().nitro?.routeRules || {})) routes[normalizeRouteRulePath(route)] = rules;
		matcher = toRouteMatcher(createRouter$1({ routes }));
	}
	return matcher;
}
/**
* Resolve the route rules for a path without the base URL. Keys and path are decoded,
* and case-folded unless routing is `sensitive`.
*/
function matchRouteRules(path) {
	return defu({}, ...getMatcher().matchAll(normalizeRouteRulePath(path)).reverse());
}
/** Resolve the route rules for a request, as {@link matchRouteRules} does for its path. */
function resolveRequestRouteRules(event) {
	return matchRouteRules(withoutBase(event.path.split("?")[0], useRuntimeConfig().app.baseURL));
}
/** The route rules for a request, reusing those already resolved for it. */
function getRouteRules(event) {
	const context = event.context._nitro ||= {};
	return context.routeRules ||= resolveRequestRouteRules(event);
}

//#region src/runtime/plugins/route-rules.ts
var route_rules_default = (nitroApp) => {
	nitroApp.hooks.hook("request", (event) => {
		event.context._nitro ||= {};
		event.context._nitro.routeRules = resolveRequestRouteRules(event);
	});
};

const script = "\"use strict\";(()=>{const o=window,e=document.documentElement,c=[\"dark\",\"light\"],s=getStorageValue(\"localStorage\",\"zngg-theme\")||\"system\";let r=s===\"system\"?f():s;const l=e.getAttribute(\"data-color-mode-forced\");l&&(r=l),i(r),o[\"__NUXT_COLOR_MODE__\"]={preference:s,value:r,getColorScheme:f,addColorScheme:i,removeColorScheme:d};function i(t){const a=\"\"+t+\"\",n=\"\";e.classList?e.classList.add(a):e.className+=\" \"+a,n&&e.setAttribute(\"data-\"+n,t)}function d(t){const a=\"\"+t+\"\",n=\"\";e.classList?e.classList.remove(a):e.className=e.className.replace(new RegExp(a,\"g\"),\"\"),n&&e.removeAttribute(\"data-\"+n)}function u(t){return o.matchMedia(\"(prefers-color-scheme\"+t+\")\")}function f(){if(o.matchMedia&&u(\"\").media!==\"not all\"){for(const t of c)if(u(\":\"+t).matches)return t}return\"light\"}})();function getStorageValue(o,e){switch(o){case\"localStorage\":try{return window.localStorage.getItem(e)}catch{return null}case\"sessionStorage\":try{return window.sessionStorage.getItem(e)}catch{return null}case\"cookie\":try{return getCookie(e)}catch{return null}default:return null}}function getCookie(o){const c=(\"; \"+window.document.cookie).split(\"; \"+o+\"=\");if(c.length===2){const s=c.pop();return s?s.split(\";\").shift():null}}";

const _W5JK3GghhCNQVdtxITtj0q8xDmJm8U_RDYp33C9k54 = (function(nitro) {
  nitro.hooks.hook("render:html", (htmlContext) => {
    htmlContext.head.push(`<script>${script}<\/script>`);
  });
});

const plugins = [
  route_rules_default,
_W5JK3GghhCNQVdtxITtj0q8xDmJm8U_RDYp33C9k54
];

const assets = {
  "/android-chrome-192x192.png": {
    "type": "image/png",
    "etag": "\"7fc-amdN4NAHRO8upcThDESRdgZv/Mg\"",
    "mtime": "2026-10-23T01:48:22.828Z",
    "size": 2044,
    "path": "../public/android-chrome-192x192.png"
  },
  "/.DS_Store": {
    "type": "text/plain; charset=utf-8",
    "etag": "\"1804-sXW8xlUYIalgflrm+ciNJDPmtuA\"",
    "mtime": "2026-10-20T00:18:15.531Z",
    "size": 6148,
    "path": "../public/.DS_Store"
  },
  "/android-chrome-512x512.png": {
    "type": "image/png",
    "etag": "\"11bd-5LgcJNc09B80eE1ZXVB2MD+OwFw\"",
    "mtime": "2026-10-23T01:48:22.850Z",
    "size": 4541,
    "path": "../public/android-chrome-512x512.png"
  },
  "/apple-touch-icon.png": {
    "type": "image/png",
    "etag": "\"7c0-FUibpPLnhKyn0taHrPObKekX8Cs\"",
    "mtime": "2026-10-23T01:48:22.815Z",
    "size": 1984,
    "path": "../public/apple-touch-icon.png"
  },
  "/favicon-16x16.png": {
    "type": "image/png",
    "etag": "\"246-zefh9sdhl2klh+uqRPm7IJBkPck\"",
    "mtime": "2026-10-23T01:48:22.777Z",
    "size": 582,
    "path": "../public/favicon-16x16.png"
  },
  "/favicon-32x32.png": {
    "type": "image/png",
    "etag": "\"3f8-iDejafWDjq/SiXZYp7Enz041HXY\"",
    "mtime": "2026-10-23T01:48:22.786Z",
    "size": 1016,
    "path": "../public/favicon-32x32.png"
  },
  "/favicon.svg": {
    "type": "image/svg+xml",
    "etag": "\"ef-0r3PXejGIS7Jkqgd4KZ8zbs1CWM\"",
    "mtime": "2026-10-23T01:48:34.481Z",
    "size": 239,
    "path": "../public/favicon.svg"
  },
  "/favicon.ico": {
    "type": "image/vnd.microsoft.icon",
    "etag": "\"bbe-4Vpo7k9679Gq4RymZDWueuTtQRQ\"",
    "mtime": "2026-10-23T01:48:34.515Z",
    "size": 3006,
    "path": "../public/favicon.ico"
  },
  "/img.webp": {
    "type": "image/webp",
    "etag": "\"1e6c-oIg/LP8CJN12q7jJqk3+6YiAAAE\"",
    "mtime": "2026-10-20T00:18:15.550Z",
    "size": 7788,
    "path": "../public/img.webp"
  },
  "/logo-black.png": {
    "type": "image/png",
    "etag": "\"f8b-T8DaUF6cMVuOtlmcWFTPSg9vRVc\"",
    "mtime": "2026-10-20T00:18:15.569Z",
    "size": 3979,
    "path": "../public/logo-black.png"
  },
  "/robots.txt": {
    "type": "text/plain; charset=utf-8",
    "etag": "\"7d-oWuRFmD+QDRt3E3RlgrtaCrS43s\"",
    "mtime": "2026-10-23T01:23:32.628Z",
    "size": 125,
    "path": "../public/robots.txt"
  },
  "/logo-white.png": {
    "type": "image/png",
    "etag": "\"12cd-7OgD0z7K6PlLKpDr28fqJyPhyDU\"",
    "mtime": "2026-10-20T00:18:15.570Z",
    "size": 4813,
    "path": "../public/logo-white.png"
  },
  "/ad/NplayerAD.jpg": {
    "type": "image/jpeg",
    "etag": "\"2d23-Ky4mH50Jri8zH03Wz47dcElUEhw\"",
    "mtime": "2026-10-20T00:18:15.531Z",
    "size": 11555,
    "path": "../public/ad/NplayerAD.jpg"
  },
  "/site.webmanifest": {
    "type": "application/manifest+json",
    "etag": "\"293-jSFF9nbZtOJJGUoB5M2YoJJbVQ8\"",
    "mtime": "2026-10-23T01:48:34.481Z",
    "size": 659,
    "path": "../public/site.webmanifest"
  },
  "/ad/rdmeLogo.jpg": {
    "type": "image/jpeg",
    "etag": "\"dd95-rlThXGSm31ogZT7BoYWWbraulZ4\"",
    "mtime": "2026-10-20T00:18:15.532Z",
    "size": 56725,
    "path": "../public/ad/rdmeLogo.jpg"
  },
  "/ad/ScreenRecAD.jpg": {
    "type": "image/jpeg",
    "etag": "\"6206-FtxjGTP1NKdNxUwffKLo4T0sIQU\"",
    "mtime": "2026-10-20T00:18:15.531Z",
    "size": 25094,
    "path": "../public/ad/ScreenRecAD.jpg"
  },
  "/css/bytemd.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"37f3-Egb/vixSwe9eTdYFNSmgvpCpxi8\"",
    "mtime": "2026-10-20T00:18:15.532Z",
    "size": 14323,
    "path": "../public/css/bytemd.css"
  },
  "/fonts/katex.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"7501-EL6HwxSYEgZDJyYUDqzQdnjih3s\"",
    "mtime": "2026-10-20T00:18:15.550Z",
    "size": 29953,
    "path": "../public/fonts/katex.min.css"
  },
  "/fonts/weibo_icon.woff": {
    "type": "font/woff",
    "etag": "\"65c4-RplHD7zUj5XjekJ5byK0RMoDUAg\"",
    "mtime": "2026-10-20T00:18:15.550Z",
    "size": 26052,
    "path": "../public/fonts/weibo_icon.woff"
  },
  "/css/cssgradient.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"731f-5AtltlARkGwYAVLjx7kEDwPt+xc\"",
    "mtime": "2026-10-20T00:18:15.532Z",
    "size": 29471,
    "path": "../public/css/cssgradient.css"
  },
  "/fonts/weibo_icon2.woff2": {
    "type": "font/woff2",
    "etag": "\"51e4-dFLYXNUPFJZwfOjvMHerJs1CUN4\"",
    "mtime": "2026-10-20T00:18:15.550Z",
    "size": 20964,
    "path": "../public/fonts/weibo_icon2.woff2"
  },
  "/img/.DS_Store": {
    "type": "text/plain; charset=utf-8",
    "etag": "\"1804-A6iDM1hmpJ5kwGb9dc9W5cp842U\"",
    "mtime": "2026-10-20T00:18:15.551Z",
    "size": 6148,
    "path": "../public/img/.DS_Store"
  },
  "/img/avatar.jpg": {
    "type": "image/jpeg",
    "etag": "\"939c-NrxYRAasNNTniegdscxu31iXb/M\"",
    "mtime": "2026-10-20T00:18:15.561Z",
    "size": 37788,
    "path": "../public/img/avatar.jpg"
  },
  "/img/model-bg.png": {
    "type": "image/png",
    "etag": "\"4e19-jxswg8YFzrMFE2g0ZUeC9GQM8p8\"",
    "mtime": "2026-10-20T00:18:15.562Z",
    "size": 19993,
    "path": "../public/img/model-bg.png"
  },
  "/img/tool-Base64Convert.svg": {
    "type": "image/svg+xml",
    "etag": "\"b49-r46zzNBT0q1XhMkJLLjp027g3V4\"",
    "mtime": "2026-10-20T00:18:15.563Z",
    "size": 2889,
    "path": "../public/img/tool-Base64Convert.svg"
  },
  "/img/paytest.gif": {
    "type": "image/gif",
    "etag": "\"2ed9-4fX/BwvRoEDzBrwN7ulSJ3o0q98\"",
    "mtime": "2026-10-20T00:18:15.563Z",
    "size": 11993,
    "path": "../public/img/paytest.gif"
  },
  "/img/tool-CssGlassGenerates.svg": {
    "type": "image/svg+xml",
    "etag": "\"2ce-1bUw9Bku540HbkC9sSdCJQc7IGI\"",
    "mtime": "2026-10-20T00:18:15.563Z",
    "size": 718,
    "path": "../public/img/tool-CssGlassGenerates.svg"
  },
  "/img/tool-cover.webp": {
    "type": "image/webp",
    "etag": "\"47f8-oriNmSyXqXRq/e+EU5tie/3REWM\"",
    "mtime": "2026-10-20T00:18:15.566Z",
    "size": 18424,
    "path": "../public/img/tool-cover.webp"
  },
  "/img/tool-CSSGradient.svg": {
    "type": "image/svg+xml",
    "etag": "\"32f-sM2yhA13hnUSG3fQFqiYFlWVNm8\"",
    "mtime": "2026-10-20T00:18:15.563Z",
    "size": 815,
    "path": "../public/img/tool-CSSGradient.svg"
  },
  "/img/tool-e2E.svg": {
    "type": "image/svg+xml",
    "etag": "\"13b94-4zBMVvb6n2n8ycSBv8nPpE2p+Z8\"",
    "mtime": "2026-10-20T00:18:15.566Z",
    "size": 80788,
    "path": "../public/img/tool-e2E.svg"
  },
  "/img/tool-DownloadM3U8.svg": {
    "type": "image/svg+xml",
    "etag": "\"4f8-oTnMCZMQbHtalSEUGc2FJCQjTN8\"",
    "mtime": "2026-10-20T00:18:15.563Z",
    "size": 1272,
    "path": "../public/img/tool-DownloadM3U8.svg"
  },
  "/img/tool-FlvPlayer.svg": {
    "type": "image/svg+xml",
    "etag": "\"b81-bYM9lbtt0yTLuq5Oj9Lv9Hru/nI\"",
    "mtime": "2026-10-20T00:18:15.563Z",
    "size": 2945,
    "path": "../public/img/tool-FlvPlayer.svg"
  },
  "/img/tool-FancyBorderRadius.svg": {
    "type": "image/svg+xml",
    "etag": "\"aaa-VPrcN7r/UyEu5W/09b5i2vMNK3s\"",
    "mtime": "2026-10-20T00:18:15.563Z",
    "size": 2730,
    "path": "../public/img/tool-FancyBorderRadius.svg"
  },
  "/img/tool-ImageToBase64.svg": {
    "type": "image/svg+xml",
    "etag": "\"6e6-Hl0WH5O7T4fl1QtZC5TZ+gcwhdY\"",
    "mtime": "2026-10-20T00:18:15.564Z",
    "size": 1766,
    "path": "../public/img/tool-ImageToBase64.svg"
  },
  "/img/tool-ImgToText.svg": {
    "type": "image/svg+xml",
    "etag": "\"91f-9OE0Y2ssZ0svBCTmW28wpFYVwiY\"",
    "mtime": "2026-10-20T00:18:15.564Z",
    "size": 2335,
    "path": "../public/img/tool-ImgToText.svg"
  },
  "/img/tool-M3U8V2Pro.svg": {
    "type": "image/svg+xml",
    "etag": "\"4f8-VK5G1j7+nmmgLoGe3bg9Xr+Hd/w\"",
    "mtime": "2026-10-20T00:18:15.564Z",
    "size": 1272,
    "path": "../public/img/tool-M3U8V2Pro.svg"
  },
  "/img/tool-MakePhrase.svg": {
    "type": "image/svg+xml",
    "etag": "\"1616-L7QlpHv+lNsphNOr3AGQ3mO5GgM\"",
    "mtime": "2026-10-20T00:18:15.564Z",
    "size": 5654,
    "path": "../public/img/tool-MakePhrase.svg"
  },
  "/img/tool-NPlayer.svg": {
    "type": "image/svg+xml",
    "etag": "\"f77-IH+ycoLEf3ZlghfOPzY4Ch4KC2g\"",
    "mtime": "2026-10-20T00:18:15.564Z",
    "size": 3959,
    "path": "../public/img/tool-NPlayer.svg"
  },
  "/img/tool-PngToSvg.svg": {
    "type": "image/svg+xml",
    "etag": "\"1ff7-fxTO+EtUdlNH6mlJKXy2KT0dpKc\"",
    "mtime": "2026-10-20T00:18:15.565Z",
    "size": 8183,
    "path": "../public/img/tool-PngToSvg.svg"
  },
  "/img/tool-ScreenRec.svg": {
    "type": "image/svg+xml",
    "etag": "\"716-euJusrgEmxL5t0hubyPmZ3O/6Os\"",
    "mtime": "2026-10-20T00:18:15.565Z",
    "size": 1814,
    "path": "../public/img/tool-ScreenRec.svg"
  },
  "/img/tool-NationalDayAvatar.png": {
    "type": "image/png",
    "etag": "\"e6c-VEiIcZ9KHHG9ddobhIZOYLMYOT4\"",
    "mtime": "2026-10-20T00:18:15.565Z",
    "size": 3692,
    "path": "../public/img/tool-NationalDayAvatar.png"
  },
  "/img/tool-TextDistinct.svg": {
    "type": "image/svg+xml",
    "etag": "\"aa4-1F61ogT1p8w6Y2muDDTLjxAug6M\"",
    "mtime": "2026-10-20T00:18:15.565Z",
    "size": 2724,
    "path": "../public/img/tool-TextDistinct.svg"
  },
  "/img/tool-TextSecret.svg": {
    "type": "image/svg+xml",
    "etag": "\"721-2wVvFuRseNytiPSf6TquDFJo5pI\"",
    "mtime": "2026-10-20T00:18:15.565Z",
    "size": 1825,
    "path": "../public/img/tool-TextSecret.svg"
  },
  "/img/tool-timestamp.svg": {
    "type": "image/svg+xml",
    "etag": "\"99a-bYkNPTNqgRa5YpQl3L/Ho9rTsrU\"",
    "mtime": "2026-10-20T00:18:15.567Z",
    "size": 2458,
    "path": "../public/img/tool-timestamp.svg"
  },
  "/img/tool-WeiBoGenerates.svg": {
    "type": "image/svg+xml",
    "etag": "\"970-CkB4ABbwewgtF67hYtgmXHkmFIk\"",
    "mtime": "2026-10-20T00:18:15.566Z",
    "size": 2416,
    "path": "../public/img/tool-WeiBoGenerates.svg"
  },
  "/img/tool-UnicodeConvert.svg": {
    "type": "image/svg+xml",
    "etag": "\"b49-ZXbE1ISS7Nd7a2r0AAEEiqY1h/U\"",
    "mtime": "2026-10-20T00:18:15.565Z",
    "size": 2889,
    "path": "../public/img/tool-UnicodeConvert.svg"
  },
  "/js/mux-mp4.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"39715-oBnNBUu7qCl99ptySV9zIAEaEAk\"",
    "mtime": "2026-10-20T00:18:15.569Z",
    "size": 235285,
    "path": "../public/js/mux-mp4.js"
  },
  "/img/tool-WordToPDF.svg": {
    "type": "image/svg+xml",
    "etag": "\"7ce-uAqB+qNV7ggcCFX9pKjJlim5yYk\"",
    "mtime": "2026-10-20T00:18:15.566Z",
    "size": 1998,
    "path": "../public/img/tool-WordToPDF.svg"
  },
  "/img/tool-Whois.svg": {
    "type": "image/svg+xml",
    "etag": "\"9d9-uwiCnzye1JntI6WFkI+8UyGuCRI\"",
    "mtime": "2026-10-20T00:18:15.566Z",
    "size": 2521,
    "path": "../public/img/tool-Whois.svg"
  },
  "/img/XGPlayer.png": {
    "type": "image/png",
    "etag": "\"de2-/suJGH1La/EuOy9OWmjJpGY2JAA\"",
    "mtime": "2026-10-20T00:18:15.561Z",
    "size": 3554,
    "path": "../public/img/XGPlayer.png"
  },
  "/_nuxt/a239vn4c.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"77e-KGRE4CBt3N9rQEPpZLOuHv4KKv8\"",
    "mtime": "2026-10-23T01:52:27.330Z",
    "size": 1918,
    "path": "../public/_nuxt/a239vn4c.js"
  },
  "/_nuxt/AdJ2m8Ja.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"dd-MrOD8WzgA/QMUITY5/rhKBzztio\"",
    "mtime": "2026-10-23T01:52:27.271Z",
    "size": 221,
    "path": "../public/_nuxt/AdJ2m8Ja.js"
  },
  "/_nuxt/Adsbygoogle.CswjguNp.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"36-zTAm0YxMZOiPUrNGfqm4sWypKXk\"",
    "mtime": "2026-10-23T01:52:27.334Z",
    "size": 54,
    "path": "../public/_nuxt/Adsbygoogle.CswjguNp.css"
  },
  "/_nuxt/5vdsilyf.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"50b-0rq3MfPB6mXF4gT9sYYxRj9m48A\"",
    "mtime": "2026-10-23T01:52:27.271Z",
    "size": 1291,
    "path": "../public/_nuxt/5vdsilyf.js"
  },
  "/_nuxt/AN-IDt-y.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1b4f-NTCTLOvpnEA7zdByg0zq/jaEv/c\"",
    "mtime": "2026-10-23T01:52:27.271Z",
    "size": 6991,
    "path": "../public/_nuxt/AN-IDt-y.js"
  },
  "/_nuxt/atom-one-dark.DX1W2tKP.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"359-3YCvHjeuWLze+k2fhm5IM5WA4zQ\"",
    "mtime": "2026-10-23T01:52:27.337Z",
    "size": 857,
    "path": "../public/_nuxt/atom-one-dark.DX1W2tKP.css"
  },
  "/_nuxt/5Hf4q38e.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"f61-2h2Mz1FbE5sjxUaAcoWgqnHPVTQ\"",
    "mtime": "2026-10-23T01:52:27.271Z",
    "size": 3937,
    "path": "../public/_nuxt/5Hf4q38e.js"
  },
  "/_nuxt/B0L28_2g.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"720-DlvOVUw+F4i0ijYdqEYx327FJ6g\"",
    "mtime": "2026-10-23T01:52:27.272Z",
    "size": 1824,
    "path": "../public/_nuxt/B0L28_2g.js"
  },
  "/_nuxt/B0BfcTAY.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"a34-Rt//+ptStczxbPJeK/7Ytm4t1g0\"",
    "mtime": "2026-10-23T01:52:27.271Z",
    "size": 2612,
    "path": "../public/_nuxt/B0BfcTAY.js"
  },
  "/_nuxt/B2C4oAfi.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"dd-MrOD8WzgA/QMUITY5/rhKBzztio\"",
    "mtime": "2026-10-23T01:52:27.272Z",
    "size": 221,
    "path": "../public/_nuxt/B2C4oAfi.js"
  },
  "/_nuxt/B55ncxov.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"8b4-vTs/q91IemtpRZhbw1cSs8WkR2M\"",
    "mtime": "2026-10-23T01:52:27.272Z",
    "size": 2228,
    "path": "../public/_nuxt/B55ncxov.js"
  },
  "/_nuxt/B5JXtMYc.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"e22-WUAxHSdZel0WmmbIZlGhkoVOOeI\"",
    "mtime": "2026-10-23T01:52:27.274Z",
    "size": 3618,
    "path": "../public/_nuxt/B5JXtMYc.js"
  },
  "/_nuxt/B1rx514R.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"8d10-T9yKMs1Si+rkwRS6ArU618r2GNI\"",
    "mtime": "2026-10-23T01:52:27.272Z",
    "size": 36112,
    "path": "../public/_nuxt/B1rx514R.js"
  },
  "/_nuxt/B7REMIyX.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"30a-edcuky2osa6J/IOVtT5rVFmCV2E\"",
    "mtime": "2026-10-23T01:52:27.275Z",
    "size": 778,
    "path": "../public/_nuxt/B7REMIyX.js"
  },
  "/_nuxt/B9A28_Y2.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"42c-D1yW1EnOTJ0+Goz8Lr04Yweca6w\"",
    "mtime": "2026-10-23T01:52:27.275Z",
    "size": 1068,
    "path": "../public/_nuxt/B9A28_Y2.js"
  },
  "/_nuxt/bBm2T0bl.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"108d-7neGQoUHn4z7RRaHnVE0+FpJ0cQ\"",
    "mtime": "2026-10-23T01:52:27.330Z",
    "size": 4237,
    "path": "../public/_nuxt/bBm2T0bl.js"
  },
  "/_nuxt/BCiCTKAo.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"515-c5zke0F2ze7SnnJuvy4Bro6y7GE\"",
    "mtime": "2026-10-23T01:52:27.275Z",
    "size": 1301,
    "path": "../public/_nuxt/BCiCTKAo.js"
  },
  "/js/mux-mp4.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"117fd-V8Q5tYC0/QALpSVuMwNk+/OYTbk\"",
    "mtime": "2026-10-20T00:18:15.569Z",
    "size": 71677,
    "path": "../public/js/mux-mp4.min.js"
  },
  "/_nuxt/BarR4Ze1.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1536-o7Rj5LN/HphwfzBXA8szEZF0dxc\"",
    "mtime": "2026-10-23T01:52:27.299Z",
    "size": 5430,
    "path": "../public/_nuxt/BarR4Ze1.js"
  },
  "/_nuxt/BcNOAZOA.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"e88-ymEKBw6rVg5WGO5xU9bDx3C0NUE\"",
    "mtime": "2026-10-23T01:52:27.299Z",
    "size": 3720,
    "path": "../public/_nuxt/BcNOAZOA.js"
  },
  "/_nuxt/B7hYAp2z.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"29b79-nMvu3PJc0QMddCrkNI9T0Rro128\"",
    "mtime": "2026-10-23T01:52:27.275Z",
    "size": 170873,
    "path": "../public/_nuxt/B7hYAp2z.js"
  },
  "/_nuxt/BgHLnROf.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"e4b-mJ/ReSwJPJhYXTYzGKcf3FeDhn4\"",
    "mtime": "2026-10-23T01:52:27.300Z",
    "size": 3659,
    "path": "../public/_nuxt/BgHLnROf.js"
  },
  "/_nuxt/BgOMe2_B.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"7b0-fGP90uE7DRI20DZX/q3qkBlnPpI\"",
    "mtime": "2026-10-23T01:52:27.300Z",
    "size": 1968,
    "path": "../public/_nuxt/BgOMe2_B.js"
  },
  "/_nuxt/BdU6ZTXP.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"11d9-9L6TthE0JtJdbsSCwNdavlifxTE\"",
    "mtime": "2026-10-23T01:52:27.299Z",
    "size": 4569,
    "path": "../public/_nuxt/BdU6ZTXP.js"
  },
  "/_nuxt/BhScwOcc.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"de2-fWj/9GzeXvISn8A1p544+pRAjWU\"",
    "mtime": "2026-10-23T01:52:27.300Z",
    "size": 3554,
    "path": "../public/_nuxt/BhScwOcc.js"
  },
  "/_nuxt/bFhKB-W7.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2ec5e-T3bSnFC9bh6nv1R6Q76zmnE7BGo\"",
    "mtime": "2026-10-23T01:52:27.330Z",
    "size": 191582,
    "path": "../public/_nuxt/bFhKB-W7.js"
  },
  "/_nuxt/BdS7Rupl.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1345-i4FFg9LZTJ5aqJOXkYmT9PWqPBA\"",
    "mtime": "2026-10-23T01:52:27.299Z",
    "size": 4933,
    "path": "../public/_nuxt/BdS7Rupl.js"
  },
  "/_nuxt/BKLwPiPA.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"808-CSqiehi0ga+WXzryKNzaJakhSeI\"",
    "mtime": "2026-10-23T01:52:27.288Z",
    "size": 2056,
    "path": "../public/_nuxt/BKLwPiPA.js"
  },
  "/_nuxt/BKKLERsf.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"f9b-aHlUvzyjKirV3nibl1jSEYfIxns\"",
    "mtime": "2026-10-23T01:52:27.287Z",
    "size": 3995,
    "path": "../public/_nuxt/BKKLERsf.js"
  },
  "/_nuxt/BLex9sBS.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"cb51-JdUyjybw4ohZrqiN3U6zCbgQ0NI\"",
    "mtime": "2026-10-23T01:52:27.290Z",
    "size": 52049,
    "path": "../public/_nuxt/BLex9sBS.js"
  },
  "/_nuxt/BNmdbDcq.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"79bd-l98zUR6cPQ8salQb5mPIx9LsxOk\"",
    "mtime": "2026-10-23T01:52:27.293Z",
    "size": 31165,
    "path": "../public/_nuxt/BNmdbDcq.js"
  },
  "/_nuxt/BM7OVCkf.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"a8c1-4C0rJBw44d7r8v2ESR2yo4r3qXo\"",
    "mtime": "2026-10-23T01:52:27.293Z",
    "size": 43201,
    "path": "../public/_nuxt/BM7OVCkf.js"
  },
  "/_nuxt/BpsbtLrv.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3b-05gHjL6du6D5MEzGA/1uAthFik0\"",
    "mtime": "2026-10-23T01:52:27.300Z",
    "size": 59,
    "path": "../public/_nuxt/BpsbtLrv.js"
  },
  "/_nuxt/BnwEIijn.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"4676-v6uiVjxnYHwSCVV6gI3LBgP8Tjc\"",
    "mtime": "2026-10-23T01:52:27.300Z",
    "size": 18038,
    "path": "../public/_nuxt/BnwEIijn.js"
  },
  "/_nuxt/BO3GLd5q.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"213f-unCM80dg84F4JGepA/BVIuTG3pI\"",
    "mtime": "2026-10-23T01:52:27.293Z",
    "size": 8511,
    "path": "../public/_nuxt/BO3GLd5q.js"
  },
  "/_nuxt/BrpMAxM_.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"424-aFHNWPIxaQ+0XTTLUhHYJr1dzos\"",
    "mtime": "2026-10-23T01:52:27.300Z",
    "size": 1060,
    "path": "../public/_nuxt/BrpMAxM_.js"
  },
  "/_nuxt/BsHA2zDz.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2edb-IEL7YUmTTzg8yg+FBCnUujbnJ4o\"",
    "mtime": "2026-10-23T01:52:27.301Z",
    "size": 11995,
    "path": "../public/_nuxt/BsHA2zDz.js"
  },
  "/_nuxt/BSeSttW7.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"22f1-zKCZ5t7TDPB+uwrulYCBlburzHM\"",
    "mtime": "2026-10-23T01:52:27.294Z",
    "size": 8945,
    "path": "../public/_nuxt/BSeSttW7.js"
  },
  "/_nuxt/BSJj0jLr.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1db-xDzzoFSEENDWDWEg7EFfYJ/wokI\"",
    "mtime": "2026-10-23T01:52:27.294Z",
    "size": 475,
    "path": "../public/_nuxt/BSJj0jLr.js"
  },
  "/_nuxt/BuEf26B0.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"12a0-QkXvE1t+RUw530Kr7VMNVXCnUu8\"",
    "mtime": "2026-10-23T01:52:27.301Z",
    "size": 4768,
    "path": "../public/_nuxt/BuEf26B0.js"
  },
  "/_nuxt/BsHgCrll.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"7f7-IPVeYuaRbmUdanKY839b94jCzfI\"",
    "mtime": "2026-10-23T01:52:27.301Z",
    "size": 2039,
    "path": "../public/_nuxt/BsHgCrll.js"
  },
  "/_nuxt/BWWnsEbC.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1fc-lF3rLsq1SjkA3jdxtf1M03WgarQ\"",
    "mtime": "2026-10-23T01:52:27.295Z",
    "size": 508,
    "path": "../public/_nuxt/BWWnsEbC.js"
  },
  "/_nuxt/BWLdl4zo.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"187a-arBSCpktXBtieJYWwLpu/EmcP6U\"",
    "mtime": "2026-10-23T01:52:27.295Z",
    "size": 6266,
    "path": "../public/_nuxt/BWLdl4zo.js"
  },
  "/_nuxt/BXAwdRP_.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"25d6-glWYDtxMg4h1okbKy6aKIqTTcu8\"",
    "mtime": "2026-10-23T01:52:27.295Z",
    "size": 9686,
    "path": "../public/_nuxt/BXAwdRP_.js"
  },
  "/_nuxt/C2Vytuwc.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"11db-f7+44KgOwa8rrQi2b7QReAboKGU\"",
    "mtime": "2026-10-23T01:52:27.301Z",
    "size": 4571,
    "path": "../public/_nuxt/C2Vytuwc.js"
  },
  "/_nuxt/C40TT6hQ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"c7-P8cxwjRqv28Bx2D5t7daJNiswPU\"",
    "mtime": "2026-10-23T01:52:27.302Z",
    "size": 199,
    "path": "../public/_nuxt/C40TT6hQ.js"
  },
  "/_nuxt/C2YUKZxw.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"ee7-1qb0scHRLFDCxliT6wvGMHmSE2M\"",
    "mtime": "2026-10-23T01:52:27.302Z",
    "size": 3815,
    "path": "../public/_nuxt/C2YUKZxw.js"
  },
  "/_nuxt/C9SxTtmq.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"a2b-KBFEQRoZx/AWulrn6uzl+iI29Fw\"",
    "mtime": "2026-10-23T01:52:27.303Z",
    "size": 2603,
    "path": "../public/_nuxt/C9SxTtmq.js"
  },
  "/_nuxt/CAgHYBVA.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"15b-nFyK2V5ldA97d2ED9uHj3BecCRg\"",
    "mtime": "2026-10-23T01:52:27.303Z",
    "size": 347,
    "path": "../public/_nuxt/CAgHYBVA.js"
  },
  "/_nuxt/CcEyb4lT.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"d2-oNG8f21W1haSkDWUPztRzyEpK30\"",
    "mtime": "2026-10-23T01:52:27.306Z",
    "size": 210,
    "path": "../public/_nuxt/CcEyb4lT.js"
  },
  "/_nuxt/CdG1DqQ5.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"26e-DUax0RpBmijZkEWK6ih6TXXA/4M\"",
    "mtime": "2026-10-23T01:52:27.306Z",
    "size": 622,
    "path": "../public/_nuxt/CdG1DqQ5.js"
  },
  "/_nuxt/CDXfaFGV.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2da5-eL++I4gBohRdILQuLCz3yRsPV/s\"",
    "mtime": "2026-10-23T01:52:27.303Z",
    "size": 11685,
    "path": "../public/_nuxt/CDXfaFGV.js"
  },
  "/_nuxt/CdXUvYwA.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"9d7-y7GOAp8fz+EP4nAMhX7pEvTc2/s\"",
    "mtime": "2026-10-23T01:52:27.306Z",
    "size": 2519,
    "path": "../public/_nuxt/CdXUvYwA.js"
  },
  "/_nuxt/CeDzvSgz.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1ba9-PmUwf227PyPOHXfEV2AgiRYBtgk\"",
    "mtime": "2026-10-23T01:52:27.306Z",
    "size": 7081,
    "path": "../public/_nuxt/CeDzvSgz.js"
  },
  "/_nuxt/Bziva5SC.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"71ecc-tbqxd2PcCtlh8Ixg20z1lTsXatg\"",
    "mtime": "2026-10-23T01:52:27.301Z",
    "size": 466636,
    "path": "../public/_nuxt/Bziva5SC.js"
  },
  "/_nuxt/CEgWCtue.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"31-YFUE0K4jHGo7t5TxBPOuD3zAcIM\"",
    "mtime": "2026-10-23T01:52:27.303Z",
    "size": 49,
    "path": "../public/_nuxt/CEgWCtue.js"
  },
  "/_nuxt/CIyD4wa-.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"dd-MrOD8WzgA/QMUITY5/rhKBzztio\"",
    "mtime": "2026-10-23T01:52:27.303Z",
    "size": 221,
    "path": "../public/_nuxt/CIyD4wa-.js"
  },
  "/_nuxt/CFaW_FoZ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3665-n3AH2peP5hOR4PQqAxha4htRGtM\"",
    "mtime": "2026-10-23T01:52:27.303Z",
    "size": 13925,
    "path": "../public/_nuxt/CFaW_FoZ.js"
  },
  "/_nuxt/CJuvGvET.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"fe-+IxxZEIURV6wGfGNtGRgFBXww58\"",
    "mtime": "2026-10-23T01:52:27.303Z",
    "size": 254,
    "path": "../public/_nuxt/CJuvGvET.js"
  },
  "/_nuxt/Cg6qNOaA.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2342-CXr1iSaJZ/xirkwtSymSL7+HZAM\"",
    "mtime": "2026-10-23T01:52:27.307Z",
    "size": 9026,
    "path": "../public/_nuxt/Cg6qNOaA.js"
  },
  "/_nuxt/C3xnj55q.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"6d061-GOmCEVC2h1FTLBzwO/xHCZGriKs\"",
    "mtime": "2026-10-23T01:52:27.302Z",
    "size": 446561,
    "path": "../public/_nuxt/C3xnj55q.js"
  },
  "/_nuxt/Cj_TdV8t.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"ef7-M7LwLn1Nk0j7yB/9oyFcEM3WQbs\"",
    "mtime": "2026-10-23T01:52:27.307Z",
    "size": 3831,
    "path": "../public/_nuxt/Cj_TdV8t.js"
  },
  "/_nuxt/Cmaib_an.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"144d-Gx2riOQPIZxFR2Kde0gGiiwdufM\"",
    "mtime": "2026-10-23T01:52:27.320Z",
    "size": 5197,
    "path": "../public/_nuxt/Cmaib_an.js"
  },
  "/_nuxt/CMrNq-9o.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"8b9-VM0e6+Kywi2bd9Zyuf242vIGhc4\"",
    "mtime": "2026-10-23T01:52:27.304Z",
    "size": 2233,
    "path": "../public/_nuxt/CMrNq-9o.js"
  },
  "/_nuxt/CnLw2stB.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"57e-rebxIfY2KG/VARkAYx0lk4U1jJU\"",
    "mtime": "2026-10-23T01:52:27.321Z",
    "size": 1406,
    "path": "../public/_nuxt/CnLw2stB.js"
  },
  "/_nuxt/CNsQt1vr.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"9db-Xj/+Jaw4s3QefyTEnnmtlQ0kN7M\"",
    "mtime": "2026-10-23T01:52:27.304Z",
    "size": 2523,
    "path": "../public/_nuxt/CNsQt1vr.js"
  },
  "/_nuxt/CMTNekQQ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"12ce3-USvmrXzgsBtAwKESXN3Fy1bnIFI\"",
    "mtime": "2026-10-23T01:52:27.304Z",
    "size": 77027,
    "path": "../public/_nuxt/CMTNekQQ.js"
  },
  "/_nuxt/CQsBGDsJ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"a5-s9tfzfaNftacgrTUMUNzA+XJv64\"",
    "mtime": "2026-10-23T01:52:27.305Z",
    "size": 165,
    "path": "../public/_nuxt/CQsBGDsJ.js"
  },
  "/_nuxt/CmBBfq8d.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2429-iDYIO5qoLhIniynu6odJpYtTeeI\"",
    "mtime": "2026-10-23T01:52:27.320Z",
    "size": 9257,
    "path": "../public/_nuxt/CmBBfq8d.js"
  },
  "/_nuxt/CRVlbAAb.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"12b-ez9J9ERx/Xkt5bFlqMJcxxb/Drw\"",
    "mtime": "2026-10-23T01:52:27.305Z",
    "size": 299,
    "path": "../public/_nuxt/CRVlbAAb.js"
  },
  "/_nuxt/CQyBpdaD.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"14c6-iQMaPLnhiG3jePETtuKVFxPXoBc\"",
    "mtime": "2026-10-23T01:52:27.305Z",
    "size": 5318,
    "path": "../public/_nuxt/CQyBpdaD.js"
  },
  "/_nuxt/CssGlassGenerates.DHMlCyoe.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"eb5-i/OeWXk8ItVsg4oY9yEeZuwfXPU\"",
    "mtime": "2026-10-23T01:52:27.334Z",
    "size": 3765,
    "path": "../public/_nuxt/CssGlassGenerates.DHMlCyoe.css"
  },
  "/_nuxt/CsqJ5Xw1.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"669-D+fd7J3TNsOZbPsRULyhLuzP1aw\"",
    "mtime": "2026-10-23T01:52:27.321Z",
    "size": 1641,
    "path": "../public/_nuxt/CsqJ5Xw1.js"
  },
  "/_nuxt/CSvR2GDm.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"b1-rAg/faClPjjUg+ixocPCRoZzwFc\"",
    "mtime": "2026-10-23T01:52:27.305Z",
    "size": 177,
    "path": "../public/_nuxt/CSvR2GDm.js"
  },
  "/_nuxt/Cv9wkX1C.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"ecb-fmP8OrMJ9Ssv4hTV5WtXzmESqjY\"",
    "mtime": "2026-10-23T01:52:27.321Z",
    "size": 3787,
    "path": "../public/_nuxt/Cv9wkX1C.js"
  },
  "/_nuxt/CXvQWzUj.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"b1-FSEcH3zm2oAhXF0E1ZvYsVqQITA\"",
    "mtime": "2026-10-23T01:52:27.305Z",
    "size": 177,
    "path": "../public/_nuxt/CXvQWzUj.js"
  },
  "/_nuxt/CU3W-tSx.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2476a-eNwTnSGNzfOAjkeFwR8/8qEYbZg\"",
    "mtime": "2026-10-23T01:52:27.271Z",
    "size": 149354,
    "path": "../public/_nuxt/CU3W-tSx.js"
  },
  "/_nuxt/CyIsLhoS.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"df-b17rZ0DT/V9NUi1t0g8T3ghS/hQ\"",
    "mtime": "2026-10-23T01:52:27.322Z",
    "size": 223,
    "path": "../public/_nuxt/CyIsLhoS.js"
  },
  "/_nuxt/D0L5KjQl.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"7e0-AhNJxEvG4K5a9s8hA33viDLEqWU\"",
    "mtime": "2026-10-23T01:52:27.322Z",
    "size": 2016,
    "path": "../public/_nuxt/D0L5KjQl.js"
  },
  "/_nuxt/D3H-b8nl.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"25ee-r9bsLeAa9oGMREEJ+zgijbbk1Pc\"",
    "mtime": "2026-10-23T01:52:27.322Z",
    "size": 9710,
    "path": "../public/_nuxt/D3H-b8nl.js"
  },
  "/_nuxt/D8i-yQff.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"e07-Me9AqUXq/H0VybUrgLRx7vsZEw8\"",
    "mtime": "2026-10-23T01:52:27.322Z",
    "size": 3591,
    "path": "../public/_nuxt/D8i-yQff.js"
  },
  "/_nuxt/D9xQZsES.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"dd-MrOD8WzgA/QMUITY5/rhKBzztio\"",
    "mtime": "2026-10-23T01:52:27.323Z",
    "size": 221,
    "path": "../public/_nuxt/D9xQZsES.js"
  },
  "/_nuxt/D3XF7Wt5.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"203-IUV28ikyj8fNwjCNABKdbc8pzGw\"",
    "mtime": "2026-10-23T01:52:27.322Z",
    "size": 515,
    "path": "../public/_nuxt/D3XF7Wt5.js"
  },
  "/_nuxt/Co3YudX4.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"8b1d3-f4+AvXFhQfuaue8flq3vyABlqA4\"",
    "mtime": "2026-10-23T01:52:27.321Z",
    "size": 569811,
    "path": "../public/_nuxt/Co3YudX4.js"
  },
  "/_nuxt/D9vHImT2.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"134-NPDqi0feH0zvp0d6slLlZyg36Qo\"",
    "mtime": "2026-10-23T01:52:27.322Z",
    "size": 308,
    "path": "../public/_nuxt/D9vHImT2.js"
  },
  "/_nuxt/DAACctBb.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"93da-EMuEIcBFS79IRKbhH3OfFyl1f0o\"",
    "mtime": "2026-10-23T01:52:27.323Z",
    "size": 37850,
    "path": "../public/_nuxt/DAACctBb.js"
  },
  "/_nuxt/DbWY5LR7.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"17da-3MbG+jtgIhYcfXyFmoLPjiZJOE0\"",
    "mtime": "2026-10-23T01:52:27.325Z",
    "size": 6106,
    "path": "../public/_nuxt/DbWY5LR7.js"
  },
  "/_nuxt/DbQ7FFYC.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"be90-OR9HeCvY6ElqAWSaIkAyxdY/54U\"",
    "mtime": "2026-10-23T01:52:27.325Z",
    "size": 48784,
    "path": "../public/_nuxt/DbQ7FFYC.js"
  },
  "/_nuxt/De-qRcTO.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"9f1-JZNHkWSlWF/cBl/PMF0yLEYix+A\"",
    "mtime": "2026-10-23T01:52:27.325Z",
    "size": 2545,
    "path": "../public/_nuxt/De-qRcTO.js"
  },
  "/_nuxt/DCx9UEgI.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"443-Gdm3kXfyOnQ6aQ5JCOUiCnGT9o4\"",
    "mtime": "2026-10-23T01:52:27.323Z",
    "size": 1091,
    "path": "../public/_nuxt/DCx9UEgI.js"
  },
  "/_nuxt/default.B6XwRajx.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"e6-qXg+zN3lbvCgh3BtjrHAQ2ajdCw\"",
    "mtime": "2026-10-23T01:52:27.337Z",
    "size": 230,
    "path": "../public/_nuxt/default.B6XwRajx.css"
  },
  "/_nuxt/DDl2lgGO.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"81e-fChQjzWWykLn4KBtrZFniPs7+Bw\"",
    "mtime": "2026-10-23T01:52:27.323Z",
    "size": 2078,
    "path": "../public/_nuxt/DDl2lgGO.js"
  },
  "/_nuxt/DFgQFscO.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"4d-xaGdT6OIKzPVi98d+V36RPW9U3Y\"",
    "mtime": "2026-10-23T01:52:27.323Z",
    "size": 77,
    "path": "../public/_nuxt/DFgQFscO.js"
  },
  "/_nuxt/DEDU0euh.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"195d-3fAUcAyExD1FBG8HTkxfnHSvSLY\"",
    "mtime": "2026-10-23T01:52:27.323Z",
    "size": 6493,
    "path": "../public/_nuxt/DEDU0euh.js"
  },
  "/_nuxt/DfyrabgN.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"13d-kpvPl4h9DK1Bxz/f/hgdmlazMTw\"",
    "mtime": "2026-10-23T01:52:27.325Z",
    "size": 317,
    "path": "../public/_nuxt/DfyrabgN.js"
  },
  "/_nuxt/DfWJs8KI.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"41de-eGDRoxxwId1NVIynzcPUFUQ9I+k\"",
    "mtime": "2026-10-23T01:52:27.325Z",
    "size": 16862,
    "path": "../public/_nuxt/DfWJs8KI.js"
  },
  "/_nuxt/DG7WySiJ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"55a-pV8SiBDVnfWJgfFD+gpuw4yU49A\"",
    "mtime": "2026-10-23T01:52:27.324Z",
    "size": 1370,
    "path": "../public/_nuxt/DG7WySiJ.js"
  },
  "/_nuxt/DMP1gpRx.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"dd-MrOD8WzgA/QMUITY5/rhKBzztio\"",
    "mtime": "2026-10-23T01:52:27.324Z",
    "size": 221,
    "path": "../public/_nuxt/DMP1gpRx.js"
  },
  "/_nuxt/DjflIO6C.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"eb-zjtWx6b3+VWA/NLnTrTGrbnzvGw\"",
    "mtime": "2026-10-23T01:52:27.326Z",
    "size": 235,
    "path": "../public/_nuxt/DjflIO6C.js"
  },
  "/_nuxt/DGt3Fm4O.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"19f5-g5gNbaWF3ClS74uD+BEIgDtHe+g\"",
    "mtime": "2026-10-23T01:52:27.324Z",
    "size": 6645,
    "path": "../public/_nuxt/DGt3Fm4O.js"
  },
  "/_nuxt/DN2-sf1X.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"11a0-UWfaQxxTowDefFNOyUoKj+PkC70\"",
    "mtime": "2026-10-23T01:52:27.324Z",
    "size": 4512,
    "path": "../public/_nuxt/DN2-sf1X.js"
  },
  "/_nuxt/DnoCGwgZ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1fd6-UyRzBhul77Lh4hqzi0yaMTYA+5o\"",
    "mtime": "2026-10-23T01:52:27.326Z",
    "size": 8150,
    "path": "../public/_nuxt/DnoCGwgZ.js"
  },
  "/_nuxt/DQZY6g8J.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"c46-xjoyoaqmR5SMVaZ0OtmwU24sKKQ\"",
    "mtime": "2026-10-23T01:52:27.325Z",
    "size": 3142,
    "path": "../public/_nuxt/DQZY6g8J.js"
  },
  "/_nuxt/DJSMGQGj.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"dd01-H93/Yct4hLgowRPJmIvNRP0kX70\"",
    "mtime": "2026-10-23T01:52:27.324Z",
    "size": 56577,
    "path": "../public/_nuxt/DJSMGQGj.js"
  },
  "/_nuxt/Dw4Mn5Il.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"cbc-8gGQPIR6Bmx5g+AgvzcVPbiM7p0\"",
    "mtime": "2026-10-23T01:52:27.326Z",
    "size": 3260,
    "path": "../public/_nuxt/Dw4Mn5Il.js"
  },
  "/_nuxt/e8FceFyD.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"df0-RjDPIgu0bRuN97kGQmIuTOwEJZE\"",
    "mtime": "2026-10-23T01:52:27.330Z",
    "size": 3568,
    "path": "../public/_nuxt/e8FceFyD.js"
  },
  "/_nuxt/E8inbnku.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"19f4-0rrGSDF1iy2QszOP+2WKDnN6xHo\"",
    "mtime": "2026-10-23T01:52:27.326Z",
    "size": 6644,
    "path": "../public/_nuxt/E8inbnku.js"
  },
  "/_nuxt/EmE-q-48.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1b2d-gI2V19cS/gdVe33SWWXaB458QnE\"",
    "mtime": "2026-10-23T01:52:27.327Z",
    "size": 6957,
    "path": "../public/_nuxt/EmE-q-48.js"
  },
  "/_nuxt/CLKk50C3.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"118d15-LVl0GoMw0ETmjX/5IbI8KFPkxjw\"",
    "mtime": "2026-10-23T01:52:27.304Z",
    "size": 1150229,
    "path": "../public/_nuxt/CLKk50C3.js"
  },
  "/_nuxt/entry.B1UojiOV.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"151de-M/o7xi9EH3vzb56PsZF2gGs4LaI\"",
    "mtime": "2026-10-23T01:52:27.337Z",
    "size": 86494,
    "path": "../public/_nuxt/entry.B1UojiOV.css"
  },
  "/_nuxt/eNIuGM2e.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1478-9Vm0Exw9BSXQGqDEDNwt6kWnj/8\"",
    "mtime": "2026-10-23T01:52:27.331Z",
    "size": 5240,
    "path": "../public/_nuxt/eNIuGM2e.js"
  },
  "/_nuxt/FancyBorderRadius.SAJ40CgB.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"462-OCbg/CfaykX+0EOFnxPACe70w9U\"",
    "mtime": "2026-10-23T01:52:27.334Z",
    "size": 1122,
    "path": "../public/_nuxt/FancyBorderRadius.SAJ40CgB.css"
  },
  "/_nuxt/FlvPlayer.DRBeBahy.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"38-txNLtSL367JohkkFdnTAN4lRpSQ\"",
    "mtime": "2026-10-23T01:52:27.334Z",
    "size": 56,
    "path": "../public/_nuxt/FlvPlayer.DRBeBahy.css"
  },
  "/_nuxt/etrzBp6s.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1959-oj1XV2QNRiJcku9vHmfZ3jaDiSI\"",
    "mtime": "2026-10-23T01:52:27.331Z",
    "size": 6489,
    "path": "../public/_nuxt/etrzBp6s.js"
  },
  "/_nuxt/HgmkcdKm.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"dd-MrOD8WzgA/QMUITY5/rhKBzztio\"",
    "mtime": "2026-10-23T01:52:27.327Z",
    "size": 221,
    "path": "../public/_nuxt/HgmkcdKm.js"
  },
  "/_nuxt/iconfont.B48GY0Tp.ttf": {
    "type": "font/ttf",
    "etag": "\"35f0-TUkBu7ER5viV5zUpdGOHHXmNFAU\"",
    "mtime": "2026-10-23T01:52:27.337Z",
    "size": 13808,
    "path": "../public/_nuxt/iconfont.B48GY0Tp.ttf"
  },
  "/_nuxt/iconfont.CDcKc1Z_.woff2": {
    "type": "font/woff2",
    "etag": "\"1a94-nzVvnKRABpQQxxAZvThluV0MC34\"",
    "mtime": "2026-10-23T01:52:27.337Z",
    "size": 6804,
    "path": "../public/_nuxt/iconfont.CDcKc1Z_.woff2"
  },
  "/_nuxt/iconfont.DKnQEIZp.woff": {
    "type": "font/woff",
    "etag": "\"1fcc-AhOW2zUa2ty7pgUQ7OKMjEWU4N0\"",
    "mtime": "2026-10-23T01:52:27.338Z",
    "size": 8140,
    "path": "../public/_nuxt/iconfont.DKnQEIZp.woff"
  },
  "/_nuxt/G5bYQkV_.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"e52-7gPTvSDhW5Qnw7T3yDmPeMYkngk\"",
    "mtime": "2026-10-23T01:52:27.327Z",
    "size": 3666,
    "path": "../public/_nuxt/G5bYQkV_.js"
  },
  "/_nuxt/F9LEIp-h.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"8e68-KFk937Cp9VrQztFRe7LDYiPOPyU\"",
    "mtime": "2026-10-23T01:52:27.327Z",
    "size": 36456,
    "path": "../public/_nuxt/F9LEIp-h.js"
  },
  "/_nuxt/JVgSvsgm.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1162-cysUIsR6n2XL8odIkDgtykWyXz0\"",
    "mtime": "2026-10-23T01:52:27.328Z",
    "size": 4450,
    "path": "../public/_nuxt/JVgSvsgm.js"
  },
  "/_nuxt/K3Oi7fSB.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"18f1-EKjA5L0bqFpMKi7Vs3pqQXxkKTQ\"",
    "mtime": "2026-10-23T01:52:27.328Z",
    "size": 6385,
    "path": "../public/_nuxt/K3Oi7fSB.js"
  },
  "/_nuxt/j_Fy5Hfy.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"39ed-b2T6yUIrMJDCSyxh+2J8aGR0CtE\"",
    "mtime": "2026-10-23T01:52:27.331Z",
    "size": 14829,
    "path": "../public/_nuxt/j_Fy5Hfy.js"
  },
  "/_nuxt/KiYfYMFE.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"135-W29boWP1HM+YcQsz7mep9v2Ht9U\"",
    "mtime": "2026-10-23T01:52:27.328Z",
    "size": 309,
    "path": "../public/_nuxt/KiYfYMFE.js"
  },
  "/_nuxt/KJwA3Igd.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1cd-nh39hRSIT+HM8vuqGAEezQ3O0dI\"",
    "mtime": "2026-10-23T01:52:27.328Z",
    "size": 461,
    "path": "../public/_nuxt/KJwA3Igd.js"
  },
  "/_nuxt/M3U8V2Pro.B0AGtkuJ.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"239-rQNsND69S+EAGYl0Ndh6W7/Mzqo\"",
    "mtime": "2026-10-23T01:52:27.335Z",
    "size": 569,
    "path": "../public/_nuxt/M3U8V2Pro.B0AGtkuJ.css"
  },
  "/_nuxt/MakePhrase.BV0KNp5I.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"7ec-0TMldUxI5lDfS0iicvbReNvfkQY\"",
    "mtime": "2026-10-23T01:52:27.335Z",
    "size": 2028,
    "path": "../public/_nuxt/MakePhrase.BV0KNp5I.css"
  },
  "/_nuxt/kUDVxw4w.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"6dc-ku0GBHAFVktDo4dPH6k4lgvHTNE\"",
    "mtime": "2026-10-23T01:52:27.331Z",
    "size": 1756,
    "path": "../public/_nuxt/kUDVxw4w.js"
  },
  "/_nuxt/mNIrNyge.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"9e-U4j6/YWm0w3T/xeGtnLa0hg9+rI\"",
    "mtime": "2026-10-23T01:52:27.332Z",
    "size": 158,
    "path": "../public/_nuxt/mNIrNyge.js"
  },
  "/_nuxt/MQ7oaUYW.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"882-2dUfCcnRmkvBsD9joA4lfeoxP2E\"",
    "mtime": "2026-10-23T01:52:27.328Z",
    "size": 2178,
    "path": "../public/_nuxt/MQ7oaUYW.js"
  },
  "/_nuxt/NationalDayAvatar.i_Pewbr6.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"38e-ZH/zsvgARcEoHCyC2OjDAen/dI4\"",
    "mtime": "2026-10-23T01:52:27.335Z",
    "size": 910,
    "path": "../public/_nuxt/NationalDayAvatar.i_Pewbr6.css"
  },
  "/_nuxt/l6wVLwTe.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1c69c-fY7M6xI6TQrmrtLe6f7S6WucT4Y\"",
    "mtime": "2026-10-23T01:52:27.331Z",
    "size": 116380,
    "path": "../public/_nuxt/l6wVLwTe.js"
  },
  "/_nuxt/NPlayer.BqNDyWPq.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"3d-a4DEycbdhN4oQcCKhXd8M/qM8lQ\"",
    "mtime": "2026-10-23T01:52:27.335Z",
    "size": 61,
    "path": "../public/_nuxt/NPlayer.BqNDyWPq.css"
  },
  "/_nuxt/NDZWQihV.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"28ef-JV3Atux+/fmcQFeHpJrx2OETSsc\"",
    "mtime": "2026-10-23T01:52:27.328Z",
    "size": 10479,
    "path": "../public/_nuxt/NDZWQihV.js"
  },
  "/_nuxt/oFyJJtgr.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"7817-ETAd73lOhQAXm6c6+p0a8gi9XAY\"",
    "mtime": "2026-10-23T01:52:27.332Z",
    "size": 30743,
    "path": "../public/_nuxt/oFyJJtgr.js"
  },
  "/_nuxt/oV60_OR_.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"d4f-O/c1SGkeQXPbzxL5zx4cYUKUfjs\"",
    "mtime": "2026-10-23T01:52:27.332Z",
    "size": 3407,
    "path": "../public/_nuxt/oV60_OR_.js"
  },
  "/_nuxt/read.AOjBc4zT.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"7a-8alzEP7vFW7T2oIZeBH8WbqpV00\"",
    "mtime": "2026-10-23T01:52:27.338Z",
    "size": 122,
    "path": "../public/_nuxt/read.AOjBc4zT.css"
  },
  "/_nuxt/pXErchap.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"5003e-cOz8rlybe4ccqewgYR/LdfLp0X0\"",
    "mtime": "2026-10-23T01:52:27.332Z",
    "size": 327742,
    "path": "../public/_nuxt/pXErchap.js"
  },
  "/_nuxt/mYd2frnQ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"29d49-cXxlWYyWKxXtdpL63JnjzG62h74\"",
    "mtime": "2026-10-23T01:52:27.332Z",
    "size": 171337,
    "path": "../public/_nuxt/mYd2frnQ.js"
  },
  "/_nuxt/TextSecret.BqekhHBi.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"6ee-C/lrp+Giw/Skw+RS8om1lHK5RrA\"",
    "mtime": "2026-10-23T01:52:27.335Z",
    "size": 1774,
    "path": "../public/_nuxt/TextSecret.BqekhHBi.css"
  },
  "/_nuxt/tool.BaCPouGG.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"7a-dVhCcroLhV+O+7eBjRVQDpi0GRg\"",
    "mtime": "2026-10-23T01:52:27.339Z",
    "size": 122,
    "path": "../public/_nuxt/tool.BaCPouGG.css"
  },
  "/_nuxt/TdvAr81c.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"e64-vpArmTYvhYrlBNaQhpAij/xCDx4\"",
    "mtime": "2026-10-23T01:52:27.328Z",
    "size": 3684,
    "path": "../public/_nuxt/TdvAr81c.js"
  },
  "/_nuxt/twJws2GP.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1f4-9k5h5013IAzYCGVZ0k0SQU92nH8\"",
    "mtime": "2026-10-23T01:52:27.333Z",
    "size": 500,
    "path": "../public/_nuxt/twJws2GP.js"
  },
  "/_nuxt/vXj8VS9F.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"b61-T7z3yKnxz+yTmLRZabPP93Pl9kI\"",
    "mtime": "2026-10-23T01:52:27.333Z",
    "size": 2913,
    "path": "../public/_nuxt/vXj8VS9F.js"
  },
  "/_nuxt/WeiBoGenerates.Dp0UVOdj.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"fc7-ksaVlThqaYWLNlJ1jRtktIGVK/8\"",
    "mtime": "2026-10-23T01:52:27.336Z",
    "size": 4039,
    "path": "../public/_nuxt/WeiBoGenerates.Dp0UVOdj.css"
  },
  "/_nuxt/Whois.C9hSFzQZ.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"83-058iFtdwiqFwhG+JfDbdwi1Fy5A\"",
    "mtime": "2026-10-23T01:52:27.336Z",
    "size": 131,
    "path": "../public/_nuxt/Whois.C9hSFzQZ.css"
  },
  "/_nuxt/WordToPDF.CGD0Mknp.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"309-nkmhg93RgElZWdwnwlGmNklKwe0\"",
    "mtime": "2026-10-23T01:52:27.336Z",
    "size": 777,
    "path": "../public/_nuxt/WordToPDF.CGD0Mknp.css"
  },
  "/_nuxt/US76zSLu.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"bfe-g+6yWef0eTtxrHiKQAdG2I1epLg\"",
    "mtime": "2026-10-23T01:52:27.329Z",
    "size": 3070,
    "path": "../public/_nuxt/US76zSLu.js"
  },
  "/_nuxt/png_to_svg_wasm_bg.tcoW2oQ5.wasm": {
    "type": "application/wasm",
    "etag": "\"ef673-bsk8QBljqnJ+cYNdfx6pxXYmDCQ\"",
    "mtime": "2026-10-23T01:52:27.338Z",
    "size": 980595,
    "path": "../public/_nuxt/png_to_svg_wasm_bg.tcoW2oQ5.wasm"
  },
  "/_nuxt/writer.C0rQSfAI.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"40-ARzvYgEE0ihBA9OIvj5ZHJvXjNw\"",
    "mtime": "2026-10-23T01:52:27.339Z",
    "size": 64,
    "path": "../public/_nuxt/writer.C0rQSfAI.css"
  },
  "/_nuxt/wU1Vxsog.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3c4d-+L1rh5TlF/S5rolEfDK0+wnylXA\"",
    "mtime": "2026-10-23T01:52:27.333Z",
    "size": 15437,
    "path": "../public/_nuxt/wU1Vxsog.js"
  },
  "/_nuxt/Xko8C-B1.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1246-8Y1Wt9V2AUCUDkd0+F51ZIyU2NM\"",
    "mtime": "2026-10-23T01:52:27.329Z",
    "size": 4678,
    "path": "../public/_nuxt/Xko8C-B1.js"
  },
  "/_nuxt/s9GPT72K.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"d5969-Eg9qpkxjV9+AeJolhDvGPtn1Xb0\"",
    "mtime": "2026-10-23T01:52:27.333Z",
    "size": 874857,
    "path": "../public/_nuxt/s9GPT72K.js"
  },
  "/_nuxt/wz7IIq98.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1f860-QOeLwmWDy7ZO0YMhvpAMX5AZchw\"",
    "mtime": "2026-10-23T01:52:27.333Z",
    "size": 129120,
    "path": "../public/_nuxt/wz7IIq98.js"
  },
  "/_nuxt/_H-e1qoF.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"dd-MrOD8WzgA/QMUITY5/rhKBzztio\"",
    "mtime": "2026-10-23T01:52:27.329Z",
    "size": 221,
    "path": "../public/_nuxt/_H-e1qoF.js"
  },
  "/_nuxt/_id_.CPhDtqRZ.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"7a-tcseCxty0eWXk+wzVm1lPJUEEB0\"",
    "mtime": "2026-10-23T01:52:27.336Z",
    "size": 122,
    "path": "../public/_nuxt/_id_.CPhDtqRZ.css"
  },
  "/_nuxt/_id_.BtZm8tN7.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"693-hDe21ajINs103xdK/qT6tyEBgUY\"",
    "mtime": "2026-10-23T01:52:27.336Z",
    "size": 1683,
    "path": "../public/_nuxt/_id_.BtZm8tN7.css"
  },
  "/_nuxt/_id_.Cz-Gwb6Q.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"7a-3YIs9+IMCoI8YD6tYPWnqMJl/GU\"",
    "mtime": "2026-10-23T01:52:27.336Z",
    "size": 122,
    "path": "../public/_nuxt/_id_.Cz-Gwb6Q.css"
  },
  "/_nuxt/zDTzY3Qt.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"11c-Reck30NinHJRz6iC7hQmQwZV57Y\"",
    "mtime": "2026-10-23T01:52:27.334Z",
    "size": 284,
    "path": "../public/_nuxt/zDTzY3Qt.js"
  },
  "/_nuxt/_pDMe-HI.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"601-y8GThhoFCEORKo4JFGUoDA0krPE\"",
    "mtime": "2026-10-23T01:52:27.329Z",
    "size": 1537,
    "path": "../public/_nuxt/_pDMe-HI.js"
  },
  "/_nuxt/XroPQsvw.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"4cc2-NAGXlbAR/9czU+otL8WTcraFftE\"",
    "mtime": "2026-10-23T01:52:27.329Z",
    "size": 19650,
    "path": "../public/_nuxt/XroPQsvw.js"
  },
  "/fonts/fonts/KaTeX_AMS-Regular.ttf": {
    "type": "font/ttf",
    "etag": "\"f890-Hf0O5uMPihwjmZ2dll24cAtany4\"",
    "mtime": "2026-10-20T00:18:15.533Z",
    "size": 63632,
    "path": "../public/fonts/fonts/KaTeX_AMS-Regular.ttf"
  },
  "/fonts/fonts/KaTeX_AMS-Regular.woff": {
    "type": "font/woff",
    "etag": "\"82ec-ma2i3jIA55UUPWOSMsNESwgBgjU\"",
    "mtime": "2026-10-20T00:18:15.534Z",
    "size": 33516,
    "path": "../public/fonts/fonts/KaTeX_AMS-Regular.woff"
  },
  "/fonts/fonts/KaTeX_AMS-Regular.woff2": {
    "type": "font/woff2",
    "etag": "\"6dac-NElHQ3Nv2nVxl9FvzGpuGnkxfIY\"",
    "mtime": "2026-10-20T00:18:15.534Z",
    "size": 28076,
    "path": "../public/fonts/fonts/KaTeX_AMS-Regular.woff2"
  },
  "/fonts/fonts/KaTeX_Caligraphic-Bold.ttf": {
    "type": "font/ttf",
    "etag": "\"3050-j6tziha6j7fnACoHXwNqRVpFxug\"",
    "mtime": "2026-10-20T00:18:15.534Z",
    "size": 12368,
    "path": "../public/fonts/fonts/KaTeX_Caligraphic-Bold.ttf"
  },
  "/fonts/fonts/KaTeX_Caligraphic-Bold.woff": {
    "type": "font/woff",
    "etag": "\"1e24-3SOsD7CsRpsGJEhep41wD2NhQgM\"",
    "mtime": "2026-10-20T00:18:15.535Z",
    "size": 7716,
    "path": "../public/fonts/fonts/KaTeX_Caligraphic-Bold.woff"
  },
  "/fonts/fonts/KaTeX_Caligraphic-Bold.woff2": {
    "type": "font/woff2",
    "etag": "\"1b00-W/pJysRs0derE1E4jTfBGvWbphU\"",
    "mtime": "2026-10-20T00:18:15.535Z",
    "size": 6912,
    "path": "../public/fonts/fonts/KaTeX_Caligraphic-Bold.woff2"
  },
  "/fonts/fonts/KaTeX_Caligraphic-Regular.ttf": {
    "type": "font/ttf",
    "etag": "\"3038-JvJqE+an0KabSPYqzTGoGWvOf24\"",
    "mtime": "2026-10-20T00:18:15.535Z",
    "size": 12344,
    "path": "../public/fonts/fonts/KaTeX_Caligraphic-Regular.ttf"
  },
  "/fonts/fonts/KaTeX_Caligraphic-Regular.woff2": {
    "type": "font/woff2",
    "etag": "\"1afc-n4B34LOKKQzZt7E2sKwpyDdegaY\"",
    "mtime": "2026-10-20T00:18:15.535Z",
    "size": 6908,
    "path": "../public/fonts/fonts/KaTeX_Caligraphic-Regular.woff2"
  },
  "/fonts/fonts/KaTeX_Caligraphic-Regular.woff": {
    "type": "font/woff",
    "etag": "\"1de8-Gm85vXDJt0cTB431991hCPm604s\"",
    "mtime": "2026-10-20T00:18:15.535Z",
    "size": 7656,
    "path": "../public/fonts/fonts/KaTeX_Caligraphic-Regular.woff"
  },
  "/fonts/fonts/KaTeX_Fraktur-Bold.ttf": {
    "type": "font/ttf",
    "etag": "\"4c80-TgjdADgxJOfNlpcMyw++NcnvqqM\"",
    "mtime": "2026-10-20T00:18:15.536Z",
    "size": 19584,
    "path": "../public/fonts/fonts/KaTeX_Fraktur-Bold.ttf"
  },
  "/fonts/fonts/KaTeX_Fraktur-Bold.woff": {
    "type": "font/woff",
    "etag": "\"33f0-W7r9UB8mIhlCavfyDBEDu0tzJZI\"",
    "mtime": "2026-10-20T00:18:15.536Z",
    "size": 13296,
    "path": "../public/fonts/fonts/KaTeX_Fraktur-Bold.woff"
  },
  "/fonts/fonts/KaTeX_Fraktur-Bold.woff2": {
    "type": "font/woff2",
    "etag": "\"2c54-+Y+JJy7KEa5BdnLFmg+qaoiAWok\"",
    "mtime": "2026-10-20T00:18:15.536Z",
    "size": 11348,
    "path": "../public/fonts/fonts/KaTeX_Fraktur-Bold.woff2"
  },
  "/fonts/fonts/KaTeX_Fraktur-Regular.ttf": {
    "type": "font/ttf",
    "etag": "\"4c74-F9tAiC3V8UBiXyjdlMQwReGJPpg\"",
    "mtime": "2026-10-20T00:18:15.537Z",
    "size": 19572,
    "path": "../public/fonts/fonts/KaTeX_Fraktur-Regular.ttf"
  },
  "/fonts/fonts/KaTeX_Fraktur-Regular.woff": {
    "type": "font/woff",
    "etag": "\"3398-b3VjdjYPCBW0SGL1f3let8HNTbI\"",
    "mtime": "2026-10-20T00:18:15.537Z",
    "size": 13208,
    "path": "../public/fonts/fonts/KaTeX_Fraktur-Regular.woff"
  },
  "/fonts/fonts/KaTeX_Fraktur-Regular.woff2": {
    "type": "font/woff2",
    "etag": "\"2c34-pXZMbieE0CggwLkECJ8/rHmL5Po\"",
    "mtime": "2026-10-20T00:18:15.537Z",
    "size": 11316,
    "path": "../public/fonts/fonts/KaTeX_Fraktur-Regular.woff2"
  },
  "/fonts/fonts/KaTeX_Main-Bold.ttf": {
    "type": "font/ttf",
    "etag": "\"c888-QTqz3D/DpXUidbriyuZ+tY8rMvA\"",
    "mtime": "2026-10-20T00:18:15.538Z",
    "size": 51336,
    "path": "../public/fonts/fonts/KaTeX_Main-Bold.ttf"
  },
  "/fonts/fonts/KaTeX_Main-Bold.woff": {
    "type": "font/woff",
    "etag": "\"74d8-9po2JQ6ubooCFzqZCapihCi6IGA\"",
    "mtime": "2026-10-20T00:18:15.538Z",
    "size": 29912,
    "path": "../public/fonts/fonts/KaTeX_Main-Bold.woff"
  },
  "/fonts/fonts/KaTeX_Main-Bold.woff2": {
    "type": "font/woff2",
    "etag": "\"62ec-MQUKGxsSP7LFnK0fdLff+Q3rj84\"",
    "mtime": "2026-10-20T00:18:15.538Z",
    "size": 25324,
    "path": "../public/fonts/fonts/KaTeX_Main-Bold.woff2"
  },
  "/fonts/fonts/KaTeX_Main-BoldItalic.woff": {
    "type": "font/woff",
    "etag": "\"4bd4-A4u9yIh6lzCtlBR/xXxv9N+0hBE\"",
    "mtime": "2026-10-20T00:18:15.539Z",
    "size": 19412,
    "path": "../public/fonts/fonts/KaTeX_Main-BoldItalic.woff"
  },
  "/fonts/fonts/KaTeX_Main-BoldItalic.ttf": {
    "type": "font/ttf",
    "etag": "\"80c8-umRk5EL9UK73Z4kkug8tlYHruwc\"",
    "mtime": "2026-10-20T00:18:15.539Z",
    "size": 32968,
    "path": "../public/fonts/fonts/KaTeX_Main-BoldItalic.ttf"
  },
  "/fonts/fonts/KaTeX_Main-BoldItalic.woff2": {
    "type": "font/woff2",
    "etag": "\"418c-pKSQW4sSb5/9VT0hpyoMJOlIA0U\"",
    "mtime": "2026-10-20T00:18:15.539Z",
    "size": 16780,
    "path": "../public/fonts/fonts/KaTeX_Main-BoldItalic.woff2"
  },
  "/fonts/fonts/KaTeX_Main-Italic.ttf": {
    "type": "font/ttf",
    "etag": "\"832c-HVZoorlK59vu/dfNaNmP6dWCXgc\"",
    "mtime": "2026-10-20T00:18:15.539Z",
    "size": 33580,
    "path": "../public/fonts/fonts/KaTeX_Main-Italic.ttf"
  },
  "/fonts/fonts/KaTeX_Main-Italic.woff": {
    "type": "font/woff",
    "etag": "\"4cdc-fIWJITvHAD4sIzS1HKQVKFiYer0\"",
    "mtime": "2026-10-20T00:18:15.540Z",
    "size": 19676,
    "path": "../public/fonts/fonts/KaTeX_Main-Italic.woff"
  },
  "/fonts/fonts/KaTeX_Main-Italic.woff2": {
    "type": "font/woff2",
    "etag": "\"425c-ybK1/9LyeqXGtvm6QaeytOZhAtM\"",
    "mtime": "2026-10-20T00:18:15.540Z",
    "size": 16988,
    "path": "../public/fonts/fonts/KaTeX_Main-Italic.woff2"
  },
  "/fonts/fonts/KaTeX_Main-Regular.woff": {
    "type": "font/woff",
    "etag": "\"7834-/crlS6HUY17oWlRizByX5SHP1RU\"",
    "mtime": "2026-10-20T00:18:15.541Z",
    "size": 30772,
    "path": "../public/fonts/fonts/KaTeX_Main-Regular.woff"
  },
  "/fonts/fonts/KaTeX_Main-Regular.ttf": {
    "type": "font/ttf",
    "etag": "\"d14c-h0TbbvjDCePchfG76YBSCti3v9Q\"",
    "mtime": "2026-10-20T00:18:15.540Z",
    "size": 53580,
    "path": "../public/fonts/fonts/KaTeX_Main-Regular.ttf"
  },
  "/fonts/fonts/KaTeX_Main-Regular.woff2": {
    "type": "font/woff2",
    "etag": "\"66a0-yIQIbCXOyFWBYLICb5Bu99o1cKw\"",
    "mtime": "2026-10-20T00:18:15.541Z",
    "size": 26272,
    "path": "../public/fonts/fonts/KaTeX_Main-Regular.woff2"
  },
  "/fonts/fonts/KaTeX_Math-BoldItalic.ttf": {
    "type": "font/ttf",
    "etag": "\"79dc-6AzEwjLSB192KlLUa+tP+9N6Xxo\"",
    "mtime": "2026-10-20T00:18:15.542Z",
    "size": 31196,
    "path": "../public/fonts/fonts/KaTeX_Math-BoldItalic.ttf"
  },
  "/fonts/fonts/KaTeX_Math-BoldItalic.woff": {
    "type": "font/woff",
    "etag": "\"48ec-1U5kgNbUBGxqVhmqODuqWXH7igw\"",
    "mtime": "2026-10-20T00:18:15.542Z",
    "size": 18668,
    "path": "../public/fonts/fonts/KaTeX_Math-BoldItalic.woff"
  },
  "/fonts/fonts/KaTeX_Math-BoldItalic.woff2": {
    "type": "font/woff2",
    "etag": "\"4010-j8udLeZaxxoMT92YYXPbcwWS7Yo\"",
    "mtime": "2026-10-20T00:18:15.542Z",
    "size": 16400,
    "path": "../public/fonts/fonts/KaTeX_Math-BoldItalic.woff2"
  },
  "/fonts/fonts/KaTeX_Math-Italic.ttf": {
    "type": "font/ttf",
    "etag": "\"7a4c-npoQ2Ppa2Iyez6SQKt3U2SWAsrw\"",
    "mtime": "2026-10-20T00:18:15.543Z",
    "size": 31308,
    "path": "../public/fonts/fonts/KaTeX_Math-Italic.ttf"
  },
  "/fonts/fonts/KaTeX_Math-Italic.woff": {
    "type": "font/woff",
    "etag": "\"493c-HBtIc54ctL4T3djAvCed3oUb26A\"",
    "mtime": "2026-10-20T00:18:15.543Z",
    "size": 18748,
    "path": "../public/fonts/fonts/KaTeX_Math-Italic.woff"
  },
  "/fonts/fonts/KaTeX_Math-Italic.woff2": {
    "type": "font/woff2",
    "etag": "\"4038-20iD0M/5XstcA0EOMoOnN8Ue1gQ\"",
    "mtime": "2026-10-20T00:18:15.543Z",
    "size": 16440,
    "path": "../public/fonts/fonts/KaTeX_Math-Italic.woff2"
  },
  "/fonts/fonts/KaTeX_SansSerif-Bold.ttf": {
    "type": "font/ttf",
    "etag": "\"5fb8-ILRfU0a2htUsRFdFOT0XB7uI7B0\"",
    "mtime": "2026-10-20T00:18:15.543Z",
    "size": 24504,
    "path": "../public/fonts/fonts/KaTeX_SansSerif-Bold.ttf"
  },
  "/fonts/fonts/KaTeX_SansSerif-Bold.woff": {
    "type": "font/woff",
    "etag": "\"3848-or7dyKPU0IAo1wd3btvU0k8uwPw\"",
    "mtime": "2026-10-20T00:18:15.544Z",
    "size": 14408,
    "path": "../public/fonts/fonts/KaTeX_SansSerif-Bold.woff"
  },
  "/fonts/fonts/KaTeX_SansSerif-Bold.woff2": {
    "type": "font/woff2",
    "etag": "\"2fb8-iG5heXpSXUqvzgqvV0FP366huHM\"",
    "mtime": "2026-10-20T00:18:15.544Z",
    "size": 12216,
    "path": "../public/fonts/fonts/KaTeX_SansSerif-Bold.woff2"
  },
  "/fonts/fonts/KaTeX_SansSerif-Italic.ttf": {
    "type": "font/ttf",
    "etag": "\"575c-mR+9wDFouxSkRHz6PlFfCabs/tw\"",
    "mtime": "2026-10-20T00:18:15.544Z",
    "size": 22364,
    "path": "../public/fonts/fonts/KaTeX_SansSerif-Italic.ttf"
  },
  "/fonts/fonts/KaTeX_SansSerif-Italic.woff": {
    "type": "font/woff",
    "etag": "\"3720-dWSjZrdv2DcEHCS+70xVgKWt1A4\"",
    "mtime": "2026-10-20T00:18:15.544Z",
    "size": 14112,
    "path": "../public/fonts/fonts/KaTeX_SansSerif-Italic.woff"
  },
  "/fonts/fonts/KaTeX_SansSerif-Regular.ttf": {
    "type": "font/ttf",
    "etag": "\"4bec-So4XoMtYqCKN1EF/vRuJnkHasEU\"",
    "mtime": "2026-10-20T00:18:15.545Z",
    "size": 19436,
    "path": "../public/fonts/fonts/KaTeX_SansSerif-Regular.ttf"
  },
  "/fonts/fonts/KaTeX_SansSerif-Italic.woff2": {
    "type": "font/woff2",
    "etag": "\"2efc-PV+jyzCfjYO03L3SdyXycPYPPus\"",
    "mtime": "2026-10-20T00:18:15.545Z",
    "size": 12028,
    "path": "../public/fonts/fonts/KaTeX_SansSerif-Italic.woff2"
  },
  "/fonts/fonts/KaTeX_SansSerif-Regular.woff": {
    "type": "font/woff",
    "etag": "\"301c-gEYQ9MsuLq2WlLjaLshOzo0Jw40\"",
    "mtime": "2026-10-20T00:18:15.545Z",
    "size": 12316,
    "path": "../public/fonts/fonts/KaTeX_SansSerif-Regular.woff"
  },
  "/fonts/fonts/KaTeX_SansSerif-Regular.woff2": {
    "type": "font/woff2",
    "etag": "\"2868-5F1fT0p/L/PcqfzMLxSOeB4j8pI\"",
    "mtime": "2026-10-20T00:18:15.545Z",
    "size": 10344,
    "path": "../public/fonts/fonts/KaTeX_SansSerif-Regular.woff2"
  },
  "/fonts/fonts/KaTeX_Script-Regular.ttf": {
    "type": "font/ttf",
    "etag": "\"4108-xvZ12oGtKcvySyz3cPeVtNosZI4\"",
    "mtime": "2026-10-20T00:18:15.546Z",
    "size": 16648,
    "path": "../public/fonts/fonts/KaTeX_Script-Regular.ttf"
  },
  "/fonts/fonts/KaTeX_Script-Regular.woff": {
    "type": "font/woff",
    "etag": "\"295c-agXNyk8fcIXmB9w4vt71V1P4b9g\"",
    "mtime": "2026-10-20T00:18:15.546Z",
    "size": 10588,
    "path": "../public/fonts/fonts/KaTeX_Script-Regular.woff"
  },
  "/fonts/fonts/KaTeX_Script-Regular.woff2": {
    "type": "font/woff2",
    "etag": "\"25ac-Y7gJWfH8Voma4hugy7zTmmywg5A\"",
    "mtime": "2026-10-20T00:18:15.546Z",
    "size": 9644,
    "path": "../public/fonts/fonts/KaTeX_Script-Regular.woff2"
  },
  "/fonts/fonts/KaTeX_Size1-Regular.ttf": {
    "type": "font/ttf",
    "etag": "\"2fc4-MoC6y8sSRZcf4BAXtHTHbDN8EMk\"",
    "mtime": "2026-10-20T00:18:15.546Z",
    "size": 12228,
    "path": "../public/fonts/fonts/KaTeX_Size1-Regular.ttf"
  },
  "/fonts/fonts/KaTeX_Size1-Regular.woff": {
    "type": "font/woff",
    "etag": "\"1960-rv5mdKVlM2J8c5zXiWOY8USH4Bw\"",
    "mtime": "2026-10-20T00:18:15.546Z",
    "size": 6496,
    "path": "../public/fonts/fonts/KaTeX_Size1-Regular.woff"
  },
  "/fonts/fonts/KaTeX_Size1-Regular.woff2": {
    "type": "font/woff2",
    "etag": "\"155c-V/pZmXShvAs31fDlzIYCMC8CtXM\"",
    "mtime": "2026-10-20T00:18:15.547Z",
    "size": 5468,
    "path": "../public/fonts/fonts/KaTeX_Size1-Regular.woff2"
  },
  "/fonts/fonts/KaTeX_Size2-Regular.ttf": {
    "type": "font/ttf",
    "etag": "\"2cf4-+vc/8+eVGE5UMWZv+v64qg4og00\"",
    "mtime": "2026-10-20T00:18:15.547Z",
    "size": 11508,
    "path": "../public/fonts/fonts/KaTeX_Size2-Regular.ttf"
  },
  "/fonts/fonts/KaTeX_Size2-Regular.woff": {
    "type": "font/woff",
    "etag": "\"182c-RmmP8YGb0ngm/V0txLpOH2PKzfQ\"",
    "mtime": "2026-10-20T00:18:15.547Z",
    "size": 6188,
    "path": "../public/fonts/fonts/KaTeX_Size2-Regular.woff"
  },
  "/fonts/fonts/KaTeX_Size2-Regular.woff2": {
    "type": "font/woff2",
    "etag": "\"1458-7hhxNjSjvoyZcnaAhVKrGVpZj0M\"",
    "mtime": "2026-10-20T00:18:15.547Z",
    "size": 5208,
    "path": "../public/fonts/fonts/KaTeX_Size2-Regular.woff2"
  },
  "/fonts/fonts/KaTeX_Size3-Regular.ttf": {
    "type": "font/ttf",
    "etag": "\"1da4-MCphsuzfgtOeZ4D0K9B+5M5nuNU\"",
    "mtime": "2026-10-20T00:18:15.548Z",
    "size": 7588,
    "path": "../public/fonts/fonts/KaTeX_Size3-Regular.ttf"
  },
  "/fonts/fonts/KaTeX_Size3-Regular.woff": {
    "type": "font/woff",
    "etag": "\"1144-HaGQWm0dm8q5KwWd9ytSjepwi8s\"",
    "mtime": "2026-10-20T00:18:15.548Z",
    "size": 4420,
    "path": "../public/fonts/fonts/KaTeX_Size3-Regular.woff"
  },
  "/fonts/fonts/KaTeX_Size3-Regular.woff2": {
    "type": "font/woff2",
    "etag": "\"e28-GafKrftmvSdXgQrkflx6DgBRAaE\"",
    "mtime": "2026-10-20T00:18:15.548Z",
    "size": 3624,
    "path": "../public/fonts/fonts/KaTeX_Size3-Regular.woff2"
  },
  "/fonts/fonts/KaTeX_Size4-Regular.ttf": {
    "type": "font/ttf",
    "etag": "\"287c-PY2d1YoDt6RtSX9XYeYNi4RKUZk\"",
    "mtime": "2026-10-20T00:18:15.548Z",
    "size": 10364,
    "path": "../public/fonts/fonts/KaTeX_Size4-Regular.ttf"
  },
  "/fonts/fonts/KaTeX_Size4-Regular.woff": {
    "type": "font/woff",
    "etag": "\"175c-j93bg1E+wiYjHr7gUHnsRfwBNXg\"",
    "mtime": "2026-10-20T00:18:15.548Z",
    "size": 5980,
    "path": "../public/fonts/fonts/KaTeX_Size4-Regular.woff"
  },
  "/fonts/fonts/KaTeX_Size4-Regular.woff2": {
    "type": "font/woff2",
    "etag": "\"1340-m+0X+5LyZQUB4imGLEDGQH4cVSg\"",
    "mtime": "2026-10-20T00:18:15.548Z",
    "size": 4928,
    "path": "../public/fonts/fonts/KaTeX_Size4-Regular.woff2"
  },
  "/fonts/fonts/KaTeX_Typewriter-Regular.ttf": {
    "type": "font/ttf",
    "etag": "\"6ba4-YpuZ+vGNl1KfIaGxAYCT5gvNBY8\"",
    "mtime": "2026-10-20T00:18:15.549Z",
    "size": 27556,
    "path": "../public/fonts/fonts/KaTeX_Typewriter-Regular.ttf"
  },
  "/fonts/fonts/KaTeX_Typewriter-Regular.woff": {
    "type": "font/woff",
    "etag": "\"3e9c-9ecp+k/0ZvwH4MerGXmtcMRfpdU\"",
    "mtime": "2026-10-20T00:18:15.549Z",
    "size": 16028,
    "path": "../public/fonts/fonts/KaTeX_Typewriter-Regular.woff"
  },
  "/fonts/fonts/KaTeX_Typewriter-Regular.woff2": {
    "type": "font/woff2",
    "etag": "\"3500-egiIP//GlYxxzAGnWguZzKPktHU\"",
    "mtime": "2026-10-20T00:18:15.549Z",
    "size": 13568,
    "path": "../public/fonts/fonts/KaTeX_Typewriter-Regular.woff2"
  },
  "/img/NationalDayAvatar/arrow-btn.png": {
    "type": "image/png",
    "etag": "\"3c0-4oEx6ZzRdEDJkMe1r3vfs/ytlO0\"",
    "mtime": "2026-10-20T00:18:15.551Z",
    "size": 960,
    "path": "../public/img/NationalDayAvatar/arrow-btn.png"
  },
  "/img/NationalDayAvatar/avatar-1.png": {
    "type": "image/png",
    "etag": "\"3a03-QTWL4xFlvDmlFYG7ex7OaOKQVMk\"",
    "mtime": "2026-10-20T00:18:15.551Z",
    "size": 14851,
    "path": "../public/img/NationalDayAvatar/avatar-1.png"
  },
  "/img/NationalDayAvatar/avatar-10.png": {
    "type": "image/png",
    "etag": "\"ae56-hA1B6WfZ59KMUQPPcJNJtghQTQY\"",
    "mtime": "2026-10-20T00:18:15.551Z",
    "size": 44630,
    "path": "../public/img/NationalDayAvatar/avatar-10.png"
  },
  "/img/NationalDayAvatar/avatar-11.png": {
    "type": "image/png",
    "etag": "\"36d4-bggVzjlMblo3BHLy09wC7Bo412M\"",
    "mtime": "2026-10-20T00:18:15.553Z",
    "size": 14036,
    "path": "../public/img/NationalDayAvatar/avatar-11.png"
  },
  "/img/NationalDayAvatar/avatar-12.png": {
    "type": "image/png",
    "etag": "\"3e36-t8rDmIOskwGrZ2HkcY1wnNR8r/k\"",
    "mtime": "2026-10-20T00:18:15.553Z",
    "size": 15926,
    "path": "../public/img/NationalDayAvatar/avatar-12.png"
  },
  "/img/NationalDayAvatar/avatar-13.png": {
    "type": "image/png",
    "etag": "\"502a-wfrD15oorRSaVvsf0U3XEABjYsU\"",
    "mtime": "2026-10-20T00:18:15.553Z",
    "size": 20522,
    "path": "../public/img/NationalDayAvatar/avatar-13.png"
  },
  "/img/NationalDayAvatar/avatar-14.png": {
    "type": "image/png",
    "etag": "\"57c2-xmWZ66VCp9sfJq6Ynb2fi3AvuTA\"",
    "mtime": "2026-10-20T00:18:15.553Z",
    "size": 22466,
    "path": "../public/img/NationalDayAvatar/avatar-14.png"
  },
  "/img/NationalDayAvatar/avatar-15.png": {
    "type": "image/png",
    "etag": "\"ace2-lcXrlZnYf8OHcp3nZplsbW1e614\"",
    "mtime": "2026-10-20T00:18:15.554Z",
    "size": 44258,
    "path": "../public/img/NationalDayAvatar/avatar-15.png"
  },
  "/img/NationalDayAvatar/avatar-2.png": {
    "type": "image/png",
    "etag": "\"6152-NVy8ZwSpZ0XYDr3VCXhIVhyk7Tg\"",
    "mtime": "2026-10-20T00:18:15.554Z",
    "size": 24914,
    "path": "../public/img/NationalDayAvatar/avatar-2.png"
  },
  "/img/NationalDayAvatar/avatar-4.png": {
    "type": "image/png",
    "etag": "\"192f3-YDSZkrDeQlcxlvwZtDE7VojB/vw\"",
    "mtime": "2026-10-20T00:18:15.555Z",
    "size": 103155,
    "path": "../public/img/NationalDayAvatar/avatar-4.png"
  },
  "/img/NationalDayAvatar/avatar-3.png": {
    "type": "image/png",
    "etag": "\"3779-UygNFuk+E0wq3rgaoe0Nkylnm+U\"",
    "mtime": "2026-10-20T00:18:15.554Z",
    "size": 14201,
    "path": "../public/img/NationalDayAvatar/avatar-3.png"
  },
  "/img/NationalDayAvatar/avatar-5.png": {
    "type": "image/png",
    "etag": "\"38895-zbAm3xgf2zqNWnYlxDHsWWpZHaQ\"",
    "mtime": "2026-10-20T00:18:15.556Z",
    "size": 231573,
    "path": "../public/img/NationalDayAvatar/avatar-5.png"
  },
  "/img/NationalDayAvatar/avatar-7.png": {
    "type": "image/png",
    "etag": "\"8cd2-EU1+GevAr4A6RKqb9n4mRFYKb9A\"",
    "mtime": "2026-10-20T00:18:15.558Z",
    "size": 36050,
    "path": "../public/img/NationalDayAvatar/avatar-7.png"
  },
  "/img/NationalDayAvatar/avatar-6.png": {
    "type": "image/png",
    "etag": "\"7eca1-+OZP2cedIpq+XVx1fgK9nzo+7Y0\"",
    "mtime": "2026-10-20T00:18:15.557Z",
    "size": 519329,
    "path": "../public/img/NationalDayAvatar/avatar-6.png"
  },
  "/img/NationalDayAvatar/avatar-8.png": {
    "type": "image/png",
    "etag": "\"136ef-i4VgEzqBMc7IU6CWmxllXbHoWUw\"",
    "mtime": "2026-10-20T00:18:15.559Z",
    "size": 79599,
    "path": "../public/img/NationalDayAvatar/avatar-8.png"
  },
  "/img/NationalDayAvatar/avatar-9.png": {
    "type": "image/png",
    "etag": "\"4f13-+Tr+2gCiSqhDBQb3rCmY6MuETT0\"",
    "mtime": "2026-10-20T00:18:15.559Z",
    "size": 20243,
    "path": "../public/img/NationalDayAvatar/avatar-9.png"
  },
  "/img/NationalDayAvatar/bg.png": {
    "type": "image/png",
    "etag": "\"c65b-z8bPfUT+KA7pGNte4MUkpv39/fU\"",
    "mtime": "2026-10-20T00:18:15.559Z",
    "size": 50779,
    "path": "../public/img/NationalDayAvatar/bg.png"
  },
  "/img/NationalDayAvatar/message.png": {
    "type": "image/png",
    "etag": "\"13c5a-nky/8zDucc+woaoaoOURcPqPVmY\"",
    "mtime": "2026-10-20T00:18:15.560Z",
    "size": 80986,
    "path": "../public/img/NationalDayAvatar/message.png"
  },
  "/img/NationalDayAvatar/save-btn.png": {
    "type": "image/png",
    "etag": "\"7c1f-IBU2JmjFplCD2htD2N0fzUo6KQ8\"",
    "mtime": "2026-10-20T00:18:15.560Z",
    "size": 31775,
    "path": "../public/img/NationalDayAvatar/save-btn.png"
  },
  "/img/NationalDayAvatar/tool-logo.png": {
    "type": "image/png",
    "etag": "\"6160-OjXdpCJP5aoCqpmI1UCU4wB1i88\"",
    "mtime": "2026-10-20T00:18:15.561Z",
    "size": 24928,
    "path": "../public/img/NationalDayAvatar/tool-logo.png"
  },
  "/img/NationalDayAvatar/upload-btn.png": {
    "type": "image/png",
    "etag": "\"db6a-4kw+4NWcZfzFpeC4jGgCBvM/olE\"",
    "mtime": "2026-10-20T00:18:15.561Z",
    "size": 56170,
    "path": "../public/img/NationalDayAvatar/upload-btn.png"
  },
  "/img/office/office_banner.svg": {
    "type": "image/svg+xml",
    "etag": "\"489c-Mjr010ztgsK3XTa2OxTXYaWsL14\"",
    "mtime": "2026-10-20T00:18:15.562Z",
    "size": 18588,
    "path": "../public/img/office/office_banner.svg"
  },
  "/img/office/upload-btn.svg": {
    "type": "image/svg+xml",
    "etag": "\"c5f-aP0nG0PwyvqoVu5bKBpQOVH4UD4\"",
    "mtime": "2026-10-20T00:18:15.562Z",
    "size": 3167,
    "path": "../public/img/office/upload-btn.svg"
  },
  "/img/weibo/weibo_icon.png": {
    "type": "image/png",
    "etag": "\"349b-6uIa81WinDOMMtKYo0q0RixyR80\"",
    "mtime": "2026-10-20T00:18:15.567Z",
    "size": 13467,
    "path": "../public/img/weibo/weibo_icon.png"
  },
  "/img/weibo/weibo_icon_2.png": {
    "type": "image/png",
    "etag": "\"1168f-XvLxAnT680wFLEMSreZhUWZJ/O8\"",
    "mtime": "2026-10-20T00:18:15.567Z",
    "size": 71311,
    "path": "../public/img/weibo/weibo_icon_2.png"
  },
  "/_nuxt/builds/meta/631842df-4911-48c0-8fd4-2075dd593927.json": {
    "type": "application/json",
    "etag": "\"58-6mjRT98c7OVv7DnDuO1rTi5zATs\"",
    "mtime": "2026-10-23T01:52:30.706Z",
    "size": 88,
    "path": "../public/_nuxt/builds/meta/631842df-4911-48c0-8fd4-2075dd593927.json"
  },
  "/_nuxt/builds/latest.json": {
    "type": "application/json",
    "etag": "\"47-zU0lmIVTaiv2vBTvmRsFjDIITYs\"",
    "mtime": "2026-10-23T01:52:30.706Z",
    "size": 71,
    "path": "../public/_nuxt/builds/latest.json"
  },
  "/_nuxt/_tvkp5DQ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"44e29-ibCfCEniNUoeQ65OzqJN407KNBg\"",
    "mtime": "2026-10-23T01:52:27.329Z",
    "size": 282153,
    "path": "../public/_nuxt/_tvkp5DQ.js"
  },
  "/_nuxt/DzXHGeNs.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"555f2-ZbKtjI2xd+BPbr/JXzGkCoApdoA\"",
    "mtime": "2026-10-23T01:52:27.326Z",
    "size": 349682,
    "path": "../public/_nuxt/DzXHGeNs.js"
  }
};

const _DRIVE_LETTER_START_RE = /^[A-Za-z]:\//;
function normalizeWindowsPath(input = "") {
  if (!input) {
    return input;
  }
  return input.replace(/\\/g, "/").replace(_DRIVE_LETTER_START_RE, (r) => r.toUpperCase());
}
const _IS_ABSOLUTE_RE = /^[/\\](?![/\\])|^[/\\]{2}(?!\.)|^[A-Za-z]:[/\\]/;
const _DRIVE_LETTER_RE = /^[A-Za-z]:$/;
const _ROOT_FOLDER_RE = /^\/([A-Za-z]:)?$/;
function cwd() {
  if (typeof process !== "undefined" && typeof process.cwd === "function") {
    return process.cwd().replace(/\\/g, "/");
  }
  return "/";
}
const resolve = function(...arguments_) {
  arguments_ = arguments_.map((argument) => normalizeWindowsPath(argument));
  let resolvedPath = "";
  let resolvedAbsolute = false;
  for (let index = arguments_.length - 1; index >= -1 && !resolvedAbsolute; index--) {
    const path = index >= 0 ? arguments_[index] : cwd();
    if (!path || path.length === 0) {
      continue;
    }
    resolvedPath = `${path}/${resolvedPath}`;
    resolvedAbsolute = isAbsolute(path);
  }
  resolvedPath = normalizeString(resolvedPath, !resolvedAbsolute);
  if (resolvedAbsolute && !isAbsolute(resolvedPath)) {
    return `/${resolvedPath}`;
  }
  return resolvedPath.length > 0 ? resolvedPath : ".";
};
function normalizeString(path, allowAboveRoot) {
  let res = "";
  let lastSegmentLength = 0;
  let lastSlash = -1;
  let dots = 0;
  let char = null;
  for (let index = 0; index <= path.length; ++index) {
    if (index < path.length) {
      char = path[index];
    } else if (char === "/") {
      break;
    } else {
      char = "/";
    }
    if (char === "/") {
      if (lastSlash === index - 1 || dots === 1) ; else if (dots === 2) {
        if (res.length < 2 || lastSegmentLength !== 2 || res[res.length - 1] !== "." || res[res.length - 2] !== ".") {
          if (res.length > 2) {
            const lastSlashIndex = res.lastIndexOf("/");
            if (lastSlashIndex === -1) {
              res = "";
              lastSegmentLength = 0;
            } else {
              res = res.slice(0, lastSlashIndex);
              lastSegmentLength = res.length - 1 - res.lastIndexOf("/");
            }
            lastSlash = index;
            dots = 0;
            continue;
          } else if (res.length > 0) {
            res = "";
            lastSegmentLength = 0;
            lastSlash = index;
            dots = 0;
            continue;
          }
        }
        if (allowAboveRoot) {
          res += res.length > 0 ? "/.." : "..";
          lastSegmentLength = 2;
        }
      } else {
        if (res.length > 0) {
          res += `/${path.slice(lastSlash + 1, index)}`;
        } else {
          res = path.slice(lastSlash + 1, index);
        }
        lastSegmentLength = index - lastSlash - 1;
      }
      lastSlash = index;
      dots = 0;
    } else if (char === "." && dots !== -1) {
      ++dots;
    } else {
      dots = -1;
    }
  }
  return res;
}
const isAbsolute = function(p) {
  return _IS_ABSOLUTE_RE.test(p);
};
const relative = function(from, to) {
  const _from = resolve(from).replace(_ROOT_FOLDER_RE, "$1").split("/");
  const _to = resolve(to).replace(_ROOT_FOLDER_RE, "$1").split("/");
  if (_to[0][1] === ":" && _from[0][1] === ":" && _from[0] !== _to[0]) {
    return _to.join("/");
  }
  const _fromCopy = [..._from];
  for (const segment of _fromCopy) {
    if (_to[0] !== segment) {
      break;
    }
    _from.shift();
    _to.shift();
  }
  return [..._from.map(() => ".."), ..._to].join("/");
};
const dirname = function(p) {
  const segments = normalizeWindowsPath(p).replace(/\/$/, "").split("/").slice(0, -1);
  if (segments.length === 1 && _DRIVE_LETTER_RE.test(segments[0])) {
    segments[0] += "/";
  }
  return segments.join("/") || (isAbsolute(p) ? "/" : ".");
};

function readAsset (id) {
  const serverDir = dirname(fileURLToPath(globalThis._importMeta_.url));
  // Public dirs might be pruned after the build (uploaded to a CDN, sourcemaps
  // stripped), so a manifest entry with no file behind it reads as absent, not broken.
  return promises.readFile(resolve(serverDir, assets[id].path)).catch((error) => {
    if (error?.code !== 'ENOENT') { throw error }
  })
}

const publicAssetBases = {"/_nuxt/builds/meta/":{"maxAge":31536000},"/_nuxt/builds/":{"maxAge":1},"/_nuxt/":{"maxAge":31536000}};

function isPublicAssetURL(id = '') {
  if (assets[id]) {
    return true
  }
  for (const base in publicAssetBases) {
    if (id.startsWith(base)) { return true }
  }
  return false
}

function getAsset (id) {
  return assets[id]
}

const METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
const EncodingMap = { gzip: ".gz", br: ".br" };
const _V9m6X0 = eventHandler((event) => {
  if (event.method && !METHODS.has(event.method)) {
    return;
  }
  let id = decodePath(
    withLeadingSlash(withoutTrailingSlash(parseURL(event.path).pathname))
  );
  let asset;
  const encodingHeader = String(
    getRequestHeader(event, "accept-encoding") || ""
  );
  const encodings = [
    ...encodingHeader.split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(),
    ""
  ];
  for (const encoding of encodings) {
    for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
      const _asset = getAsset(_id);
      if (_asset) {
        asset = _asset;
        id = _id;
        break;
      }
    }
  }
  if (!asset) {
    if (isPublicAssetURL(id)) {
      removeResponseHeader(event, "Cache-Control");
      throw createError$1({ statusCode: 404 });
    }
    return;
  }
  if (asset.encoding !== void 0) {
    appendResponseHeader(event, "Vary", "Accept-Encoding");
  }
  const ifNotMatch = getRequestHeader(event, "if-none-match") === asset.etag;
  if (ifNotMatch) {
    setResponseStatus(event, 304, "Not Modified");
    return "";
  }
  const ifModifiedSinceH = getRequestHeader(event, "if-modified-since");
  const mtimeDate = new Date(asset.mtime);
  if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
    setResponseStatus(event, 304, "Not Modified");
    return "";
  }
  if (asset.type && !getResponseHeader(event, "Content-Type")) {
    setResponseHeader(event, "Content-Type", asset.type);
  }
  if (asset.etag && !getResponseHeader(event, "ETag")) {
    setResponseHeader(event, "ETag", asset.etag);
  }
  if (asset.mtime && !getResponseHeader(event, "Last-Modified")) {
    setResponseHeader(event, "Last-Modified", mtimeDate.toUTCString());
  }
  if (asset.encoding && !getResponseHeader(event, "Content-Encoding")) {
    setResponseHeader(event, "Content-Encoding", asset.encoding);
  }
  if (asset.size > 0 && !getResponseHeader(event, "Content-Length")) {
    setResponseHeader(event, "Content-Length", asset.size);
  }
  const data = readAsset(id);
  return typeof data?.then === "function" ? data.then(
    (resolved) => assertAssetData(event, resolved)
  ) : assertAssetData(event, data);
});
function assertAssetData(event, data) {
  if (data === null || data === void 0) {
    removeResponseHeader(event, "Cache-Control");
    throw createError$1({ statusCode: 404 });
  }
  return data;
}

const _njqPVb = defineEventHandler((event) => {
  var _a, _b, _c;
  const uList = [
    "/tool/detail/DownloadM3U8"
  ];
  if (uList.indexOf(event.node.req.url) > -1) {
    (_a = event.node.res) == null ? void 0 : _a.setHeader("Cross-Origin-Embedder-Policy", "require-corp");
    (_b = event.node.res) == null ? void 0 : _b.setHeader("Cross-Origin-Opener-Policy", "same-origin");
    (_c = event.node.res) == null ? void 0 : _c.setHeader("cross-origin-resource-policy", "cross-origin");
  }
});

const _SxA8c9 = defineEventHandler(() => {});

const _lazy_yC2HSQ = () => import('../routes/api/search.get.mjs');
const _lazy_JKDnS1 = () => import('../routes/api/site.xml.mjs');
const _lazy_dqakYF = () => import('../routes/api/whois.get.mjs');
const _lazy_ZWN_IN = () => import('../routes/renderer.mjs').then(function (n) { return n.r; });

const handlers = [
  { route: '', handler: _V9m6X0, lazy: false, middleware: true, method: undefined },
  { route: '', handler: _njqPVb, lazy: false, middleware: true, method: undefined },
  { route: '/api/search', handler: _lazy_yC2HSQ, lazy: true, middleware: false, method: "get" },
  { route: '/api/site.xml', handler: _lazy_JKDnS1, lazy: true, middleware: false, method: undefined },
  { route: '/api/whois', handler: _lazy_dqakYF, lazy: true, middleware: false, method: "get" },
  { route: '/__nuxt_error', handler: _lazy_ZWN_IN, lazy: true, middleware: false, method: undefined },
  { route: '/__nuxt_island/**', handler: _SxA8c9, lazy: false, middleware: false, method: undefined },
  { route: '/**', handler: _lazy_ZWN_IN, lazy: true, middleware: false, method: undefined }
];

function createNitroApp() {
  const config = useRuntimeConfig();
  const hooks = createHooks();
  const captureError = (error, context = {}) => {
    const promise = hooks.callHookParallel("error", error, context).catch((error_) => {
      console.error("Error while capturing another error", error_);
    });
    if (context.event && isEvent(context.event)) {
      const errors = context.event.context.nitro?.errors;
      if (errors) {
        errors.push({ error, context });
      }
      if (context.event.waitUntil) {
        context.event.waitUntil(promise);
      }
    }
  };
  const h3App = createApp({
    debug: destr(false),
    onError: (error, event) => {
      captureError(error, { event, tags: ["request"] });
      return errorHandler(error, event);
    },
    onRequest: async (event) => {
      event.context.nitro = event.context.nitro || { errors: [] };
      const fetchContext = event.node.req?.__unenv__;
      if (fetchContext?._platform) {
        event.context = {
          _platform: fetchContext?._platform,
          // #3335
          ...fetchContext._platform,
          ...event.context
        };
      }
      if (!event.context.waitUntil && fetchContext?.waitUntil) {
        event.context.waitUntil = fetchContext.waitUntil;
      }
      event.fetch = (req, init) => fetchWithEvent(event, req, init, { fetch: localFetch });
      event.$fetch = (req, init) => fetchWithEvent(event, req, init, {
        fetch: $fetch
      });
      event.waitUntil = (promise) => {
        if (!event.context.nitro._waitUntilPromises) {
          event.context.nitro._waitUntilPromises = [];
        }
        event.context.nitro._waitUntilPromises.push(promise);
        if (event.context.waitUntil) {
          event.context.waitUntil(promise);
        }
      };
      event.captureError = (error, context) => {
        captureError(error, { event, ...context });
      };
      await nitroApp.hooks.callHook("request", event).catch((error) => {
        captureError(error, { event, tags: ["request"] });
      });
    },
    onBeforeResponse: async (event, response) => {
      await nitroApp.hooks.callHook("beforeResponse", event, response).catch((error) => {
        captureError(error, { event, tags: ["request", "response"] });
      });
    },
    onAfterResponse: async (event, response) => {
      await nitroApp.hooks.callHook("afterResponse", event, response).catch((error) => {
        captureError(error, { event, tags: ["request", "response"] });
      });
    }
  });
  const router = createRouter({
    preemptive: true
  });
  const nodeHandler = toNodeListener(h3App);
  const localCall = (aRequest) => b(
    nodeHandler,
    aRequest
  );
  const localFetch = (input, init) => {
    if (!input.toString().startsWith("/")) {
      return globalThis.fetch(input, init);
    }
    return C(
      nodeHandler,
      input,
      init
    ).then((response) => normalizeFetchResponse(response));
  };
  const $fetch = createFetch({
    fetch: localFetch,
    Headers: Headers$1,
    defaults: { baseURL: config.app.baseURL }
  });
  globalThis.$fetch = $fetch;
  h3App.use(createRouteRulesHandler({ localFetch }));
  for (const h of handlers) {
    let handler = h.lazy ? lazyEventHandler(h.handler) : h.handler;
    if (h.middleware || !h.route) {
      const middlewareBase = (config.app.baseURL + (h.route || "/")).replace(
        /\/+/g,
        "/"
      );
      h3App.use(middlewareBase, handler);
    } else {
      const routeRules = getRouteRulesForPath(
        h.route.replace(/:\w+|\*\*/g, "_")
      );
      if (routeRules.cache) {
        handler = cachedEventHandler(handler, {
          group: "nitro/routes",
          ...routeRules.cache
        });
      }
      router.use(h.route, handler, h.method);
    }
  }
  h3App.use(config.app.baseURL, router.handler);
  const app = {
    hooks,
    h3App,
    router,
    localCall,
    localFetch,
    captureError
  };
  return app;
}
function runNitroPlugins(nitroApp2) {
  for (const plugin of plugins) {
    try {
      plugin(nitroApp2);
    } catch (error) {
      nitroApp2.captureError(error, { tags: ["plugin"] });
      throw error;
    }
  }
}
const nitroApp = createNitroApp();
function useNitroApp() {
  return nitroApp;
}
runNitroPlugins(nitroApp);

function defineRenderHandler(render) {
  const runtimeConfig = useRuntimeConfig();
  return eventHandler(async (event) => {
    const nitroApp = useNitroApp();
    const ctx = { event, render, response: void 0 };
    await nitroApp.hooks.callHook("render:before", ctx);
    if (!ctx.response) {
      if (event.path === `${runtimeConfig.app.baseURL}favicon.ico`) {
        setResponseHeader(event, "Content-Type", "image/x-icon");
        return send(
          event,
          "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
        );
      }
      ctx.response = await ctx.render(event);
      if (!ctx.response) {
        const _currentStatus = getResponseStatus(event);
        setResponseStatus(event, _currentStatus === 200 ? 500 : _currentStatus);
        return send(
          event,
          "No response returned from render handler: " + event.path
        );
      }
    }
    await nitroApp.hooks.callHook("render:response", ctx.response, ctx);
    if (ctx.response.headers) {
      setResponseHeaders(event, ctx.response.headers);
    }
    if (ctx.response.statusCode || ctx.response.statusMessage) {
      setResponseStatus(
        event,
        ctx.response.statusCode,
        ctx.response.statusMessage
      );
    }
    return ctx.response.body;
  });
}

const debug = (...args) => {
};
function GracefulShutdown(server, opts) {
  opts = opts || {};
  const options = Object.assign(
    {
      signals: "SIGINT SIGTERM",
      timeout: 3e4,
      development: false,
      forceExit: true,
      onShutdown: (signal) => Promise.resolve(signal),
      preShutdown: (signal) => Promise.resolve(signal)
    },
    opts
  );
  let isShuttingDown = false;
  const connections = {};
  let connectionCounter = 0;
  const secureConnections = {};
  let secureConnectionCounter = 0;
  let failed = false;
  let finalRun = false;
  function onceFactory() {
    let called = false;
    return (emitter, events, callback) => {
      function call() {
        if (!called) {
          called = true;
          return Reflect.apply(callback, this, arguments);
        }
      }
      for (const e of events) {
        emitter.on(e, call);
      }
    };
  }
  const signals = options.signals.split(" ").map((s) => s.trim()).filter((s) => s.length > 0);
  const once = onceFactory();
  once(process, signals, (signal) => {
    debug("received shut down signal", signal);
    shutdown(signal).then(() => {
      if (options.forceExit) {
        process.exit(failed ? 1 : 0);
      }
    }).catch((error) => {
      debug("server shut down error occurred", error);
      process.exit(1);
    });
  });
  function isFunction(functionToCheck) {
    const getType = Object.prototype.toString.call(functionToCheck);
    return /^\[object\s([A-Za-z]+)?Function]$/.test(getType);
  }
  function destroy(socket, force = false) {
    if (socket._isIdle && isShuttingDown || force) {
      socket.destroy();
      if (socket.server instanceof http.Server) {
        delete connections[socket._connectionId];
      } else {
        delete secureConnections[socket._connectionId];
      }
    }
  }
  function destroyAllConnections(force = false) {
    debug("Destroy Connections : " + (force ? "forced close" : "close"));
    let counter = 0;
    let secureCounter = 0;
    for (const key of Object.keys(connections)) {
      const socket = connections[key];
      const serverResponse = socket._httpMessage;
      if (serverResponse && !force) {
        if (!serverResponse.headersSent) {
          serverResponse.setHeader("connection", "close");
        }
      } else {
        counter++;
        destroy(socket);
      }
    }
    debug("Connections destroyed : " + counter);
    debug("Connection Counter    : " + connectionCounter);
    for (const key of Object.keys(secureConnections)) {
      const socket = secureConnections[key];
      const serverResponse = socket._httpMessage;
      if (serverResponse && !force) {
        if (!serverResponse.headersSent) {
          serverResponse.setHeader("connection", "close");
        }
      } else {
        secureCounter++;
        destroy(socket);
      }
    }
    debug("Secure Connections destroyed : " + secureCounter);
    debug("Secure Connection Counter    : " + secureConnectionCounter);
  }
  server.on("request", (req, res) => {
    req.socket._isIdle = false;
    if (isShuttingDown && !res.headersSent) {
      res.setHeader("connection", "close");
    }
    res.on("finish", () => {
      req.socket._isIdle = true;
      destroy(req.socket);
    });
  });
  server.on("connection", (socket) => {
    if (isShuttingDown) {
      socket.destroy();
    } else {
      const id = connectionCounter++;
      socket._isIdle = true;
      socket._connectionId = id;
      connections[id] = socket;
      socket.once("close", () => {
        delete connections[socket._connectionId];
      });
    }
  });
  server.on("secureConnection", (socket) => {
    if (isShuttingDown) {
      socket.destroy();
    } else {
      const id = secureConnectionCounter++;
      socket._isIdle = true;
      socket._connectionId = id;
      secureConnections[id] = socket;
      socket.once("close", () => {
        delete secureConnections[socket._connectionId];
      });
    }
  });
  process.on("close", () => {
    debug("closed");
  });
  function shutdown(sig) {
    function cleanupHttp() {
      destroyAllConnections();
      debug("Close http server");
      return new Promise((resolve, reject) => {
        server.close((err) => {
          if (err) {
            return reject(err);
          }
          return resolve(true);
        });
      });
    }
    debug("shutdown signal - " + sig);
    if (options.development) {
      debug("DEV-Mode - immediate forceful shutdown");
      return process.exit(0);
    }
    function finalHandler() {
      if (!finalRun) {
        finalRun = true;
        if (options.finally && isFunction(options.finally)) {
          debug("executing finally()");
          options.finally();
        }
      }
      return Promise.resolve();
    }
    function waitForReadyToShutDown(totalNumInterval) {
      debug(`waitForReadyToShutDown... ${totalNumInterval}`);
      if (totalNumInterval === 0) {
        debug(
          `Could not close connections in time (${options.timeout}ms), will forcefully shut down`
        );
        return Promise.resolve(true);
      }
      const allConnectionsClosed = Object.keys(connections).length === 0 && Object.keys(secureConnections).length === 0;
      if (allConnectionsClosed) {
        debug("All connections closed. Continue to shutting down");
        return Promise.resolve(false);
      }
      debug("Schedule the next waitForReadyToShutdown");
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve(waitForReadyToShutDown(totalNumInterval - 1));
        }, 250);
      });
    }
    if (isShuttingDown) {
      return Promise.resolve();
    }
    debug("shutting down");
    return options.preShutdown(sig).then(() => {
      isShuttingDown = true;
      cleanupHttp();
    }).then(() => {
      const pollIterations = options.timeout ? Math.round(options.timeout / 250) : 0;
      return waitForReadyToShutDown(pollIterations);
    }).then((force) => {
      debug("Do onShutdown now");
      if (force) {
        destroyAllConnections(force);
      }
      return options.onShutdown(sig);
    }).then(finalHandler).catch((error) => {
      const errString = typeof error === "string" ? error : JSON.stringify(error);
      debug(errString);
      failed = true;
      throw errString;
    });
  }
  function shutdownManual() {
    return shutdown("manual");
  }
  return shutdownManual;
}

function getGracefulShutdownConfig() {
  return {
    disabled: !!process.env.NITRO_SHUTDOWN_DISABLED,
    signals: (process.env.NITRO_SHUTDOWN_SIGNALS || "SIGTERM SIGINT").split(" ").map((s) => s.trim()),
    timeout: Number.parseInt(process.env.NITRO_SHUTDOWN_TIMEOUT || "", 10) || 3e4,
    forceExit: !process.env.NITRO_SHUTDOWN_NO_FORCE_EXIT
  };
}
function setupGracefulShutdown(listener, nitroApp) {
  const shutdownConfig = getGracefulShutdownConfig();
  if (shutdownConfig.disabled) {
    return;
  }
  GracefulShutdown(listener, {
    signals: shutdownConfig.signals.join(" "),
    timeout: shutdownConfig.timeout,
    forceExit: shutdownConfig.forceExit,
    onShutdown: async () => {
      await new Promise((resolve) => {
        const timeout = setTimeout(() => {
          console.warn("Graceful shutdown timeout, force exiting...");
          resolve();
        }, shutdownConfig.timeout);
        nitroApp.hooks.callHook("close").catch((error) => {
          console.error(error);
        }).finally(() => {
          clearTimeout(timeout);
          resolve();
        });
      });
    }
  });
}

export { $fetch as $, NUXT_NO_SCRIPTS_PATTERNS as A, relative as B, joinURL as C, appTeleportTag as D, NUXT_PAGE_PATTERNS as E, defineRenderHandler as F, toRequestEvent as G, setResponseHeader as H, defu as I, parseQuery as J, parseURL as K, decodePath as L, withQuery as M, NUXT_PRERENDER_NO_SSR_ROUTES as N, hasProtocol as O, isScriptProtocol as P, sanitizeStatusCode as Q, withTrailingSlash as R, withoutTrailingSlash as S, getRequestHeaders as T, klona as U, getRequestHeader as V, isEqual as W, splitCookiesString as X, getResponseHeader as Y, setCookie as Z, getCookie as _, trapUnhandledNodeErrors as a, deleteCookie as a0, useNitroApp as b, defineEventHandler as c, destr as d, setHeader as e, createError$1 as f, getQuery as g, setResponseStatus as h, appRootTag as i, joinRelativeURL as j, appRootAttrs as k, appSpaLoaderTag as l, appSpaLoaderAttrs as m, getRouteRules as n, createHead as o, unheadOptions as p, appId as q, getQuery$1 as r, setupGracefulShutdown as s, toNodeListener as t, useRuntimeConfig as u, appHead as v, writeEarlyHints as w, NUXT_SSR_STREAMING as x, renderSSRHeadOptions as y, appTeleportAttrs as z };
//# sourceMappingURL=nitro.mjs.map
