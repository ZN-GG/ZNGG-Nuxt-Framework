const interopDefault = r => r.default || r || [];
const styles = {
  "../node_modules/nuxt/dist/app/entry.js": () => import('../build/entry-styles.qE1GXY3q.mjs').then(interopDefault),
  "pages/tool/detail/FlvPlayer.vue": () => import('../build/FlvPlayer-styles.CNUg4fGN.mjs').then(interopDefault),
  "pages/tool/detail/NPlayer.vue": () => import('../build/NPlayer-styles.DDEHCy3B.mjs').then(interopDefault),
  "pages/tool/detail/WordToPDF.vue": () => import('../build/WordToPDF-styles.BDLSQGco.mjs').then(interopDefault),
  "pages/tool/detail/CssGlassGenerates.vue": () => import('../build/CssGlassGenerates-styles.BD7CEW1N.mjs').then(interopDefault),
  "pages/tool/detail/FancyBorderRadius.vue": () => import('../build/FancyBorderRadius-styles.uPvzeSPT.mjs').then(interopDefault),
  "pages/tool/detail/MakePhrase.vue": () => import('../build/MakePhrase-styles.mL7pUmXt.mjs').then(interopDefault),
  "pages/tool/detail/NationalDayAvatar.vue": () => import('../build/NationalDayAvatar-styles.BBD5tGAx.mjs').then(interopDefault),
  "pages/tool/detail/WeiBoGenerates.vue": () => import('../build/WeiBoGenerates-styles.t4QCRCnF.mjs').then(interopDefault),
  "pages/tool/detail/TextSecret.vue": () => import('../build/TextSecret-styles.Dgnbycjp.mjs').then(interopDefault),
  "pages/read/index.vue": () => import('../build/index-styles.D-8UwheK.mjs').then(interopDefault),
  "pages/read/category/[id].vue": () => import('../build/_id_-styles.8vuivsSE.mjs').then(interopDefault),
  "pages/tool/category/[id].vue": () => import('../build/_id_-styles-2.Coln3Ogs.mjs').then(interopDefault),
  "pages/tool/index.vue": () => import('../build/index-styles-2.BPg-o8SW.mjs').then(interopDefault),
  "pages/tool/detail/Whois.vue": () => import('../build/Whois-styles.C8KIAiW0.mjs').then(interopDefault),
  "pages/read/post/[id].vue": () => import('../build/_id_-styles-3.B5IdU-f7.mjs').then(interopDefault),
  "pages/writer.vue": () => import('../build/writer-styles.wyOfcd7m.mjs').then(interopDefault),
  "pages/tool/detail/M3U8V2Pro.vue": () => import('../build/M3U8V2Pro-styles.T9YTilGs.mjs').then(interopDefault),
  "app.vue": () => import('../build/app-styles.W4uJ3SC0.mjs').then(interopDefault),
  "../node_modules/@nuxtjs/google-adsense/dist/runtime/components/Adsbygoogle.vue": () => import('../build/Adsbygoogle-styles.Cu7ZM56j.mjs').then(interopDefault),
  "layouts/default.vue": () => import('../build/default-styles.IjKuTElp.mjs').then(interopDefault),
  "components/Toolbar.vue": () => import('../build/default-styles.IjKuTElp.mjs').then(interopDefault)
};

const inlinedCSS = {"Adsbygoogle.CswjguNp.css":[["../node_modules/@nuxtjs/google-adsense/dist/runtime/components/Adsbygoogle.vue"]],"default.B6XwRajx.css":[["layouts/default.vue","components/Toolbar.vue"]],"_id_.CPhDtqRZ.css":[["pages/read/category/[id].vue"]],"read.AOjBc4zT.css":[["pages/read/index.vue"]],"_id_.BtZm8tN7.css":[["pages/read/post/[id].vue"]],"atom-one-dark.DX1W2tKP.css":[["pages/read/post/[id].vue","pages/writer.vue"]],"_id_.Cz-Gwb6Q.css":[["pages/tool/category/[id].vue"]],"CssGlassGenerates.DHMlCyoe.css":[["pages/tool/detail/CssGlassGenerates.vue"]],"FancyBorderRadius.SAJ40CgB.css":[["pages/tool/detail/FancyBorderRadius.vue"]],"FlvPlayer.DRBeBahy.css":[["pages/tool/detail/FlvPlayer.vue"]],"M3U8V2Pro.B0AGtkuJ.css":[["pages/tool/detail/M3U8V2Pro.vue"]],"MakePhrase.BV0KNp5I.css":[["pages/tool/detail/MakePhrase.vue"]],"NPlayer.BqNDyWPq.css":[["pages/tool/detail/NPlayer.vue"]],"NationalDayAvatar.i_Pewbr6.css":[["pages/tool/detail/NationalDayAvatar.vue"]],"TextSecret.BqekhHBi.css":[["pages/tool/detail/TextSecret.vue"]],"WeiBoGenerates.Dp0UVOdj.css":[["pages/tool/detail/WeiBoGenerates.vue"]],"Whois.C9hSFzQZ.css":[["pages/tool/detail/Whois.vue"]],"WordToPDF.CGD0Mknp.css":[["pages/tool/detail/WordToPDF.vue"]],"tool.BaCPouGG.css":[["pages/tool/index.vue"]],"writer.C0rQSfAI.css":[["pages/writer.vue"]]};

export { styles as default, inlinedCSS };
//# sourceMappingURL=styles.mjs.map
