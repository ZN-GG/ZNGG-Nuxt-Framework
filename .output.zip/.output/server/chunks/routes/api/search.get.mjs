import { c as defineEventHandler, g as getQuery, u as useRuntimeConfig, e as setHeader, f as createError } from '../../_/nitro.mjs';
import 'unhead/server';
import 'vue';
import 'unhead/legacy';
import 'unhead/plugins';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const TTL = 5 * 60 * 1e3;
const SHORT_TTL = 60 * 1e3;
let cache = null;
const split = (value) => String(value || "").split(/[,，]/).map((item) => item.trim()).filter(Boolean);
const stripMarkdown = (value) => String(value || "").replace(/```[\s\S]*?```/g, " ").replace(/!\[[^\]]*\]\([^)]*\)/g, " ").replace(/\[([^\]]*)\]\([^)]*\)/g, "$1").replace(/<[^>]+>/g, " ").replace(/[#>*_`~|-]/g, " ").replace(/\s+/g, " ").trim();
const textOf = (item) => {
  const summary = stripMarkdown(item.summary || item.description || "");
  if (summary) return summary.slice(0, 180);
  return stripMarkdown(item.content || "").slice(0, 180);
};
const categoryOf = (item, fallback) => {
  var _a;
  return ((_a = item.category) == null ? void 0 : _a.name) || item.categoryName || fallback;
};
async function fetchList(base, path) {
  var _a;
  const response = await $fetch(base + path, {
    headers: { version: "20" },
    timeout: 8e3
  });
  return Array.isArray((_a = response == null ? void 0 : response.data) == null ? void 0 : _a.content) ? response.data.content : [];
}
async function buildIndex(base) {
  if (cache && Date.now() - cache.at < (cache.degraded ? SHORT_TTL : TTL)) {
    return cache;
  }
  const [tools, articles, projects, downloads] = await Promise.allSettled([
    fetchList(base, "/portal/tool/1/60"),
    fetchList(base, "/portal/article/1/999"),
    fetchList(base, "/portal/project/1/999"),
    fetchList(base, "/portal/download/1/999")
  ]);
  const docs = [];
  const failed = [tools, articles, projects, downloads].some((result) => result.status === "rejected");
  const push = (result, type, map) => {
    if (result.status !== "fulfilled") return;
    for (const item of result.value) {
      const normalized = map(item);
      docs.push({
        ...normalized,
        type,
        text: [
          normalized.title,
          normalized.summary,
          normalized.category,
          normalized.tags.join(" ")
        ].join(" ").toLowerCase()
      });
    }
  };
  push(tools, "tool", (item) => {
    var _a;
    const slug = String(item.content || item.slug || item.id);
    return {
      id: String((_a = item.id) != null ? _a : slug),
      title: item.title || item.name || "\u672A\u547D\u540D\u5DE5\u5177",
      summary: textOf(item),
      tags: split(item.tags),
      category: categoryOf(item, "\u5728\u7EBF\u5DE5\u5177"),
      route: `/tool/detail/${encodeURIComponent(slug)}`,
      updatedAt: item.updateTime || "",
      meta: { category: categoryOf(item, "\u5728\u7EBF\u5DE5\u5177") }
    };
  });
  push(articles, "article", (item) => {
    var _a;
    return {
      id: String(item.id),
      title: item.title || "\u672A\u547D\u540D\u6587\u7AE0",
      summary: textOf(item),
      tags: split(item.labels),
      category: categoryOf(item, "\u6587\u7AE0"),
      route: `/read/post/${item.id}`,
      updatedAt: item.updateTime || "",
      meta: { author: ((_a = item.user) == null ? void 0 : _a.name) || "ZNGG", date: String(item.updateTime || "").slice(0, 10) }
    };
  });
  push(projects, "project", (item) => ({
    id: String(item.id),
    title: item.name || "\u672A\u547D\u540D\u9879\u76EE",
    summary: textOf(item),
    tags: split(item.tags),
    category: categoryOf(item, "\u5F00\u6E90\u9879\u76EE"),
    route: `/project/${item.id}`,
    updatedAt: item.updateTime || "",
    meta: { platform: item.platform, stars: item.stars, language: item.language }
  }));
  push(downloads, "download", (item) => ({
    id: String(item.id),
    title: item.title || "\u672A\u547D\u540D\u8D44\u6E90",
    summary: textOf(item),
    tags: split(item.tags),
    category: categoryOf(item, "\u8F6F\u4EF6\u8D44\u6E90"),
    route: `/download/${item.id}`,
    updatedAt: item.updateTime || "",
    meta: { platform: item.platform, version: item.version, size: item.fileSize }
  }));
  if (docs.length === 0 && failed) {
    throw createError({ statusCode: 503, statusMessage: "\u641C\u7D22\u670D\u52A1\u6682\u4E0D\u53EF\u7528" });
  }
  cache = { at: Date.now(), docs, degraded: failed };
  return cache;
}
function score(doc, query) {
  const title = doc.title.toLowerCase();
  if (title === query) return 120;
  if (title.startsWith(query)) return 100;
  if (title.includes(query)) return 80;
  if (doc.tags.some((tag) => tag.toLowerCase().includes(query))) return 55;
  if (doc.category.toLowerCase().includes(query)) return 45;
  if (doc.route.toLowerCase().includes(query)) return 40;
  if (doc.summary.toLowerCase().includes(query)) return 25;
  return 0;
}
const search_get = defineEventHandler(async (event) => {
  const { q = "", type = "", limit = "8" } = getQuery(event);
  const query = String(q || "").trim().toLowerCase();
  const take = Math.min(Math.max(Number(limit) || 8, 1), 30);
  const allowed = ["tool", "article", "project", "download"];
  const requested = allowed.includes(type) ? type : null;
  const empty = {
    tool: [],
    article: [],
    project: [],
    download: []
  };
  if (!query) {
    return { query: "", total: 0, groups: empty, degraded: false };
  }
  try {
    const config = useRuntimeConfig();
    const index = await buildIndex(config.public.apiBase);
    const matched = index.docs.map((doc) => ({ doc, score: score(doc, query) })).filter((entry) => entry.score > 0 && (!requested || entry.doc.type === requested)).sort((a, b) => b.score - a.score || String(b.doc.updatedAt).localeCompare(String(a.doc.updatedAt)));
    const groups = { ...empty };
    for (const entry of matched) {
      if (groups[entry.doc.type].length < take) {
        groups[entry.doc.type].push(entry.doc);
      }
    }
    const total = matched.length;
    setHeader(event, "cache-control", "public, max-age=60, stale-while-revalidate=300");
    return { query: String(q), total, groups, degraded: index.degraded };
  } catch (error) {
    throw createError({
      statusCode: (error == null ? void 0 : error.statusCode) || 503,
      statusMessage: "\u641C\u7D22\u670D\u52A1\u6682\u4E0D\u53EF\u7528"
    });
  }
});

export { search_get as default };
//# sourceMappingURL=search.get.mjs.map
