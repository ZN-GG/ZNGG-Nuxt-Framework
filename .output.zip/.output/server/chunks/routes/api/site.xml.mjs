import { c as defineEventHandler, u as useRuntimeConfig, h as setResponseStatus, e as setHeader } from '../../_/nitro.mjs';
import 'unhead/server';
import 'vue';
import 'unhead/legacy';
import 'unhead/plugins';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const site_xml = defineEventHandler(async (event) => {
  var _a, _b, _c, _d;
  const config = useRuntimeConfig(event);
  const baseUrl = String(config.public.siteUrl || "https://www.zngg.net").replace(/\/$/, "");
  const apiBase = String(config.public.apiBase || "https://api.zngg.net").replace(/\/$/, "");
  const entries = [];
  const escapeXml = (value) => String(value).replace(/[<>&'"]/g, (char) => {
    const map = { "<": "&lt;", ">": "&gt;", "&": "&amp;", "'": "&apos;", '"': "&quot;" };
    return map[char];
  });
  const addUrl = (path, lastmod, changefreq, priority) => {
    entries.push(
      `<url><loc>${escapeXml(baseUrl + path)}</loc>` + (lastmod ? `<lastmod>${escapeXml(lastmod)}</lastmod>` : "") + `<changefreq>${changefreq}</changefreq><priority>${priority}</priority></url>`
    );
  };
  const fetchPage = async (url) => {
    try {
      const result = await $fetch(url, {
        headers: { version: "20" },
        timeout: 1e4
      });
      return (result == null ? void 0 : result.success) ? result.data : null;
    } catch (e) {
      return null;
    }
  };
  const dateOf = (value) => value ? String(value).slice(0, 10) : "";
  const latestOf = (items) => items.reduce((latest, item) => {
    const date = dateOf(item == null ? void 0 : item.updateTime);
    return date > latest ? date : latest;
  }, "");
  const [toolData, articleData, projectData, downloadData, articleCategories, toolCategories] = await Promise.all([
    fetchPage(apiBase + "/portal/tool/1/99"),
    fetchPage(apiBase + "/portal/article/1/999"),
    fetchPage(apiBase + "/portal/project/1/999"),
    fetchPage(apiBase + "/portal/download/1/999"),
    fetchPage(apiBase + "/portal/article_category"),
    fetchPage(apiBase + "/portal/tool_category")
  ]);
  const tools = (_a = toolData == null ? void 0 : toolData.content) != null ? _a : [];
  const articles = (_b = articleData == null ? void 0 : articleData.content) != null ? _b : [];
  const projects = (_c = projectData == null ? void 0 : projectData.content) != null ? _c : [];
  const downloads = (_d = downloadData == null ? void 0 : downloadData.content) != null ? _d : [];
  if (!toolData && !articleData && !projectData && !downloadData) {
    setResponseStatus(event, 503);
    setHeader(event, "Content-Type", "text/plain; charset=utf-8");
    return "Sitemap temporarily unavailable";
  }
  for (const item of tools) {
    addUrl("/tool/detail/" + encodeURIComponent(String(item.content || "")), dateOf(item.updateTime), "monthly", "0.8");
  }
  for (const item of articles) {
    addUrl("/read/post/" + encodeURIComponent(String(item.id)), dateOf(item.updateTime), "monthly", "0.8");
  }
  for (const item of projects) {
    addUrl("/project/" + encodeURIComponent(String(item.id)), dateOf(item.updateTime), "monthly", "0.8");
  }
  for (const item of downloads) {
    addUrl("/download/" + encodeURIComponent(String(item.id)), dateOf(item.updateTime), "monthly", "0.8");
  }
  const latestArticle = latestOf(articles);
  const latestTool = latestOf(tools);
  const latestProject = latestOf(projects);
  const latestDownload = latestOf(downloads);
  for (const item of articleCategories != null ? articleCategories : []) {
    addUrl("/read/category/" + encodeURIComponent(String(item.id)), latestArticle, "weekly", "0.6");
  }
  for (const item of toolCategories != null ? toolCategories : []) {
    addUrl("/tool/category/" + encodeURIComponent(String(item.id)), latestTool, "weekly", "0.6");
  }
  addUrl("/read", latestArticle, "weekly", "0.8");
  addUrl("/tool", latestTool, "weekly", "0.8");
  addUrl("/project", latestProject, "weekly", "0.8");
  addUrl("/download", latestDownload, "weekly", "0.8");
  addUrl("/discover", "", "weekly", "0.7");
  addUrl("/nav", "", "monthly", "0.5");
  addUrl("/link", "", "monthly", "0.5");
  const latestHome = [latestArticle, latestTool, latestProject, latestDownload].sort().pop() || "";
  addUrl("/", latestHome, "daily", "1.0");
  setHeader(event, "Content-Type", "application/xml; charset=utf-8");
  setHeader(event, "Cache-Control", "public, max-age=3600");
  return '<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' + entries.join("") + "</urlset>";
});

export { site_xml as default };
//# sourceMappingURL=site.xml.mjs.map
