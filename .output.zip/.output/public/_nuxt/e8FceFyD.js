const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./CLKk50C3.js","./BCiCTKAo.js","./AN-IDt-y.js"])))=>i.map(i=>d[i]);
import{_ as e,g as t}from"#entry";import{t as n}from"./CsqJ5Xw1.js";var r=n(`chart-graph`,function(e){return`<?xml version="1.0" encoding="UTF-8"?><svg width="`+e.size+`" height="`+e.size+`" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="17" y="6" width="14" height="9" fill="`+e.colors[1]+`" stroke="`+e.colors[0]+`" stroke-width="`+e.strokeWidth+`" stroke-linejoin="`+e.strokeLinejoin+`"/><rect x="6" y="33" width="14" height="9" fill="`+e.colors[1]+`" stroke="`+e.colors[0]+`" stroke-width="`+e.strokeWidth+`" stroke-linejoin="`+e.strokeLinejoin+`"/><rect x="28" y="33" width="14" height="9" fill="`+e.colors[1]+`" stroke="`+e.colors[0]+`" stroke-width="`+e.strokeWidth+`" stroke-linejoin="`+e.strokeLinejoin+`"/><path d="M24 16V24" stroke="`+e.colors[0]+`" stroke-width="`+e.strokeWidth+`" stroke-linecap="`+e.strokeLinecap+`" stroke-linejoin="`+e.strokeLinejoin+`"/><path d="M13 33V24H35V33" stroke="`+e.colors[0]+`" stroke-width="`+e.strokeWidth+`" stroke-linecap="`+e.strokeLinecap+`" stroke-linejoin="`+e.strokeLinejoin+`"/></svg>`});e();var i={class:`Class diagram`,er:`Entity relationship diagram`,flowchart:`Flow chart`,gantt:`Gantt chart`,mermaid:`Mermaid diagrams`,pie:`Pie chart`,sequence:`Sequence diagram`,state:`State diagram`,uj:`User journey diagram`};function a({locale:e,...n}={}){let a={...i,...e},o,s=[{title:a.flowchart,code:`graph TD
Start --> Stop`},{title:a.sequence,code:`sequenceDiagram
Alice->>John: Hello John, how are you?
John-->>Alice: Great!
Alice-)John: See you later!`},{title:a.class,code:`classDiagram
Animal <|-- Duck
Animal <|-- Fish
Animal <|-- Zebra
Animal : +int age
Animal : +String gender
Animal: +isMammal()
Animal: +mate()
class Duck{
+String beakColor
+swim()
+quack()
}
class Fish{
-int sizeInFeet
-canEat()
}
class Zebra{
+bool is_wild
+run()
}`},{title:a.state,code:`stateDiagram-v2
[*] --> Still
Still --> [*]

Still --> Moving
Moving --> Still
Moving --> Crash
Crash --> [*]`},{title:a.er,code:`erDiagram
CUSTOMER ||--o{ ORDER : places
ORDER ||--|{ LINE-ITEM : contains
CUSTOMER }|..|{ DELIVERY-ADDRESS : uses`},{title:a.uj,code:`journey
title My working day
section Go to work
Make tea: 5: Me
Go upstairs: 3: Me
Do work: 1: Me, Cat
section Go home
Go downstairs: 5: Me
Sit down: 5: Me`},{title:a.gantt,code:`gantt
title A Gantt Diagram
dateFormat  YYYY-MM-DD
section Section
A task           :a1, 2014-01-01, 30d
Another task     :after a1  , 20d
section Another
Task in sec      :2014-01-12  , 12d
another task      : 24d`},{title:a.pie,code:`pie title Pets adopted by volunteers
"Dogs" : 386
"Cats" : 85
"Rats" : 15`}];return{viewerEffect({markdownBody:e}){(async()=>{let r=e.querySelectorAll(`pre>code.language-mermaid`);r.length!==0&&(o||(o=await t(()=>import(`./CLKk50C3.js`).then(e=>e.default),__vite__mapDeps([0,1,2]),import.meta.url),n&&o.initialize(n)),r.forEach((e,t)=>{let n=e.parentElement,r=e.innerText,i=document.createElement(`div`);i.classList.add(`bytemd-mermaid`),i.style.lineHeight=`initial`,n.replaceWith(i);try{o.render(`bytemd-mermaid-${Date.now()}-${t}`,r,e=>{i.innerHTML=e},i)}catch{}}))})()},actions:[{title:a.mermaid,icon:r({}),cheatsheet:"```mermaid",handler:{type:`dropdown`,actions:s.map(({title:e,code:t})=>({title:e,handler:{type:`action`,click({editor:e,appendBlock:n,codemirror:r}){let{line:i}=n("```mermaid\n"+t+"\n```");e.setSelection(r.Pos(i+1,0),r.Pos(i+t.split(`
`).length)),e.focus()}}})),...a}}]}}export{a as default};